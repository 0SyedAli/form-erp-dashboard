import mongoose from 'mongoose';
import { CreateSupplierInput, UpdateSupplierInput, SupplierQuery } from './supplier.schema.js';
export declare class SupplierService {
    /**
     * Generates a sequential supplier code atomically: SUP-1001, SUP-1002, etc.
     */
    static generateSupplierCode(session?: mongoose.ClientSession | null): Promise<string>;
    /**
     * 1. CREATE SUPPLIER
     */
    static createSupplier(input: CreateSupplierInput, userContext: {
        id: string;
        loginId: string;
        branchId?: string;
    }): Promise<{
        id: string;
        code: string;
        name: string;
        contactPerson?: string;
        phone: string;
        whatsapp?: string;
        email?: string;
        address?: string;
        city: string;
        ntn?: string;
        suppliedBrands: string[];
        creditEnabled: boolean;
        defaultCreditDays: number;
        paymentTerms: string;
        creditLimit: number;
        openingPayable: number;
        currentOutstanding: number;
        balancePayable: number;
        unallocatedAdvances: number;
        supplierCreditBalance: number;
        bankName?: string;
        bankAccountNumber?: string;
        status: "ACTIVE" | "INACTIVE";
        notes?: string;
        createdAt: Date;
        updatedAt: Date;
        _id: mongoose.Types.ObjectId;
        $locals: Record<string, unknown>;
        $op: "save" | "validate" | "remove" | null;
        $where: Record<string, unknown>;
        baseModelName?: string;
        collection: mongoose.Collection;
        db: mongoose.Connection;
        errors?: mongoose.Error.ValidationError;
        isNew: boolean;
        schema: mongoose.Schema;
        __v: number;
    }>;
    /**
     * 2. GET SUPPLIERS LIST
     */
    static getSuppliers(query: SupplierQuery): Promise<any>;
    /**
     * 3. GET SUPPLIER BY ID
     */
    static getSupplierById(idOrCode: string): Promise<any>;
    /**
     * 4. UPDATE SUPPLIER
     */
    static updateSupplier(id: string, input: UpdateSupplierInput): Promise<{
        id: string;
        code: string;
        name: string;
        contactPerson?: string;
        phone: string;
        whatsapp?: string;
        email?: string;
        address?: string;
        city: string;
        ntn?: string;
        suppliedBrands: string[];
        creditEnabled: boolean;
        defaultCreditDays: number;
        paymentTerms: string;
        creditLimit: number;
        openingPayable: number;
        currentOutstanding: number;
        balancePayable: number;
        unallocatedAdvances: number;
        supplierCreditBalance: number;
        bankName?: string;
        bankAccountNumber?: string;
        status: "ACTIVE" | "INACTIVE";
        notes?: string;
        createdAt: Date;
        updatedAt: Date;
        _id: mongoose.Types.ObjectId;
        $locals: Record<string, unknown>;
        $op: "save" | "validate" | "remove" | null;
        $where: Record<string, unknown>;
        baseModelName?: string;
        collection: mongoose.Collection;
        db: mongoose.Connection;
        errors?: mongoose.Error.ValidationError;
        isNew: boolean;
        schema: mongoose.Schema;
        __v: number;
    }>;
    /**
     * 5. UPDATE STATUS (ACTIVATE / DEACTIVATE)
     */
    static updateStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<{
        id: string;
        code: string;
        name: string;
        contactPerson?: string;
        phone: string;
        whatsapp?: string;
        email?: string;
        address?: string;
        city: string;
        ntn?: string;
        suppliedBrands: string[];
        creditEnabled: boolean;
        defaultCreditDays: number;
        paymentTerms: string;
        creditLimit: number;
        openingPayable: number;
        currentOutstanding: number;
        balancePayable: number;
        unallocatedAdvances: number;
        supplierCreditBalance: number;
        bankName?: string;
        bankAccountNumber?: string;
        status: "ACTIVE" | "INACTIVE";
        notes?: string;
        createdAt: Date;
        updatedAt: Date;
        _id: mongoose.Types.ObjectId;
        $locals: Record<string, unknown>;
        $op: "save" | "validate" | "remove" | null;
        $where: Record<string, unknown>;
        baseModelName?: string;
        collection: mongoose.Collection;
        db: mongoose.Connection;
        errors?: mongoose.Error.ValidationError;
        isNew: boolean;
        schema: mongoose.Schema;
        __v: number;
    }>;
    /**
     * 6. GET SUPPLIER LEDGER
     */
    static getSupplierLedger(supplierId: string, query?: {
        dateFrom?: string;
        dateTo?: string;
        page?: number;
        limit?: number;
    }): Promise<any>;
    /**
     * 7. GET SUPPLIER OUTSTANDING BILLS
     */
    static getSupplierOutstandingBills(supplierId: string): Promise<any>;
    /**
     * 8. GET ALL BILLS FOR SUPPLIER
     */
    static getSupplierBills(supplierId: string): Promise<any>;
    /**
     * 9. GET ALL PAYMENTS FOR SUPPLIER
     */
    static getSupplierPayments(supplierId: string): Promise<any>;
}
