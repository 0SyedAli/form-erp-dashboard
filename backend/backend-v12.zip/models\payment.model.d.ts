import mongoose, { Document } from 'mongoose';
export interface IPayment extends Document {
    paymentNumber: string;
    invoiceId?: mongoose.Types.ObjectId;
    customerId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    amount: number;
    paymentMethod: 'CASH' | 'BANK_TRANSFER' | 'CHEQUE' | 'ONLINE';
    reference?: string;
    notes?: string;
    collectedBy: string;
    paymentDate: Date;
    createdAt: Date;
}
export declare const Payment: mongoose.Model<IPayment, {}, {}, {}, mongoose.Document<unknown, {}, IPayment, {}, {}> & IPayment & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
