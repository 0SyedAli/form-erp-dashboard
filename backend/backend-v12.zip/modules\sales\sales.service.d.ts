import mongoose from 'mongoose';
import { SalesQuery } from './sales.schema.js';
export interface UserContext {
    accountId: string;
    loginId: string;
    role: 'SUPER_ADMIN' | 'BRANCH';
    branchId?: string;
}
export declare class SalesService {
    /**
     * 1. GET INVOICES WITH BRANCH ISOLATION & FILTERS
     */
    static getInvoices(query: SalesQuery, userContext: UserContext): Promise<{
        invoices: (mongoose.FlattenMaps<import("../../models/salesInvoice.model.js").ISalesInvoice> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    /**
     * 2. GET INVOICE BY ID (WITH BRANCH ISOLATION GUARD)
     */
    static getInvoiceById(id: string, userContext: UserContext): Promise<any>;
    /**
     * 3. GET INVOICE RECEIPT VIEW (80mm Thermal / A4 Commercial format)
     */
    static getInvoiceReceipt(id: string, userContext: UserContext): Promise<{
        invoiceNumber: any;
        date: any;
        isInterBranch: any;
        sourceBranch: {
            name: any;
            code: any;
            shopNumber: any;
        } | undefined;
        branch: {
            name: any;
            code: any;
            shopNumber: any;
            address: any;
            phone: any;
            city: any;
        };
        customer: {
            name: any;
            phone: any;
            type: any;
        };
        cashier: any;
        saleType: any;
        paymentArrangement: any;
        paymentStatus: any;
        items: any;
        financials: {
            subtotal: any;
            discount: any;
            tax: any;
            total: any;
            paidAmount: any;
            balanceDue: any;
            cashReceived: any;
            changeReturned: any;
            dueDate: any;
        };
        creditDetails: {
            creditOverride: any;
            creditApprovedBy: any;
            dueDate: any;
        } | null;
        notes: any;
    }>;
    /**
     * 4. DELETE / VOID INVOICE (With Option to Return Stock or Delete Only)
     */
    static deleteInvoice(id: string, options: {
        returnStock: boolean;
    }, userContext: UserContext): Promise<{
        success: boolean;
        invoiceNumber: any;
        status: any;
        stockReturned: boolean;
        message: string;
    }>;
    /**
     * 4. GET SALES SUMMARY METRICS
     * Keeps Invoiced Revenue strictly separate from Collections (Section 22).
     */
    static getSalesSummary(userContext: UserContext): Promise<{
        grossInvoicedSales: number;
        totalDiscounts: number;
        netInvoicedSales: number;
        walkInSales: number;
        wholesaleSales: number;
        distributorSales: number;
        invoiceCount: number;
        cashReceivedAtPOS: number;
        collectionsRecovered: number;
        totalCashCollected: number;
        totalOutstandingReceivables: number;
        overdueReceivables: number;
    }>;
}
