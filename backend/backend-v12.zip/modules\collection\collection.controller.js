"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionController = void 0;
const collection_service_js_1 = require("./collection.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class CollectionController {
    static getUserContext(req) {
        return {
            accountId: req.account?._id?.toString() || '',
            loginId: req.account?.loginId || '',
            role: req.account?.role || 'BRANCH',
            branchId: req.account?.branchId?._id?.toString() || req.account?.branchId?.toString(),
        };
    }
    static handleError(res, error, defaultMessage, defaultStatus = 500) {
        const err = error;
        const msg = err.message || defaultMessage;
        const status = err.statusCode || defaultStatus;
        const code = err.code ||
            (status === 404
                ? 'NOT_FOUND'
                : status === 403
                    ? 'FORBIDDEN'
                    : status === 409
                        ? 'CONFLICT'
                        : 'INTERNAL_ERROR');
        (0, apiResponse_js_1.sendError)(res, msg, status, code, err.details);
    }
    static async createCollection(req, res) {
        try {
            const userContext = CollectionController.getUserContext(req);
            const result = await collection_service_js_1.CollectionService.createCollection(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, result, result.message, result.isReplay ? 200 : 201);
        }
        catch (error) {
            CollectionController.handleError(res, error, 'Failed to record payment collection.');
        }
    }
    static async getCollections(req, res) {
        try {
            const userContext = CollectionController.getUserContext(req);
            const data = await collection_service_js_1.CollectionService.getCollections(req.query, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.collections, 'Payment collections retrieved.', 200, data.pagination);
        }
        catch (error) {
            CollectionController.handleError(res, error, 'Failed to fetch collections.');
        }
    }
    static async getCollectionById(req, res) {
        try {
            const userContext = CollectionController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await collection_service_js_1.CollectionService.getCollectionById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Collection record retrieved.');
        }
        catch (error) {
            CollectionController.handleError(res, error, 'Failed to fetch collection.');
        }
    }
    static async getCollectionReceipt(req, res) {
        try {
            const userContext = CollectionController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await collection_service_js_1.CollectionService.getCollectionReceipt(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Collection receipt retrieved.');
        }
        catch (error) {
            CollectionController.handleError(res, error, 'Failed to fetch collection receipt.');
        }
    }
    static async getOutstanding(req, res) {
        try {
            const userContext = CollectionController.getUserContext(req);
            const data = await collection_service_js_1.CollectionService.getOutstandingCustomers(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Outstanding customer receivables retrieved.');
        }
        catch (error) {
            CollectionController.handleError(res, error, 'Failed to fetch outstanding receivables.');
        }
    }
    static async getOverdue(req, res) {
        try {
            const userContext = CollectionController.getUserContext(req);
            const data = await collection_service_js_1.CollectionService.getOverdueCustomers(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Overdue customer receivables retrieved.');
        }
        catch (error) {
            CollectionController.handleError(res, error, 'Failed to fetch overdue receivables.');
        }
    }
}
exports.CollectionController = CollectionController;
//# sourceMappingURL=collection.controller.js.map