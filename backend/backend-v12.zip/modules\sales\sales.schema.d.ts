import { z } from 'zod';
export declare const salesQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        customerId: z.ZodOptional<z.ZodString>;
        scope: z.ZodOptional<z.ZodEnum<["sales", "dispatches", "all"]>>;
        isInterBranch: z.ZodOptional<z.ZodEffects<z.ZodEnum<["true", "false"]>, boolean, "false" | "true">>;
        saleType: z.ZodOptional<z.ZodEnum<["WALK_IN", "WHOLESALE", "DISTRIBUTOR"]>>;
        paymentStatus: z.ZodOptional<z.ZodEnum<["PAID", "PARTIAL", "UNPAID"]>>;
        search: z.ZodOptional<z.ZodString>;
        dateFrom: z.ZodOptional<z.ZodString>;
        dateTo: z.ZodOptional<z.ZodString>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        customerId?: string | undefined;
        isInterBranch?: boolean | undefined;
        saleType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        paymentStatus?: "PAID" | "PARTIAL" | "UNPAID" | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
        scope?: "all" | "sales" | "dispatches" | undefined;
    }, {
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        customerId?: string | undefined;
        isInterBranch?: "false" | "true" | undefined;
        saleType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        paymentStatus?: "PAID" | "PARTIAL" | "UNPAID" | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
        scope?: "all" | "sales" | "dispatches" | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        customerId?: string | undefined;
        isInterBranch?: boolean | undefined;
        saleType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        paymentStatus?: "PAID" | "PARTIAL" | "UNPAID" | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
        scope?: "all" | "sales" | "dispatches" | undefined;
    };
}, {
    query: {
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        customerId?: string | undefined;
        isInterBranch?: "false" | "true" | undefined;
        saleType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        paymentStatus?: "PAID" | "PARTIAL" | "UNPAID" | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
        scope?: "all" | "sales" | "dispatches" | undefined;
    };
}>;
export declare const invoiceParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export declare const deleteInvoiceSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodOptional<z.ZodObject<{
        returnStock: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    }, "strip", z.ZodTypeAny, {
        returnStock: boolean;
    }, {
        returnStock?: boolean | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body?: {
        returnStock: boolean;
    } | undefined;
}, {
    params: {
        id: string;
    };
    body?: {
        returnStock?: boolean | undefined;
    } | undefined;
}>;
export type SalesQuery = z.infer<typeof salesQuerySchema>['query'];
