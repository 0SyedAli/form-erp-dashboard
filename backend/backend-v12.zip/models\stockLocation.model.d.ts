import mongoose, { Document } from 'mongoose';
import { StockLocationType } from '../constants/index.js';
export interface IStockLocation extends Document {
    branchId: mongoose.Types.ObjectId;
    code: string;
    name: string;
    type: StockLocationType;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare const StockLocation: mongoose.Model<IStockLocation, {}, {}, {}, mongoose.Document<unknown, {}, IStockLocation, {}, {}> & IStockLocation & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
