"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const auth_service_js_1 = require("./auth.service.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
const env_js_1 = require("../../config/env.js");
class AuthController {
    static async login(req, res) {
        try {
            const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
            const userAgent = req.headers['user-agent'];
            const result = await auth_service_js_1.AuthService.login(req.body, ipAddress, userAgent);
            // Set HttpOnly cookie with strict security flags
            const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https' || env_js_1.env.COOKIE_SECURE;
            res.cookie(auth_middleware_js_1.SESSION_COOKIE_NAME, result.rawToken, {
                httpOnly: true,
                secure: isHttps,
                sameSite: isHttps ? 'none' : 'lax',
                domain: env_js_1.env.COOKIE_DOMAIN && env_js_1.env.COOKIE_DOMAIN !== 'localhost' ? env_js_1.env.COOKIE_DOMAIN : undefined,
                path: '/',
                expires: result.expiresAt,
                maxAge: env_js_1.env.SESSION_TTL_HOURS * 60 * 60 * 1000,
            });
            (0, apiResponse_js_1.sendSuccess)(res, {
                account: result.account,
                expiresAt: result.expiresAt,
                token: result.rawToken,
            }, 'Login successful', 200);
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'An error occurred during authentication.', 500, 'INTERNAL_ERROR');
        }
    }
    static async logout(req, res) {
        try {
            const rawToken = req.cookies?.[auth_middleware_js_1.SESSION_COOKIE_NAME] ||
                req.signedCookies?.[auth_middleware_js_1.SESSION_COOKIE_NAME] ||
                (req.headers.authorization?.startsWith('Bearer ')
                    ? req.headers.authorization.split(' ')[1]
                    : undefined);
            const accountId = req.account?.id;
            if (rawToken) {
                await auth_service_js_1.AuthService.logout(rawToken, accountId);
            }
            const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https' || env_js_1.env.COOKIE_SECURE;
            res.clearCookie(auth_middleware_js_1.SESSION_COOKIE_NAME, {
                httpOnly: true,
                secure: isHttps,
                sameSite: isHttps ? 'none' : 'lax',
                domain: env_js_1.env.COOKIE_DOMAIN && env_js_1.env.COOKIE_DOMAIN !== 'localhost' ? env_js_1.env.COOKIE_DOMAIN : undefined,
                path: '/',
            });
            (0, apiResponse_js_1.sendSuccess)(res, null, 'Logged out successfully');
        }
        catch {
            (0, apiResponse_js_1.sendError)(res, 'Logout failed', 500, 'LOGOUT_ERROR');
        }
    }
    static async me(req, res) {
        try {
            if (!req.account) {
                (0, apiResponse_js_1.sendError)(res, 'Unauthorized', 401, 'UNAUTHORIZED');
                return;
            }
            const profile = await auth_service_js_1.AuthService.getProfile(req.account._id.toString());
            (0, apiResponse_js_1.sendSuccess)(res, profile);
        }
        catch {
            (0, apiResponse_js_1.sendError)(res, 'Failed to fetch current user profile', 500, 'FETCH_PROFILE_ERROR');
        }
    }
    static async changePassword(req, res) {
        try {
            if (!req.account) {
                (0, apiResponse_js_1.sendError)(res, 'Unauthorized', 401, 'UNAUTHORIZED');
                return;
            }
            const rawToken = req.cookies?.[auth_middleware_js_1.SESSION_COOKIE_NAME] ||
                req.signedCookies?.[auth_middleware_js_1.SESSION_COOKIE_NAME] ||
                (req.headers.authorization?.startsWith('Bearer ')
                    ? req.headers.authorization.split(' ')[1]
                    : undefined);
            const result = await auth_service_js_1.AuthService.changePassword(req.account._id.toString(), req.body, rawToken);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Password changed successfully');
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to change password', 500, 'PASSWORD_CHANGE_ERROR');
        }
    }
}
exports.AuthController = AuthController;
//# sourceMappingURL=auth.controller.js.map