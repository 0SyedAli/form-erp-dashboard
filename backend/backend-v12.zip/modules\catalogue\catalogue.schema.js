"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paginationQuerySchema = exports.idParamSchema = exports.statusToggleSchema = exports.updatePricesSchema = exports.updateSkuSchema = exports.createProductWithVariantSchema = exports.updateThicknessSchema = exports.thicknessSchema = exports.updateSizeSchema = exports.sizeSchema = exports.updateProductLineSchema = exports.productLineSchema = exports.updateCategorySchema = exports.categorySchema = exports.updateBrandSchema = exports.brandSchema = void 0;
const zod_1 = require("zod");
exports.brandSchema = zod_1.z.object({
    body: zod_1.z.object({
        code: zod_1.z.string().trim().min(2).max(10).toUpperCase(),
        name: zod_1.z.string().trim().min(2).max(100),
        description: zod_1.z.string().trim().optional(),
        logoUrl: zod_1.z.string().trim().optional().or(zod_1.z.literal('')),
        branchId: zod_1.z.string().optional(),
        hasThickness: zod_1.z.boolean().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.updateBrandSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        code: zod_1.z.string().trim().min(2).max(10).toUpperCase().optional(),
        name: zod_1.z.string().trim().min(2).max(100).optional(),
        description: zod_1.z.string().trim().optional(),
        logoUrl: zod_1.z.string().trim().optional().or(zod_1.z.literal('')),
        branchId: zod_1.z.string().optional(),
        hasThickness: zod_1.z.boolean().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.categorySchema = zod_1.z.object({
    body: zod_1.z.object({
        brandId: zod_1.z.string({ required_error: 'Brand ID is required' }),
        branchId: zod_1.z.string().optional(),
        code: zod_1.z.string().trim().min(2).max(10).toUpperCase(),
        name: zod_1.z.string().trim().min(2).max(100),
        description: zod_1.z.string().trim().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.updateCategorySchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        brandId: zod_1.z.string().optional(),
        branchId: zod_1.z.string().optional(),
        code: zod_1.z.string().trim().min(2).max(10).toUpperCase().optional(),
        name: zod_1.z.string().trim().min(2).max(100).optional(),
        description: zod_1.z.string().trim().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.productLineSchema = zod_1.z.object({
    body: zod_1.z.object({
        brandId: zod_1.z.string({ required_error: 'Brand ID is required' }),
        categoryId: zod_1.z.string({ required_error: 'Category ID is required' }),
        branchId: zod_1.z.string().optional(),
        code: zod_1.z.string().trim().min(2).max(20).toUpperCase(),
        name: zod_1.z.string().trim().min(2).max(100),
        description: zod_1.z.string().trim().optional(),
        imageUrl: zod_1.z.string().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.updateProductLineSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        brandId: zod_1.z.string().optional(),
        categoryId: zod_1.z.string().optional(),
        branchId: zod_1.z.string().optional(),
        code: zod_1.z.string().trim().min(2).max(20).toUpperCase().optional(),
        name: zod_1.z.string().trim().min(2).max(100).optional(),
        description: zod_1.z.string().trim().optional(),
        imageUrl: zod_1.z.string().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.sizeSchema = zod_1.z.object({
    body: zod_1.z.object({
        length: zod_1.z.coerce.number().positive(),
        width: zod_1.z.coerce.number().positive(),
        unit: zod_1.z.string().default('in'),
        displayLabel: zod_1.z.string().trim().min(2),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.updateSizeSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        length: zod_1.z.coerce.number().positive().optional(),
        width: zod_1.z.coerce.number().positive().optional(),
        unit: zod_1.z.string().optional(),
        displayLabel: zod_1.z.string().trim().min(2).optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.thicknessSchema = zod_1.z.object({
    body: zod_1.z.object({
        value: zod_1.z.coerce.number().positive(),
        unit: zod_1.z.string().default('in'),
        displayLabel: zod_1.z.string().trim().min(1),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.updateThicknessSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        value: zod_1.z.coerce.number().positive().optional(),
        unit: zod_1.z.string().optional(),
        displayLabel: zod_1.z.string().trim().min(1).optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
    }),
});
exports.createProductWithVariantSchema = zod_1.z.object({
    body: zod_1.z.object({
        brandId: zod_1.z.string({ required_error: 'Brand is required' }),
        categoryId: zod_1.z.string({ required_error: 'Category is required' }),
        productLineId: zod_1.z.string().optional(),
        sizeId: zod_1.z.string({ required_error: 'Size is required' }),
        thicknessId: zod_1.z.string().optional(),
        // Financials in Rupees
        listPrice: zod_1.z.coerce.number().min(0, 'List Price must be positive'),
        purchasePercent: zod_1.z.coerce.number().min(0).max(100).optional(),
        purchasePrice: zod_1.z.coerce.number().min(0).optional(),
        retailPercent: zod_1.z.coerce.number().min(0).optional(),
        retailPrice: zod_1.z.coerce.number().min(0).optional(),
        wholesalePercent: zod_1.z.coerce.number().min(0).max(100).optional(),
        wholesalePrice: zod_1.z.coerce.number().min(0).optional(),
        distributorPercent: zod_1.z.coerce.number().min(0).max(100).optional(),
        distributorPrice: zod_1.z.coerce.number().min(0).optional(),
        // Initial stock parameters
        stock: zod_1.z.coerce.number().int().min(0).default(0),
        minimumStock: zod_1.z.coerce.number().int().min(0).default(5),
        destinationBranchId: zod_1.z.string().optional(),
        imageUrl: zod_1.z.string().optional(),
    }),
});
exports.updateSkuSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        brandId: zod_1.z.string().optional(),
        categoryId: zod_1.z.string().optional(),
        productLineId: zod_1.z.string().optional(),
        sizeId: zod_1.z.string().optional(),
        thicknessId: zod_1.z.string().optional(),
        imageUrl: zod_1.z.string().optional(),
        listPrice: zod_1.z.coerce.number().min(0).optional(),
        purchasePercent: zod_1.z.coerce.number().min(0).max(100).optional(),
        purchasePrice: zod_1.z.coerce.number().min(0).optional(),
        retailPercent: zod_1.z.coerce.number().min(0).optional(),
        retailPrice: zod_1.z.coerce.number().min(0).optional(),
        wholesalePercent: zod_1.z.coerce.number().min(0).max(100).optional(),
        wholesalePrice: zod_1.z.coerce.number().min(0).optional(),
        distributorPercent: zod_1.z.coerce.number().min(0).max(100).optional(),
        distributorPrice: zod_1.z.coerce.number().min(0).optional(),
        stock: zod_1.z.coerce.number().min(0).optional(),
        minimumStock: zod_1.z.coerce.number().min(0).optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'active', 'inactive']).optional(),
        reason: zod_1.z.string().trim().optional(),
    }),
});
exports.updatePricesSchema = exports.updateSkuSchema;
exports.statusToggleSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
    body: zod_1.z.object({
        status: zod_1.z
            .enum(['ACTIVE', 'INACTIVE', 'active', 'inactive'])
            .transform((val) => val.toUpperCase()),
    }),
});
exports.idParamSchema = zod_1.z.object({
    params: zod_1.z.object({ id: zod_1.z.string() }),
});
exports.paginationQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        page: zod_1.z.coerce.number().int().positive().default(1),
        limit: zod_1.z.coerce.number().int().positive().max(1000).default(500),
        search: zod_1.z.string().trim().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'ALL', 'active', 'inactive', 'all']).default('ACTIVE'),
        brandId: zod_1.z.string().optional(),
        categoryId: zod_1.z.string().optional(),
        productLineId: zod_1.z.string().optional(),
        branchId: zod_1.z.string().optional(),
    }),
});
//# sourceMappingURL=catalogue.schema.js.map