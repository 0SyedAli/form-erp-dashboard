"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierController = void 0;
const supplier_service_js_1 = require("./supplier.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class SupplierController {
    static async createSupplier(req, res, next) {
        try {
            const userContext = {
                id: req.account._id.toString(),
                loginId: req.account.loginId,
                branchId: req.account.branchId?.toString(),
            };
            const data = await supplier_service_js_1.SupplierService.createSupplier(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier created successfully', 201);
        }
        catch (error) {
            next(error);
        }
    }
    static async getSuppliers(req, res, next) {
        try {
            const result = await supplier_service_js_1.SupplierService.getSuppliers(req.query);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Suppliers retrieved successfully');
        }
        catch (error) {
            next(error);
        }
    }
    static async getSupplierById(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.getSupplierById(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier retrieved successfully');
        }
        catch (error) {
            next(error);
        }
    }
    static async updateSupplier(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.updateSupplier(id, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier updated successfully');
        }
        catch (error) {
            next(error);
        }
    }
    static async updateStatus(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.updateStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `Supplier status updated to ${req.body.status}`);
        }
        catch (error) {
            next(error);
        }
    }
    static async getSupplierLedger(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.getSupplierLedger(id, req.query);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier ledger statement retrieved successfully');
        }
        catch (error) {
            next(error);
        }
    }
    static async getSupplierOutstanding(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.getSupplierOutstandingBills(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier outstanding bills retrieved successfully');
        }
        catch (error) {
            next(error);
        }
    }
    static async getSupplierBills(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.getSupplierBills(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier bills retrieved successfully');
        }
        catch (error) {
            next(error);
        }
    }
    static async getSupplierPayments(req, res, next) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await supplier_service_js_1.SupplierService.getSupplierPayments(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier payments retrieved successfully');
        }
        catch (error) {
            next(error);
        }
    }
}
exports.SupplierController = SupplierController;
//# sourceMappingURL=supplier.controller.js.map