import mongoose from 'mongoose';
import { IPurchaseOrder, ISupplierBill } from '../../models/index.js';
import { CreatePOInput, UpdatePOInput, ReceiveOrderInput, CreateSupplierBillInput, CreateSupplierPaymentInput, CreatePurchaseReturnInput, POQuery } from './purchasing.schema.js';
interface UserContext {
    id: string;
    loginId: string;
    role: 'SUPER_ADMIN' | 'BRANCH';
    branchId?: string;
    branchName?: string;
    permissions?: Record<string, boolean>;
}
export declare class PurchasingService {
    /**
     * Generates a date-based sequence code atomically: e.g. PO-YYYYMMDD-0001
     */
    static generateSequentialNumber(prefix: string, session?: mongoose.ClientSession | null): Promise<string>;
    static createPurchaseOrder(input: CreatePOInput, userContext: UserContext): Promise<IPurchaseOrder>;
    static getPurchaseOrders(query: POQuery, userContext: UserContext): Promise<any>;
    static getPurchaseOrderById(id: string, userContext: UserContext): Promise<any>;
    static updatePurchaseOrder(id: string, input: UpdatePOInput, userContext: UserContext): Promise<mongoose.Document<unknown, {}, IPurchaseOrder, {}, {}> & IPurchaseOrder & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static submitPurchaseOrder(id: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, IPurchaseOrder, {}, {}> & IPurchaseOrder & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static approvePurchaseOrder(id: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, IPurchaseOrder, {}, {}> & IPurchaseOrder & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static cancelPurchaseOrder(id: string, reason: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, IPurchaseOrder, {}, {}> & IPurchaseOrder & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static receivePurchaseOrder(orderId: string, input: ReceiveOrderInput, userContext: UserContext): Promise<{
        grn: mongoose.Document<unknown, {}, import("../../models/stockReceipt.model.js").IStockReceipt, {}, {}> & import("../../models/stockReceipt.model.js").IStockReceipt & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        };
        orderStatus: "PARTIALLY_RECEIVED" | "FULLY_RECEIVED";
        acceptedUnits: number;
        quarantineUnits: number;
    }>;
    static createSupplierBill(input: CreateSupplierBillInput, userContext: UserContext): Promise<ISupplierBill>;
    static getSupplierBills(query: {
        supplierId?: string;
        branchId?: string;
        paymentStatus?: string;
        status?: string;
        search?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        bills: (mongoose.FlattenMaps<ISupplierBill> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        pagination: {
            page: number;
            limit: number;
            total: number;
            pages: number;
        };
    }>;
    static createSupplierPayment(input: CreateSupplierPaymentInput, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/supplierPayment.model.js").ISupplierPayment, {}, {}> & import("../../models/supplierPayment.model.js").ISupplierPayment & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static createPurchaseReturn(input: CreatePurchaseReturnInput, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/purchaseReturn.model.js").IPurchaseReturn, {}, {}> & import("../../models/purchaseReturn.model.js").IPurchaseReturn & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static getPurchasingSummary(userContext: UserContext): Promise<{
        totalOrders: number;
        pendingApprovalOrders: number;
        totalGoodsReceipts: number;
        totalBilledAmount: any;
        totalBalanceDue: any;
        totalPaidAmount: any;
        totalOverdueAmount: any;
        overdueBillsCount: any;
        activeSuppliersCount: number;
    }>;
}
export {};
