"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.posRoutes = void 0;
const express_1 = require("express");
const pos_controller_js_1 = require("./pos.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const pos_schema_js_1 = require("./pos.schema.js");
exports.posRoutes = (0, express_1.Router)();
// 0. POS Unified Bootstrap (Single round-trip, lean snapshot)
exports.posRoutes.get('/bootstrap', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), pos_controller_js_1.PosController.getBootstrap);
// 0b. POS Out of Stock Products & Variants (Lazy progressive background load)
exports.posRoutes.get('/out-of-stock', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), pos_controller_js_1.PosController.getOutOfStock);
// 1. POS Catalogue
exports.posRoutes.get('/catalogue', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), pos_controller_js_1.PosController.getCatalogue);
// 2. POS Stock Availability for SKU
exports.posRoutes.get('/products/:skuId/availability', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(pos_schema_js_1.availabilityParamSchema), pos_controller_js_1.PosController.getAvailability);
// 3. Complete Checkout
exports.posRoutes.post('/checkout', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(pos_schema_js_1.checkoutSchema), pos_controller_js_1.PosController.checkout);
// 4. Held Sales
exports.posRoutes.get('/held-sales', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), pos_controller_js_1.PosController.getHeldSales);
exports.posRoutes.post('/held-sales', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(pos_schema_js_1.heldSaleSchema), pos_controller_js_1.PosController.createHeldSale);
exports.posRoutes.post('/held-sales/:id/resume', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(pos_schema_js_1.heldSaleParamSchema), pos_controller_js_1.PosController.resumeHeldSale);
exports.posRoutes.delete('/held-sales/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(pos_schema_js_1.heldSaleParamSchema), pos_controller_js_1.PosController.deleteHeldSale);
//# sourceMappingURL=pos.routes.js.map