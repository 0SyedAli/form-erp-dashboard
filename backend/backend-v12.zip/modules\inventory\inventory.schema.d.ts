import { z } from 'zod';
export declare const stockQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        sku: z.ZodOptional<z.ZodString>;
        search: z.ZodOptional<z.ZodString>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
    }, {
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
        page?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
    };
}, {
    query: {
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
        page?: string | undefined;
    };
}>;
export declare const updateMinimumStockSchema: z.ZodObject<{
    params: z.ZodObject<{
        skuId: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        skuId: string;
    }, {
        skuId: string;
    }>;
    body: z.ZodObject<{
        reorderLevel: z.ZodNumber;
        stockLocationId: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        reorderLevel: number;
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
    }, {
        reorderLevel: number;
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        skuId: string;
    };
    body: {
        reorderLevel: number;
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
    };
}, {
    params: {
        skuId: string;
    };
    body: {
        reorderLevel: number;
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
    };
}>;
export declare const openingStockSchema: z.ZodObject<{
    body: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodString;
        sku: z.ZodString;
        quantity: z.ZodNumber;
        minimumStock: z.ZodOptional<z.ZodNumber>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        sku: string;
        stockLocationId: string;
        quantity: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        minimumStock?: number | undefined;
    }, {
        sku: string;
        stockLocationId: string;
        quantity: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        minimumStock?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        sku: string;
        stockLocationId: string;
        quantity: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        minimumStock?: number | undefined;
    };
}, {
    body: {
        sku: string;
        stockLocationId: string;
        quantity: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        minimumStock?: number | undefined;
    };
}>;
export declare const createStockReceiptSchema: z.ZodObject<{
    body: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        receiptNumber: z.ZodOptional<z.ZodString>;
        supplierId: z.ZodOptional<z.ZodString>;
        supplierReference: z.ZodOptional<z.ZodString>;
        receivedDate: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantityOrdered: z.ZodOptional<z.ZodNumber>;
            quantityReceived: z.ZodNumber;
            unitCost: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            quantityReceived: number;
            quantityOrdered?: number | undefined;
            unitCost?: number | undefined;
        }, {
            sku: string;
            quantityReceived: number;
            quantityOrdered?: number | undefined;
            unitCost?: number | undefined;
        }>, "many">;
        idempotencyKey: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        items: {
            sku: string;
            quantityReceived: number;
            quantityOrdered?: number | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        receiptNumber?: string | undefined;
        supplierId?: string | undefined;
        supplierReference?: string | undefined;
        receivedDate?: string | undefined;
        idempotencyKey?: string | undefined;
    }, {
        items: {
            sku: string;
            quantityReceived: number;
            quantityOrdered?: number | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        receiptNumber?: string | undefined;
        supplierId?: string | undefined;
        supplierReference?: string | undefined;
        receivedDate?: string | undefined;
        idempotencyKey?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        items: {
            sku: string;
            quantityReceived: number;
            quantityOrdered?: number | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        receiptNumber?: string | undefined;
        supplierId?: string | undefined;
        supplierReference?: string | undefined;
        receivedDate?: string | undefined;
        idempotencyKey?: string | undefined;
    };
}, {
    body: {
        items: {
            sku: string;
            quantityReceived: number;
            quantityOrdered?: number | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        receiptNumber?: string | undefined;
        supplierId?: string | undefined;
        supplierReference?: string | undefined;
        receivedDate?: string | undefined;
        idempotencyKey?: string | undefined;
    };
}>;
export declare const createAdjustmentSchema: z.ZodObject<{
    body: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            newPhysicalQuantity: z.ZodNumber;
            adjustmentType: z.ZodDefault<z.ZodOptional<z.ZodEnum<["PHYSICAL_COUNT", "ADMINISTRATIVE", "DAMAGE_WRITE_OFF"]>>>;
            reason: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            reason: string;
            adjustmentType: "PHYSICAL_COUNT" | "ADMINISTRATIVE" | "DAMAGE_WRITE_OFF";
            newPhysicalQuantity: number;
        }, {
            sku: string;
            reason: string;
            newPhysicalQuantity: number;
            adjustmentType?: "PHYSICAL_COUNT" | "ADMINISTRATIVE" | "DAMAGE_WRITE_OFF" | undefined;
        }>, "many">;
        idempotencyKey: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        items: {
            sku: string;
            reason: string;
            adjustmentType: "PHYSICAL_COUNT" | "ADMINISTRATIVE" | "DAMAGE_WRITE_OFF";
            newPhysicalQuantity: number;
        }[];
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
        idempotencyKey?: string | undefined;
    }, {
        items: {
            sku: string;
            reason: string;
            newPhysicalQuantity: number;
            adjustmentType?: "PHYSICAL_COUNT" | "ADMINISTRATIVE" | "DAMAGE_WRITE_OFF" | undefined;
        }[];
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
        idempotencyKey?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        items: {
            sku: string;
            reason: string;
            adjustmentType: "PHYSICAL_COUNT" | "ADMINISTRATIVE" | "DAMAGE_WRITE_OFF";
            newPhysicalQuantity: number;
        }[];
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
        idempotencyKey?: string | undefined;
    };
}, {
    body: {
        items: {
            sku: string;
            reason: string;
            newPhysicalQuantity: number;
            adjustmentType?: "PHYSICAL_COUNT" | "ADMINISTRATIVE" | "DAMAGE_WRITE_OFF" | undefined;
        }[];
        branchId?: string | undefined;
        stockLocationId?: string | undefined;
        idempotencyKey?: string | undefined;
    };
}>;
export declare const createTransferSchema: z.ZodObject<{
    body: z.ZodObject<{
        fromBranchId: z.ZodOptional<z.ZodString>;
        toBranchId: z.ZodString;
        fromStockLocationId: z.ZodString;
        toStockLocationId: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantity: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            quantity: number;
        }, {
            sku: string;
            quantity: number;
        }>, "many">;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        items: {
            sku: string;
            quantity: number;
        }[];
        toBranchId: string;
        fromStockLocationId: string;
        toStockLocationId: string;
        notes?: string | undefined;
        fromBranchId?: string | undefined;
    }, {
        items: {
            sku: string;
            quantity: number;
        }[];
        toBranchId: string;
        fromStockLocationId: string;
        toStockLocationId: string;
        notes?: string | undefined;
        fromBranchId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        items: {
            sku: string;
            quantity: number;
        }[];
        toBranchId: string;
        fromStockLocationId: string;
        toStockLocationId: string;
        notes?: string | undefined;
        fromBranchId?: string | undefined;
    };
}, {
    body: {
        items: {
            sku: string;
            quantity: number;
        }[];
        toBranchId: string;
        fromStockLocationId: string;
        toStockLocationId: string;
        notes?: string | undefined;
        fromBranchId?: string | undefined;
    };
}>;
export declare const transferActionSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodOptional<z.ZodObject<{
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        notes?: string | undefined;
    }, {
        notes?: string | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body?: {
        notes?: string | undefined;
    } | undefined;
}, {
    params: {
        id: string;
    };
    body?: {
        notes?: string | undefined;
    } | undefined;
}>;
export declare const movementsQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        sku: z.ZodOptional<z.ZodString>;
        movementType: z.ZodOptional<z.ZodEnum<[string, ...string[]]>>;
        dateFrom: z.ZodOptional<z.ZodString>;
        dateTo: z.ZodOptional<z.ZodString>;
        search: z.ZodOptional<z.ZodString>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
        movementType?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    }, {
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
        movementType?: string | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
        movementType?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    };
}, {
    query: {
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        stockLocationId?: string | undefined;
        movementType?: string | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    };
}>;
export declare const alertsQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        status: z.ZodDefault<z.ZodOptional<z.ZodEnum<["ALL", "OUT_OF_STOCK", "LOW_STOCK"]>>>;
        brandId: z.ZodOptional<z.ZodString>;
        categoryId: z.ZodOptional<z.ZodString>;
        search: z.ZodOptional<z.ZodString>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        status: "ALL" | "OUT_OF_STOCK" | "LOW_STOCK";
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
    }, {
        status?: "ALL" | "OUT_OF_STOCK" | "LOW_STOCK" | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        page?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        status: "ALL" | "OUT_OF_STOCK" | "LOW_STOCK";
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
    };
}, {
    query: {
        status?: "ALL" | "OUT_OF_STOCK" | "LOW_STOCK" | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        page?: string | undefined;
    };
}>;
export declare const idParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export declare const skuParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        sku: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        sku: string;
    }, {
        sku: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        sku: string;
    };
}, {
    params: {
        sku: string;
    };
}>;
