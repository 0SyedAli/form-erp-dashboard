import mongoose, { Document } from 'mongoose';
export interface ISupplierPaymentAllocation {
    billId: mongoose.Types.ObjectId;
    billNumber: string;
    supplierInvoiceNumber?: string;
    allocatedAmount: number;
    previousDue?: number;
    newDue?: number;
}
export interface ISupplierPayment extends Document {
    paymentNumber: string;
    supplierId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    amount: number;
    paymentMethod: 'CASH' | 'BANK_TRANSFER' | 'CHEQUE' | 'ONLINE' | 'PAYPAK_CARD';
    reference?: string;
    chequeDate?: Date;
    chequeStatus?: 'PENDING_CLEARANCE' | 'CLEARED' | 'BOUNCED';
    allocations: ISupplierPaymentAllocation[];
    unallocatedAdvance: number;
    paidBy: string;
    createdBy?: string;
    notes?: string;
    paymentDate: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const SupplierPayment: mongoose.Model<ISupplierPayment, {}, {}, {}, mongoose.Document<unknown, {}, ISupplierPayment, {}, {}> & ISupplierPayment & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
