import mongoose, { Document } from 'mongoose';
import { CustomerType } from '../constants/index.js';
export interface ICustomer extends Document {
    name: string;
    phone: string;
    customerType: CustomerType;
    businessName?: string;
    email?: string;
    address?: string;
    city?: string;
    taxNumber?: string;
    branchId?: mongoose.Types.ObjectId;
    creditEnabled: boolean;
    creditLimit: number;
    creditTerms: string;
    defaultDueDays: number;
    outstandingBalance: number;
    status: 'ACTIVE' | 'INACTIVE' | 'BLOCKED';
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Customer: mongoose.Model<ICustomer, {}, {}, {}, mongoose.Document<unknown, {}, ICustomer, {}, {}> & ICustomer & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
