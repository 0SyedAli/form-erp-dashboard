"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesController = void 0;
const sales_service_js_1 = require("./sales.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class SalesController {
    static getUserContext(req) {
        return {
            accountId: req.account?._id?.toString() || '',
            loginId: req.account?.loginId || '',
            role: req.account?.role || 'BRANCH',
            branchId: req.account?.branchId?._id?.toString() || req.account?.branchId?.toString(),
        };
    }
    static handleError(res, error, defaultMessage, defaultStatus = 500) {
        const err = error;
        const msg = err.message || defaultMessage;
        const status = err.statusCode || defaultStatus;
        const code = err.code ||
            (status === 404
                ? 'NOT_FOUND'
                : status === 403
                    ? 'FORBIDDEN'
                    : status === 409
                        ? 'CONFLICT'
                        : 'INTERNAL_ERROR');
        (0, apiResponse_js_1.sendError)(res, msg, status, code, err.details);
    }
    static async getInvoices(req, res) {
        try {
            const userContext = SalesController.getUserContext(req);
            const data = await sales_service_js_1.SalesService.getInvoices(req.query, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.invoices, 'Sales invoices retrieved.', 200, data.pagination);
        }
        catch (error) {
            SalesController.handleError(res, error, 'Failed to fetch invoices.');
        }
    }
    static async getInvoiceById(req, res) {
        try {
            const userContext = SalesController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await sales_service_js_1.SalesService.getInvoiceById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Invoice details retrieved.');
        }
        catch (error) {
            SalesController.handleError(res, error, 'Failed to fetch invoice.');
        }
    }
    static async getInvoiceReceipt(req, res) {
        try {
            const userContext = SalesController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await sales_service_js_1.SalesService.getInvoiceReceipt(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Invoice receipt format retrieved.');
        }
        catch (error) {
            SalesController.handleError(res, error, 'Failed to fetch invoice receipt.');
        }
    }
    static async getSalesSummary(req, res) {
        try {
            const userContext = SalesController.getUserContext(req);
            const data = await sales_service_js_1.SalesService.getSalesSummary(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Sales summary retrieved.');
        }
        catch (error) {
            SalesController.handleError(res, error, 'Failed to calculate sales summary.');
        }
    }
    static async deleteInvoice(req, res) {
        try {
            const userContext = SalesController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const returnStock = req.body?.returnStock !== false; // Default to true if omitted
            const result = await sales_service_js_1.SalesService.deleteInvoice(id, { returnStock }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, result, result.message, 200);
        }
        catch (error) {
            SalesController.handleError(res, error, 'Failed to delete/void invoice.');
        }
    }
}
exports.SalesController = SalesController;
//# sourceMappingURL=sales.controller.js.map