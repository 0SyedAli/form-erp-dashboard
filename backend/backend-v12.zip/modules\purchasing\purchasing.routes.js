"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.purchasingRoutes = void 0;
const express_1 = require("express");
const purchasing_controller_js_1 = require("./purchasing.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const purchasing_schema_js_1 = require("./purchasing.schema.js");
exports.purchasingRoutes = (0, express_1.Router)();
// Require authentication and 'purchases' branch permission across all purchasing routes
exports.purchasingRoutes.use(auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('purchases'));
// --- Overview Summary ---
exports.purchasingRoutes.get('/summary', purchasing_controller_js_1.PurchasingController.getPurchasingSummary);
// --- Purchase Orders ---
exports.purchasingRoutes.get('/orders', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.poQuerySchema), purchasing_controller_js_1.PurchasingController.getPurchaseOrders);
exports.purchasingRoutes.post('/orders', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.createPurchaseOrderSchema), purchasing_controller_js_1.PurchasingController.createPurchaseOrder);
exports.purchasingRoutes.get('/orders/:id', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.idParamSchema), purchasing_controller_js_1.PurchasingController.getPurchaseOrderById);
exports.purchasingRoutes.patch('/orders/:id', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.updatePurchaseOrderSchema), purchasing_controller_js_1.PurchasingController.updatePurchaseOrder);
exports.purchasingRoutes.post('/orders/:id/submit', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.idParamSchema), purchasing_controller_js_1.PurchasingController.submitPurchaseOrder);
exports.purchasingRoutes.post('/orders/:id/approve', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.idParamSchema), purchasing_controller_js_1.PurchasingController.approvePurchaseOrder);
exports.purchasingRoutes.post('/orders/:id/cancel', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.idParamSchema), purchasing_controller_js_1.PurchasingController.cancelPurchaseOrder);
// --- Goods Receiving / GRN ---
exports.purchasingRoutes.post('/orders/:id/receive', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.receiveOrderSchema), purchasing_controller_js_1.PurchasingController.receivePurchaseOrder);
// --- Supplier Bills ---
exports.purchasingRoutes.get('/bills', purchasing_controller_js_1.PurchasingController.getSupplierBills);
exports.purchasingRoutes.post('/bills', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.createSupplierBillSchema), purchasing_controller_js_1.PurchasingController.createSupplierBill);
// --- Supplier Payments ---
exports.purchasingRoutes.get('/payments', purchasing_controller_js_1.PurchasingController.getSupplierPayments);
exports.purchasingRoutes.post('/payments', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.createSupplierPaymentSchema), purchasing_controller_js_1.PurchasingController.createSupplierPayment);
// --- Purchase Returns & Debit Notes ---
exports.purchasingRoutes.get('/returns', purchasing_controller_js_1.PurchasingController.getPurchaseReturns);
exports.purchasingRoutes.post('/returns', (0, validateRequest_middleware_js_1.validateRequest)(purchasing_schema_js_1.createPurchaseReturnSchema), purchasing_controller_js_1.PurchasingController.createPurchaseReturn);
//# sourceMappingURL=purchasing.routes.js.map