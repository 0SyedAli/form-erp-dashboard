"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CUSTOMER_TYPES = exports.STOCK_MOVEMENT_TYPES = exports.STOCK_LOCATION_TYPES = exports.INVOICE_STATUSES = exports.PAYMENT_ARRANGEMENTS = exports.PAYMENT_STATUSES = exports.SALE_TYPES = exports.STANDARD_BRANCH_PERMISSIONS = exports.BRANCH_CODES = exports.ACCOUNT_ROLES = void 0;
exports.ACCOUNT_ROLES = {
    SUPER_ADMIN: 'SUPER_ADMIN',
    BRANCH: 'BRANCH',
};
exports.BRANCH_CODES = {
    MAIN: 'SHOP-12-14',
    DISPLAY: 'SHOP-18',
    WHOLESALE: 'SHOP-24-A',
    ORTHO: 'SHOP-06',
    EXPRESS: 'SHOP-31',
};
exports.STANDARD_BRANCH_PERMISSIONS = {
    pos: true,
    viewOwnSales: true,
    viewProducts: false,
    addEditProducts: false,
    viewStock: false,
    manageStock: false,
    stockTransfers: false,
    customers: false,
    customerCredit: false,
    collections: false,
    purchases: false,
    suppliers: false,
    reports: false,
    returns: false,
    discountsOverrides: false,
};
exports.SALE_TYPES = {
    WALK_IN: 'WALK_IN',
    WHOLESALE: 'WHOLESALE',
    DISTRIBUTOR: 'DISTRIBUTOR',
};
exports.PAYMENT_STATUSES = {
    PAID: 'PAID',
    PARTIAL: 'PARTIAL',
    UNPAID: 'UNPAID',
};
exports.PAYMENT_ARRANGEMENTS = {
    FULL: 'FULL',
    PARTIAL: 'PARTIAL',
    CREDIT: 'CREDIT',
    CASH: 'CASH',
    SPLIT: 'SPLIT',
};
exports.INVOICE_STATUSES = {
    DRAFT: 'DRAFT',
    CONFIRMED: 'CONFIRMED',
    VOID: 'VOID',
    REFUNDED: 'REFUNDED',
};
exports.STOCK_LOCATION_TYPES = {
    SALES_FLOOR: 'SALES_FLOOR',
    WAREHOUSE: 'WAREHOUSE',
    BACK_ROOM: 'BACK_ROOM',
    RETURNS_DAMAGED: 'RETURNS_DAMAGED',
};
exports.STOCK_MOVEMENT_TYPES = {
    OPENING_BALANCE: 'OPENING_BALANCE',
    PURCHASE_RECEIPT: 'PURCHASE_RECEIPT',
    SALE_DEDUCTION: 'SALE_DEDUCTION',
    INTER_BRANCH_SALE: 'INTER_BRANCH_SALE',
    TRANSFER_IN: 'TRANSFER_IN',
    TRANSFER_OUT: 'TRANSFER_OUT',
    PHYSICAL_COUNT: 'PHYSICAL_COUNT',
    ADMINISTRATIVE_ADJUSTMENT: 'ADMINISTRATIVE_ADJUSTMENT',
    MANUAL_ADJUSTMENT: 'MANUAL_ADJUSTMENT',
    RETURN_RESTOCK: 'RETURN_RESTOCK',
    PURCHASE_RETURN: 'PURCHASE_RETURN',
};
exports.CUSTOMER_TYPES = {
    WALK_IN: 'WALK_IN',
    WHOLESALE: 'WHOLESALE',
    DISTRIBUTOR: 'DISTRIBUTOR',
    RETAIL: 'RETAIL',
};
//# sourceMappingURL=index.js.map