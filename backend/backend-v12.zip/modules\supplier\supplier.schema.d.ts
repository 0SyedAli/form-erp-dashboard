import { z } from 'zod';
export declare const createSupplierSchema: z.ZodObject<{
    body: z.ZodObject<{
        name: z.ZodString;
        contactPerson: z.ZodOptional<z.ZodString>;
        phone: z.ZodString;
        whatsapp: z.ZodOptional<z.ZodString>;
        email: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
        address: z.ZodOptional<z.ZodString>;
        city: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        ntn: z.ZodOptional<z.ZodString>;
        suppliedBrands: z.ZodDefault<z.ZodOptional<z.ZodArray<z.ZodString, "many">>>;
        creditEnabled: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
        defaultCreditDays: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        paymentTerms: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        creditLimit: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        openingPayable: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        bankName: z.ZodOptional<z.ZodString>;
        bankAccountNumber: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        name: string;
        city: string;
        phone: string;
        creditEnabled: boolean;
        creditLimit: number;
        suppliedBrands: string[];
        defaultCreditDays: number;
        paymentTerms: string;
        openingPayable: number;
        email?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    }, {
        name: string;
        phone: string;
        email?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        suppliedBrands?: string[] | undefined;
        defaultCreditDays?: number | undefined;
        paymentTerms?: string | undefined;
        openingPayable?: number | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        name: string;
        city: string;
        phone: string;
        creditEnabled: boolean;
        creditLimit: number;
        suppliedBrands: string[];
        defaultCreditDays: number;
        paymentTerms: string;
        openingPayable: number;
        email?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    };
}, {
    body: {
        name: string;
        phone: string;
        email?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        suppliedBrands?: string[] | undefined;
        defaultCreditDays?: number | undefined;
        paymentTerms?: string | undefined;
        openingPayable?: number | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    };
}>;
export declare const updateSupplierSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        contactPerson: z.ZodOptional<z.ZodString>;
        phone: z.ZodOptional<z.ZodString>;
        whatsapp: z.ZodOptional<z.ZodString>;
        email: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
        address: z.ZodOptional<z.ZodString>;
        city: z.ZodOptional<z.ZodString>;
        ntn: z.ZodOptional<z.ZodString>;
        suppliedBrands: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        creditEnabled: z.ZodOptional<z.ZodBoolean>;
        defaultCreditDays: z.ZodOptional<z.ZodNumber>;
        paymentTerms: z.ZodOptional<z.ZodString>;
        creditLimit: z.ZodOptional<z.ZodNumber>;
        bankName: z.ZodOptional<z.ZodString>;
        bankAccountNumber: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE"]>>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        suppliedBrands?: string[] | undefined;
        defaultCreditDays?: number | undefined;
        paymentTerms?: string | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        suppliedBrands?: string[] | undefined;
        defaultCreditDays?: number | undefined;
        paymentTerms?: string | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        suppliedBrands?: string[] | undefined;
        defaultCreditDays?: number | undefined;
        paymentTerms?: string | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        contactPerson?: string | undefined;
        whatsapp?: string | undefined;
        ntn?: string | undefined;
        suppliedBrands?: string[] | undefined;
        defaultCreditDays?: number | undefined;
        paymentTerms?: string | undefined;
        bankName?: string | undefined;
        bankAccountNumber?: string | undefined;
    };
}>;
export declare const updateSupplierStatusSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        status: z.ZodEnum<["ACTIVE", "INACTIVE"]>;
    }, "strip", z.ZodTypeAny, {
        status: "ACTIVE" | "INACTIVE";
    }, {
        status: "ACTIVE" | "INACTIVE";
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status: "ACTIVE" | "INACTIVE";
    };
}, {
    params: {
        id: string;
    };
    body: {
        status: "ACTIVE" | "INACTIVE";
    };
}>;
export declare const supplierQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        search: z.ZodOptional<z.ZodString>;
        city: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE"]>>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        status?: "ACTIVE" | "INACTIVE" | undefined;
        search?: string | undefined;
        city?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        city?: string | undefined;
        page?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        status?: "ACTIVE" | "INACTIVE" | undefined;
        search?: string | undefined;
        city?: string | undefined;
    };
}, {
    query: {
        status?: "ACTIVE" | "INACTIVE" | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        city?: string | undefined;
        page?: string | undefined;
    };
}>;
export declare const supplierParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export type CreateSupplierInput = z.infer<typeof createSupplierSchema>['body'];
export type UpdateSupplierInput = z.infer<typeof updateSupplierSchema>['body'];
export type SupplierQuery = z.infer<typeof supplierQuerySchema>['query'];
