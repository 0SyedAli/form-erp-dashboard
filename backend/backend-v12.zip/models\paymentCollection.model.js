"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentCollection = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const CollectionAllocationSchema = new mongoose_1.Schema({
    invoiceId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'SalesInvoice', required: true },
    invoiceNumber: { type: String, required: true },
    allocatedAmount: { type: Number, required: true, min: 1 },
}, { _id: false });
const PaymentCollectionSchema = new mongoose_1.Schema({
    collectionNumber: { type: String, required: true, unique: true, index: true },
    branchId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Branch', required: true, index: true },
    customerId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Customer', required: true, index: true },
    customerName: { type: String, required: true },
    totalCollected: { type: Number, required: true, min: 1 },
    paymentMethod: {
        type: String,
        enum: ['CASH', 'CARD', 'BANK_TRANSFER', 'CHEQUE', 'ONLINE'],
        default: 'CASH',
    },
    reference: { type: String, trim: true },
    allocations: { type: [CollectionAllocationSchema], default: [] },
    unallocatedAmount: { type: Number, default: 0, min: 0 },
    notes: { type: String },
    collectedBy: { type: String, required: true },
    receiptNumber: { type: String, required: true },
    collectionDate: { type: Date, default: Date.now, index: true },
    idempotencyKey: { type: String, unique: true, sparse: true, index: true },
}, { timestamps: true });
PaymentCollectionSchema.index({ branchId: 1, collectionDate: -1 });
exports.PaymentCollection = mongoose_1.default.model('PaymentCollection', PaymentCollectionSchema);
//# sourceMappingURL=paymentCollection.model.js.map