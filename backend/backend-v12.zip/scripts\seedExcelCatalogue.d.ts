export declare function seedExcelCatalogue(): Promise<void>;
