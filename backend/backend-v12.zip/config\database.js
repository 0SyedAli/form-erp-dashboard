"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDatabase = connectDatabase;
exports.disconnectDatabase = disconnectDatabase;
exports.getDatabaseStatus = getDatabaseStatus;
const mongoose_1 = __importDefault(require("mongoose"));
const env_js_1 = require("./env.js");
const logger_js_1 = require("../utils/logger.js");
async function connectDatabase(uri) {
    const targetUri = uri || env_js_1.env.MONGODB_URI;
    mongoose_1.default.connection.on('connected', () => {
        logger_js_1.logger.info({ host: mongoose_1.default.connection.host, db: mongoose_1.default.connection.name }, 'MongoDB connected successfully');
    });
    mongoose_1.default.connection.on('error', (err) => {
        logger_js_1.logger.error({ err }, 'MongoDB connection error occurred');
    });
    mongoose_1.default.connection.on('disconnected', () => {
        logger_js_1.logger.warn('MongoDB connection disconnected');
    });
    try {
        const conn = await mongoose_1.default.connect(targetUri, {
            serverSelectionTimeoutMS: 5000,
            autoIndex: env_js_1.env.NODE_ENV !== 'production',
            maxPoolSize: 20,
            minPoolSize: 2,
        });
        return conn;
    }
    catch (error) {
        logger_js_1.logger.error({ error, uri: targetUri }, 'Failed to establish initial MongoDB connection');
        if (env_js_1.env.NODE_ENV === 'production') {
            process.exit(1);
        }
        throw error;
    }
}
async function disconnectDatabase() {
    if (mongoose_1.default.connection.readyState !== 0) {
        await mongoose_1.default.connection.close();
        logger_js_1.logger.info('MongoDB connection closed gracefully');
    }
}
function getDatabaseStatus() {
    const state = mongoose_1.default.connection.readyState;
    // readyState: 0 = disconnected, 1 = connected, 2 = connecting, 3 = disconnecting
    const isConnected = state === 1;
    const client = isConnected ? mongoose_1.default.connection.getClient() : null;
    const topologyType = (client?.topology?.description?.type || client?.topology?.s?.description?.type || '');
    const isReplicaSet = Boolean(topologyType.includes('ReplicaSet') ||
        client?.topology?.description?.setName ||
        Boolean(client?.options?.replicaSet));
    return {
        connected: isConnected,
        readyState: state,
        host: isConnected ? mongoose_1.default.connection.host : undefined,
        name: isConnected ? mongoose_1.default.connection.name : undefined,
        isReplicaSet,
    };
}
//# sourceMappingURL=database.js.map