"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateRequest = validateRequest;
const zod_1 = require("zod");
const apiResponse_js_1 = require("../utils/apiResponse.js");
function validateRequest(schema) {
    return async (req, res, next) => {
        try {
            const parsed = await schema.parseAsync({
                body: req.body,
                query: req.query,
                params: req.params,
            });
            // Replace with validated/sanitized data
            req.body = parsed.body ?? req.body;
            req.query = parsed.query ?? req.query;
            req.params = parsed.params ?? req.params;
            next();
        }
        catch (error) {
            if (error instanceof zod_1.ZodError) {
                const formatted = error.errors.map((e) => ({
                    field: e.path.join('.').replace(/^(body|query|params)\./, ''),
                    message: e.message,
                }));
                (0, apiResponse_js_1.sendError)(res, 'Validation failed for request input', 400, 'VALIDATION_ERROR', formatted);
                return;
            }
            next(error);
        }
    };
}
//# sourceMappingURL=validateRequest.middleware.js.map