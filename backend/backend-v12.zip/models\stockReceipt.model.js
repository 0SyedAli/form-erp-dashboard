"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockReceipt = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const ReceiptItemSchema = new mongoose_1.Schema({
    sku: { type: String, required: true },
    variantId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Variant' },
    productName: { type: String },
    sizeLabel: { type: String },
    thicknessLabel: { type: String },
    quantityOrdered: { type: Number, required: true, min: 1 },
    quantityReceived: { type: Number, required: true, min: 0 },
    damagedQuantity: { type: Number, default: 0, min: 0 },
    unitCost: { type: Number, required: true, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
}, { _id: false });
const StockReceiptSchema = new mongoose_1.Schema({
    receiptNumber: {
        type: String,
        required: true,
        unique: true,
        index: true,
    },
    purchaseOrderId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'PurchaseOrder',
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    supplierId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Supplier',
        required: false,
        index: true,
    },
    supplierReference: {
        type: String,
        trim: true,
    },
    stockLocationId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'StockLocation',
        required: true,
        index: true,
    },
    items: [ReceiptItemSchema],
    totalQuantity: {
        type: Number,
        required: true,
        min: 1,
    },
    totalCost: {
        type: Number,
        required: true,
        min: 0,
    },
    receivedBy: {
        type: String,
        required: true,
    },
    receivedDate: {
        type: Date,
        default: Date.now,
        index: true,
    },
    status: {
        type: String,
        enum: ['COMPLETED', 'PARTIAL', 'CANCELLED'],
        default: 'COMPLETED',
    },
    notes: {
        type: String,
    },
}, {
    timestamps: true,
});
exports.StockReceipt = mongoose_1.default.model('StockReceipt', StockReceiptSchema);
//# sourceMappingURL=stockReceipt.model.js.map