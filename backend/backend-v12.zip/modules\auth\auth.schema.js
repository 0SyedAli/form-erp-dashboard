"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.changePasswordSchema = exports.loginSchema = void 0;
const zod_1 = require("zod");
exports.loginSchema = zod_1.z.object({
    body: zod_1.z.object({
        loginId: zod_1.z
            .string({ required_error: 'Login ID is required' })
            .trim()
            .min(3, 'Login ID must be at least 3 characters'),
        password: zod_1.z
            .string({ required_error: 'Password is required' })
            .min(4, 'Password must be at least 4 characters'),
    }),
});
exports.changePasswordSchema = zod_1.z.object({
    body: zod_1.z.object({
        currentPassword: zod_1.z.string({ required_error: 'Current password is required' }).min(1),
        newPassword: zod_1.z
            .string({ required_error: 'New password is required' })
            .min(6, 'New password must be at least 6 characters'),
    }),
});
//# sourceMappingURL=auth.schema.js.map