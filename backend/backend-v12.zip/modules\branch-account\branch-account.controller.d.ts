import { Request, Response } from 'express';
export declare class BranchAccountController {
    static getAccount(req: Request, res: Response): Promise<void>;
    static createAccount(req: Request, res: Response): Promise<void>;
    static updateAccount(req: Request, res: Response): Promise<void>;
    static resetPassword(req: Request, res: Response): Promise<void>;
    static updatePermissions(req: Request, res: Response): Promise<void>;
    static deactivateAccount(req: Request, res: Response): Promise<void>;
    static createBranch(req: Request, res: Response): Promise<void>;
    static updateBranch(req: Request, res: Response): Promise<void>;
}
