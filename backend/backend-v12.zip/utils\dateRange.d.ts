/**
 * Asia/Karachi (UTC+5) Timezone Date Range Utility for Financial & ERP Reporting
 */
export type DateRangePreset = 'today' | 'yesterday' | 'last7days' | 'thisMonth' | 'lastMonth' | 'custom' | 'all';
export interface DateRangeResult {
    start?: Date;
    end?: Date;
    preset: DateRangePreset;
    label: string;
}
/**
 * Calculates start (inclusive) and end (exclusive) UTC Date objects for reporting presets in Asia/Karachi.
 */
export declare function resolveDateRange(preset?: DateRangePreset, customStart?: string, customEnd?: string, referenceNow?: Date): DateRangeResult;
