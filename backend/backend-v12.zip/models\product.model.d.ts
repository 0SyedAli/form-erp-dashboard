import mongoose, { Document } from 'mongoose';
export interface IProduct extends Document {
    brandId: mongoose.Types.ObjectId;
    categoryId: mongoose.Types.ObjectId;
    productLineId?: mongoose.Types.ObjectId;
    name: string;
    posDisplayName?: string;
    description?: string;
    imageUrl?: string;
    branchId?: mongoose.Types.ObjectId;
    status: 'ACTIVE' | 'INACTIVE';
    createdAt: Date;
    updatedAt: Date;
}
export declare const Product: mongoose.Model<IProduct, {}, {}, {}, mongoose.Document<unknown, {}, IProduct, {}, {}> & IProduct & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
