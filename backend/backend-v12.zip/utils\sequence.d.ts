import { ClientSession } from 'mongoose';
export declare function generateDailySequence(prefix: string, session?: ClientSession | null, date?: Date): Promise<string>;
