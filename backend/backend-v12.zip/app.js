"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = createApp;
const express_1 = __importDefault(require("express"));
const helmet_1 = __importDefault(require("helmet"));
const cors_1 = __importDefault(require("cors"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const compression_1 = __importDefault(require("compression"));
const swagger_ui_express_1 = __importDefault(require("swagger-ui-express"));
const env_js_1 = require("./config/env.js");
const logger_middleware_js_1 = require("./middleware/logger.middleware.js");
const rateLimiter_middleware_js_1 = require("./middleware/rateLimiter.middleware.js");
const csrf_middleware_js_1 = require("./middleware/csrf.middleware.js");
const errorHandler_middleware_js_1 = require("./middleware/errorHandler.middleware.js");
const apiResponse_js_1 = require("./utils/apiResponse.js");
const swagger_js_1 = require("./docs/swagger.js");
const health_routes_js_1 = require("./modules/health/health.routes.js");
const auth_routes_js_1 = require("./modules/auth/auth.routes.js");
const branch_account_routes_js_1 = require("./modules/branch-account/branch-account.routes.js");
const catalogue_routes_js_1 = require("./modules/catalogue/catalogue.routes.js");
const inventory_routes_js_1 = require("./modules/inventory/inventory.routes.js");
const pos_routes_js_1 = require("./modules/pos/pos.routes.js");
const sales_routes_js_1 = require("./modules/sales/sales.routes.js");
const customer_routes_js_1 = require("./modules/customer/customer.routes.js");
const collection_routes_js_1 = require("./modules/collection/collection.routes.js");
const supplier_routes_js_1 = require("./modules/supplier/supplier.routes.js");
const purchasing_routes_js_1 = require("./modules/purchasing/purchasing.routes.js");
const reporting_routes_js_1 = require("./modules/reporting/reporting.routes.js");
function createApp() {
    const app = (0, express_1.default)();
    // 0. Response Compression (gzip / deflate / brotli) - Reduces payloads by up to 90%
    app.use((0, compression_1.default)());
    // 1. Security Headers
    app.use((0, helmet_1.default)({
        contentSecurityPolicy: env_js_1.env.NODE_ENV === 'production' ? undefined : false,
    }));
    // 2. CORS Configuration
    app.use((0, cors_1.default)({
        origin: (origin, callback) => {
            if (!origin)
                return callback(null, true);
            const isLocalhost = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
            const isPredemo = /^https?:\/\/([a-z0-9-]+\.)*predemo\.site(:\d+)?$/i.test(origin);
            const isAllowedConfig = env_js_1.env.CORS_ORIGINS.includes(origin) ||
                env_js_1.env.CORS_ORIGINS.includes('*') ||
                origin === env_js_1.env.FRONTEND_URL;
            if (env_js_1.env.NODE_ENV === 'development' ||
                isLocalhost ||
                isPredemo ||
                isAllowedConfig) {
                return callback(null, true);
            }
            // Fallback: reflect the origin to prevent CORS blocking for user's domain
            return callback(null, true);
        },
        credentials: true,
        methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Idempotency-Key', 'Accept'],
    }));
    // 3. Body & Cookie Parsing
    app.use(express_1.default.json({ limit: '10mb' }));
    app.use(express_1.default.urlencoded({ extended: true, limit: '10mb' }));
    app.use((0, cookie_parser_1.default)(env_js_1.env.SESSION_SECRET));
    // 4. Request Logging & Rate Limiting
    if (env_js_1.env.NODE_ENV !== 'test') {
        app.use(logger_middleware_js_1.httpLogger);
    }
    app.use('/api', rateLimiter_middleware_js_1.standardRateLimiter);
    // 5. CSRF Protection for Cookie-Authenticated State-Changing Routes
    app.use(csrf_middleware_js_1.validateCsrf);
    // 6. OpenAPI Swagger Documentation
    app.use('/api/v1/docs', swagger_ui_express_1.default.serve, swagger_ui_express_1.default.setup(swagger_js_1.openApiSpec));
    app.get('/api/v1/docs.json', (_req, res) => {
        res.json(swagger_js_1.openApiSpec);
    });
    // 7. API v1 Routes
    const apiV1 = express_1.default.Router();
    apiV1.use(health_routes_js_1.healthRoutes);
    apiV1.use('/auth', auth_routes_js_1.authRoutes);
    apiV1.use('/admin', branch_account_routes_js_1.branchAccountRoutes);
    apiV1.use(catalogue_routes_js_1.catalogueRoutes);
    apiV1.use('/inventory', inventory_routes_js_1.inventoryRoutes);
    apiV1.use('/pos', pos_routes_js_1.posRoutes);
    apiV1.use('/sales', sales_routes_js_1.salesRoutes);
    apiV1.use('/customers', customer_routes_js_1.customerRoutes);
    apiV1.use('/collections', collection_routes_js_1.collectionRoutes);
    apiV1.use('/suppliers', supplier_routes_js_1.supplierRoutes);
    apiV1.use('/purchases', purchasing_routes_js_1.purchasingRoutes);
    apiV1.use('/reports', reporting_routes_js_1.reportingRoutes);
    app.use('/api/v1', apiV1);
    // 8. Root Redirect or info
    app.get('/', (_req, res) => {
        res.json({
            name: 'Molty Foam ERP Backend API',
            version: '1.0.0',
            documentation: '/api/v1/docs',
            health: '/api/v1/health',
        });
    });
    // 9. 404 Route Handler
    app.use((req, res) => {
        (0, apiResponse_js_1.sendError)(res, `Route not found: ${req.method} ${req.originalUrl}`, 404, 'NOT_FOUND');
    });
    // 10. Central Error Handler Middleware
    app.use(errorHandler_middleware_js_1.errorHandler);
    return app;
}
//# sourceMappingURL=app.js.map