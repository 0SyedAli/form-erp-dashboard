import mongoose, { Document } from 'mongoose';
export interface ICollectionAllocation {
    invoiceId: mongoose.Types.ObjectId;
    invoiceNumber: string;
    allocatedAmount: number;
}
export interface IPaymentCollection extends Document {
    collectionNumber: string;
    branchId: mongoose.Types.ObjectId;
    customerId: mongoose.Types.ObjectId;
    customerName: string;
    totalCollected: number;
    paymentMethod: 'CASH' | 'CARD' | 'BANK_TRANSFER' | 'CHEQUE' | 'ONLINE';
    reference?: string;
    allocations: ICollectionAllocation[];
    unallocatedAmount: number;
    notes?: string;
    collectedBy: string;
    receiptNumber: string;
    collectionDate: Date;
    idempotencyKey?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PaymentCollection: mongoose.Model<IPaymentCollection, {}, {}, {}, mongoose.Document<unknown, {}, IPaymentCollection, {}, {}> & IPaymentCollection & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
