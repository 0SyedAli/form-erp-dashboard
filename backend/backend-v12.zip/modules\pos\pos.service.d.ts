import mongoose from 'mongoose';
import { CheckoutInput, HeldSaleInput } from './pos.schema.js';
export interface UserContext {
    accountId: string;
    loginId: string;
    role: 'SUPER_ADMIN' | 'BRANCH';
    branchId?: string;
    name?: string;
    permissions?: Record<string, boolean>;
}
export declare class PosService {
    private static posBootstrapCache;
    private static posOutOfStockCache;
    static invalidatePOSCache(): void;
    /**
     * 0. UNIFIED POS BOOTSTRAP (STAGE 1: FAST IN-STOCK ONLY)
     * Single-roundtrip, lean, high-performance bootstrap endpoint for POS.
     * Returns branches, brands, all active categories, product lines, sizes, thicknesses,
     * in-stock products, in-stock variants, and stock balances in ultra-light ~15 KB payload.
     */
    static getPOSBootstrap(branchId?: string, clientVersionHash?: string): Promise<any>;
    /**
     * 0b. POS OUT OF STOCK CATALOGUE (STAGE 2: LAZY LOADED IN BACKGROUND)
     * Fetches the products and variants that currently have 0 on-hand stock.
     * Runs seamlessly in the background after bootstrap so the UI never blocks.
     */
    static getPOSOutOfStockCatalogue(userContext?: UserContext, branchId?: string): Promise<any>;
    /**
     * 1. GET POS CATALOGUE
     * Returns active brands, categories, sizes, thicknesses, products and active variants
     * with prices formatted for POS and sensitive purchase prices stripped.
     */
    static getPOSCatalogue(userContext: UserContext): Promise<{
        brands: (mongoose.FlattenMaps<import("../../models/brand.model.js").IBrand> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        categories: (mongoose.FlattenMaps<import("../../models/category.model.js").ICategory> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        sizes: (mongoose.FlattenMaps<import("../../models/size.model.js").ISize> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        thicknesses: (mongoose.FlattenMaps<import("../../models/thickness.model.js").IThickness> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        products: (mongoose.FlattenMaps<import("../../models/product.model.js").IProduct> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        variants: {
            id: any;
            productId: any;
            sku: any;
            productName: any;
            sizeLabel: any;
            thicknessLabel: any;
            retailPrice: number;
            wholesalePrice: number;
            distributorPrice: number;
            listPrice: number;
        }[];
    }>;
    /**
     * 2. GET SKU STOCK AVAILABILITY FOR POS
     * Accessible by POS cashier accounts without warehouse viewStock permission.
     */
    static getSkuAvailability(skuOrId: string, userContext: UserContext): Promise<{
        sku: string;
        branchId: string;
        onHand: number;
        reserved: number;
        available: number;
    }>;
    /**
     * 3. ATOMIC POS CHECKOUT
     * Single authoritative financial and inventory transaction:
     * - Authoritative price lookup from DB (ignoring client unitPrice)
     * - Integer-paisa financial calculations
     * - Concurrency-safe atomic stock deduction with $gte conditional check
     * - Customer credit limit enforcement and audit logging
     * - Immutable SalesInvoice and StockMovement creation
     * - Customer ledger posting and receivables update
     */
    static checkout(input: CheckoutInput, userContext: UserContext): Promise<{
        invoice: mongoose.Document<unknown, {}, import("../../models/salesInvoice.model.js").ISalesInvoice, {}, {}> & import("../../models/salesInvoice.model.js").ISalesInvoice & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        };
        message: string;
        isReplay: boolean;
    }>;
    /**
     * 4. HELD SALES MANAGEMENT
     */
    static getHeldSales(userContext: UserContext): Promise<(mongoose.FlattenMaps<import("../../models/heldSale.model.js").IHeldSale> & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    })[]>;
    static createHeldSale(input: HeldSaleInput, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/heldSale.model.js").IHeldSale, {}, {}> & import("../../models/heldSale.model.js").IHeldSale & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static deleteHeldSale(id: string, userContext: UserContext): Promise<{
        success: boolean;
        message: string;
    }>;
    static resumeHeldSale(id: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/heldSale.model.js").IHeldSale, {}, {}> & import("../../models/heldSale.model.js").IHeldSale & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
}
