export declare function cleanAndSeedCatalogue(): Promise<void>;
