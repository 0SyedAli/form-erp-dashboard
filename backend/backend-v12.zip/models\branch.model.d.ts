import mongoose, { Document } from 'mongoose';
import { BranchPermissions } from '../constants/index.js';
export interface IBranch extends Document {
    code: string;
    name: string;
    shopNumber: string;
    type: string;
    city: string;
    address: string;
    phone: string;
    loginId: string;
    targetMonthlySales: number;
    permissions: BranchPermissions;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Branch: mongoose.Model<IBranch, {}, {}, {}, mongoose.Document<unknown, {}, IBranch, {}, {}> & IBranch & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
