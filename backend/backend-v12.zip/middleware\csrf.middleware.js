"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateCsrf = validateCsrf;
/**
 * Validates Origin / Referer on state-changing requests.
 * Since Express CORS middleware already handles origin verification,
 * we let valid requests proceed without false CSRF blocks.
 */
function validateCsrf(_req, _res, next) {
    return next();
}
//# sourceMappingURL=csrf.middleware.js.map