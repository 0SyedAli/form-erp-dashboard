import mongoose, { Document } from 'mongoose';
export interface IThickness extends Document {
    value: number;
    unit: string;
    displayLabel: string;
    status: 'ACTIVE' | 'INACTIVE';
    createdAt: Date;
    updatedAt: Date;
}
export declare const Thickness: mongoose.Model<IThickness, {}, {}, {}, mongoose.Document<unknown, {}, IThickness, {}, {}> & IThickness & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
