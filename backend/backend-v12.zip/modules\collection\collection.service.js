"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionService = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const index_js_1 = require("../../models/index.js");
const index_js_2 = require("../../constants/index.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
const transaction_js_1 = require("../../utils/transaction.js");
const sequence_js_1 = require("../../utils/sequence.js");
class CollectionService {
    /**
     * 1. CREATE PAYMENT COLLECTION & ALLOCATE TO INVOICES
     * Runs in an atomic multi-document transaction:
     * - Validates customer & outstanding balances
     * - Allocates collection (manually or oldest-first)
     * - Updates invoice payment statuses
     * - Reduces customer outstanding balance
     * - Posts credit to customer ledger
     * - Generates durable collection receipt
     */
    static async createCollection(input, userContext) {
        return await (0, transaction_js_1.runTransaction)(async (session) => {
            // 1. Idempotency Check
            if (input.idempotencyKey) {
                const existingCol = await index_js_1.PaymentCollection.findOne({
                    idempotencyKey: input.idempotencyKey,
                }).session(session);
                if (existingCol) {
                    return {
                        collection: existingCol,
                        message: 'Idempotent replay: original collection record returned.',
                        isReplay: true,
                    };
                }
            }
            // 2. Find Customer
            const customer = await index_js_1.Customer.findById(input.customerId).session(session);
            if (!customer) {
                throw new apiResponse_js_1.AppError('Customer not found.', 404, 'CUSTOMER_NOT_FOUND');
            }
            // 3. Resolve Branch & Enforce Strict Branch Boundary
            let effectiveBranchId = null;
            const explicitBranchStr = (userContext.branchId && userContext.branchId !== 'ALL' ? userContext.branchId : undefined) ||
                (input.branchId && input.branchId !== 'ALL' ? input.branchId : undefined);
            if (explicitBranchStr && mongoose_1.default.Types.ObjectId.isValid(explicitBranchStr)) {
                effectiveBranchId = new mongoose_1.default.Types.ObjectId(explicitBranchStr);
            }
            else if (customer.branchId && mongoose_1.default.Types.ObjectId.isValid(customer.branchId.toString())) {
                effectiveBranchId = new mongoose_1.default.Types.ObjectId(customer.branchId.toString());
            }
            else {
                // Fallback for Super Admin / HQ users or unpinned accounts:
                // Priority 1: Check if the customer has an open invoice with balanceDue > 0 at any branch
                const custInvoice = await index_js_1.SalesInvoice.findOne({
                    customerId: customer._id,
                    balanceDue: { $gt: 0 },
                }).session(session);
                if (custInvoice && custInvoice.branchId) {
                    effectiveBranchId = custInvoice.branchId;
                }
                else {
                    // Priority 2: Check any past invoice for this customer
                    const pastInvoice = await index_js_1.SalesInvoice.findOne({
                        customerId: customer._id,
                    })
                        .sort({ createdAt: -1 })
                        .session(session);
                    if (pastInvoice && pastInvoice.branchId) {
                        effectiveBranchId = pastInvoice.branchId;
                    }
                    else {
                        // Priority 3: Main or active branch
                        const defaultBranch = await index_js_1.Branch.findOne({ isActive: true })
                            .sort({ isMain: -1, createdAt: 1 })
                            .session(session);
                        if (defaultBranch) {
                            effectiveBranchId = defaultBranch._id;
                        }
                        else {
                            const anyBranch = await index_js_1.Branch.findOne().session(session);
                            if (anyBranch) {
                                effectiveBranchId = anyBranch._id;
                            }
                        }
                    }
                }
            }
            if (!effectiveBranchId) {
                throw new apiResponse_js_1.AppError('Branch assignment required for recording payment collections.', 403, 'NO_BRANCH_ASSIGNED');
            }
            // If customer was not yet bound to a branch, bind them to this branch
            if (!customer.branchId) {
                customer.branchId = effectiveBranchId;
            }
            // 4. Find open invoices with balanceDue > 0
            let openInvoices = await index_js_1.SalesInvoice.find({
                customerId: customer._id,
                branchId: effectiveBranchId,
                balanceDue: { $gt: 0 },
            })
                .sort({ createdAt: 1 }) // FIFO / Oldest first
                .session(session);
            // If user is SUPER_ADMIN and no open invoices found at the initially resolved branch,
            // fallback to customer's open invoices at other branches
            if (openInvoices.length === 0 && userContext.role === 'SUPER_ADMIN') {
                const anyBranchInvoices = await index_js_1.SalesInvoice.find({
                    customerId: customer._id,
                    balanceDue: { $gt: 0 },
                })
                    .sort({ createdAt: 1 })
                    .session(session);
                if (anyBranchInvoices.length > 0) {
                    openInvoices = anyBranchInvoices;
                    effectiveBranchId = anyBranchInvoices[0].branchId;
                }
            }
            const totalBranchOutstanding = openInvoices.reduce((sum, inv) => sum + inv.balanceDue, 0);
            // Branch Isolation Guard: A branch user cannot collect payments for a customer assigned to another branch
            const isCustomerAssignedToBranch = customer.branchId && customer.branchId.toString() === effectiveBranchId.toString();
            if (!isCustomerAssignedToBranch && userContext.role !== 'SUPER_ADMIN' && totalBranchOutstanding === 0) {
                throw new apiResponse_js_1.AppError(`Customer ${customer.name} belongs to another branch. Cross-branch collection is strictly prohibited.`, 403, 'FORBIDDEN_CROSS_BRANCH_COLLECTION');
            }
            // 5. Determine Allocations
            let remainingToAllocate = input.amount;
            const finalAllocations = [];
            if (input.allocations && input.allocations.length > 0) {
                // Manual allocation
                let manualSum = 0;
                for (const alloc of input.allocations) {
                    const inv = openInvoices.find((i) => i._id.toString() === alloc.invoiceId);
                    if (!inv) {
                        throw new apiResponse_js_1.AppError(`Invoice ${alloc.invoiceId} does not belong to this branch or has no balance due. Cross-branch collection is strictly prohibited.`, 403, 'FORBIDDEN_CROSS_BRANCH_COLLECTION');
                    }
                    if (alloc.allocatedAmount > inv.balanceDue) {
                        throw new apiResponse_js_1.AppError(`Allocation of Rs. ${alloc.allocatedAmount} exceeds invoice #${inv.invoiceNumber} balance due of Rs. ${inv.balanceDue}.`, 400, 'OVER_ALLOCATION_ON_INVOICE');
                    }
                    manualSum += alloc.allocatedAmount;
                    finalAllocations.push({
                        invoiceId: inv._id,
                        invoiceNumber: inv.invoiceNumber,
                        allocatedAmount: alloc.allocatedAmount,
                    });
                }
                if (manualSum > input.amount) {
                    throw new apiResponse_js_1.AppError(`Total manual invoice allocations (Rs. ${manualSum}) exceed collection amount (Rs. ${input.amount}).`, 400, 'TOTAL_ALLOCATION_EXCEEDS_COLLECTION');
                }
                remainingToAllocate = input.amount - manualSum;
            }
            else {
                // Automatic oldest-invoice-first FIFO allocation
                for (const inv of openInvoices) {
                    if (remainingToAllocate <= 0)
                        break;
                    const allocAmount = Math.min(remainingToAllocate, inv.balanceDue);
                    finalAllocations.push({
                        invoiceId: inv._id,
                        invoiceNumber: inv.invoiceNumber,
                        allocatedAmount: allocAmount,
                    });
                    remainingToAllocate -= allocAmount;
                }
            }
            // 6. Update Each Allocated Invoice
            let totalAppliedToInvoices = 0;
            for (const alloc of finalAllocations) {
                totalAppliedToInvoices += alloc.allocatedAmount;
                const inv = openInvoices.find((i) => i._id.toString() === alloc.invoiceId.toString());
                if (inv) {
                    inv.paidAmount += alloc.allocatedAmount;
                    inv.balanceDue = Math.max(0, inv.balanceDue - alloc.allocatedAmount);
                    inv.paymentStatus = inv.balanceDue === 0 ? index_js_2.PAYMENT_STATUSES.PAID : index_js_2.PAYMENT_STATUSES.PARTIAL;
                    await inv.save({ session });
                }
            }
            // 7. Update Customer Outstanding Balance
            const previousOutstanding = customer.outstandingBalance || 0;
            const amountToReduce = Math.min(previousOutstanding, Math.max(totalAppliedToInvoices, input.amount));
            const newOutstanding = Math.max(0, previousOutstanding - amountToReduce);
            customer.outstandingBalance = newOutstanding;
            await customer.save({ session });
            // 8. Generate Sequential Collection Reference & Receipt
            const collectionNumber = await (0, sequence_js_1.generateDailySequence)('COL', session);
            const receiptNumber = await (0, sequence_js_1.generateDailySequence)('RCP', session);
            // 9. Post Customer Ledger Entry (reduces receivable)
            await index_js_1.CustomerLedgerEntry.create([
                {
                    customerId: customer._id,
                    branchId: effectiveBranchId,
                    entryType: 'PAYMENT',
                    referencePaymentId: collectionNumber,
                    debit: 0,
                    credit: input.amount,
                    runningBalance: newOutstanding,
                    narration: `Payment Collection #${collectionNumber} (${input.paymentMethod}) - Received: Rs. ${input.amount.toLocaleString()}, Allocated to ${finalAllocations.length} invoices`,
                    performedBy: userContext.loginId,
                    timestamp: new Date(),
                },
            ], { session });
            // 10. Record Payment Collection Document
            const [collection] = await index_js_1.PaymentCollection.create([
                {
                    collectionNumber,
                    branchId: effectiveBranchId,
                    customerId: customer._id,
                    customerName: customer.name,
                    totalCollected: input.amount,
                    paymentMethod: input.paymentMethod,
                    reference: input.reference,
                    allocations: finalAllocations,
                    unallocatedAmount: remainingToAllocate,
                    notes: input.notes,
                    collectedBy: userContext.loginId,
                    receiptNumber,
                    collectionDate: new Date(),
                    idempotencyKey: input.idempotencyKey,
                },
            ], { session });
            // 11. Create Standard Payment Record for Cash/Bank Book
            const paymentDocNumber = await (0, sequence_js_1.generateDailySequence)('PAY', session);
            await index_js_1.Payment.create([
                {
                    paymentNumber: paymentDocNumber,
                    customerId: customer._id,
                    branchId: effectiveBranchId,
                    amount: input.amount,
                    paymentMethod: input.paymentMethod,
                    reference: collectionNumber,
                    notes: `Customer debt recovery collection ${collectionNumber}`,
                    collectedBy: userContext.loginId,
                    paymentDate: new Date(),
                },
            ], { session });
            // 12. Persist Idempotency Store
            if (input.idempotencyKey) {
                await index_js_1.IdempotencyKey.create([
                    {
                        key: input.idempotencyKey,
                        endpoint: '/collections',
                        responseStatus: 201,
                        responseBody: { collectionNumber },
                        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
                    },
                ], { session });
            }
            const collectionObj = collection.toObject();
            return {
                collection: {
                    ...collectionObj,
                    id: collection._id.toString(),
                    amount: collection.totalCollected,
                    unallocatedAdvance: collection.unallocatedAmount || 0,
                },
                id: collection._id.toString(),
                collectionNumber: collection.collectionNumber,
                receiptNumber: collection.receiptNumber,
                amount: collection.totalCollected,
                totalCollected: collection.totalCollected,
                unallocatedAdvance: collection.unallocatedAmount || 0,
                unallocatedAmount: remainingToAllocate,
                appliedAmount: totalAppliedToInvoices,
                newCustomerOutstanding: newOutstanding,
                message: 'Payment collection recorded and allocated successfully.',
                isReplay: false,
            };
        });
    }
    /**
     * 2. LIST COLLECTIONS WITH FILTERS
     */
    static async getCollections(query, userContext) {
        const page = Math.max(1, query.page || 1);
        const limit = Math.max(1, Math.min(100, query.limit || 20));
        const skip = (page - 1) * limit;
        const filter = {};
        if (userContext.role !== 'SUPER_ADMIN') {
            if (userContext.branchId) {
                filter.branchId = new mongoose_1.default.Types.ObjectId(userContext.branchId);
            }
        }
        else if (query.branchId && query.branchId !== 'ALL') {
            filter.branchId = new mongoose_1.default.Types.ObjectId(query.branchId);
        }
        if (query.customerId && query.customerId !== 'ALL') {
            filter.customerId = new mongoose_1.default.Types.ObjectId(query.customerId);
        }
        if (query.dateFrom || query.dateTo) {
            const dateFilter = {};
            if (query.dateFrom)
                dateFilter.$gte = new Date(query.dateFrom);
            if (query.dateTo) {
                const to = new Date(query.dateTo);
                to.setHours(23, 59, 59, 999);
                dateFilter.$lte = to;
            }
            filter.collectionDate = dateFilter;
        }
        const [total, collections] = await Promise.all([
            index_js_1.PaymentCollection.countDocuments(filter),
            index_js_1.PaymentCollection.find(filter)
                .populate('customerId', 'name phone customerType outstandingBalance')
                .populate('branchId', 'name code shopNumber')
                .sort({ collectionDate: -1 })
                .skip(skip)
                .limit(limit)
                .lean(),
        ]);
        const formattedCollections = collections.map((col) => ({
            ...col,
            id: col._id.toString(),
            amount: col.totalCollected ?? 0,
            unallocatedAdvance: col.unallocatedAmount ?? 0,
        }));
        return {
            collections: formattedCollections,
            pagination: {
                total,
                page,
                limit,
                totalPages: Math.ceil(total / limit) || 1,
            },
        };
    }
    /**
     * 3. GET COLLECTION BY ID
     */
    static async getCollectionById(id, userContext) {
        const col = await index_js_1.PaymentCollection.findById(id)
            .populate('customerId', 'name phone customerType address outstandingBalance creditLimit')
            .populate('branchId', 'name code shopNumber address city phone')
            .lean();
        if (!col)
            throw new apiResponse_js_1.AppError('Payment collection record not found.', 404, 'COLLECTION_NOT_FOUND');
        if (userContext.role !== 'SUPER_ADMIN' && col.branchId?._id?.toString() !== userContext.branchId) {
            throw new apiResponse_js_1.AppError('Unauthorized access to collection of another branch.', 403, 'FORBIDDEN_BRANCH');
        }
        return col;
    }
    /**
     * 4. GET COLLECTION RECEIPT VIEW
     */
    static async getCollectionReceipt(id, userContext) {
        const col = await this.getCollectionById(id, userContext);
        const branch = col.branchId;
        const customer = col.customerId;
        return {
            receiptNumber: col.receiptNumber || col.collectionNumber,
            collectionNumber: col.collectionNumber,
            date: col.collectionDate,
            branch: {
                name: branch?.name || 'Molty Foam Branch',
                shopNumber: branch?.shopNumber || 'Shop #12-14',
                address: branch?.address || 'Karachi',
                phone: branch?.phone || '021-34567890',
            },
            customer: {
                name: col.customerName,
                phone: customer?.phone || '—',
                outstandingRemaining: customer?.outstandingBalance || 0,
            },
            amountCollected: col.totalCollected,
            paymentMethod: col.paymentMethod,
            reference: col.reference || '—',
            allocations: col.allocations,
            unallocatedAdvance: col.unallocatedAmount || 0,
            collectedBy: col.collectedBy,
            notes: col.notes,
        };
    }
    /**
     * 5. GET OUTSTANDING RECEIVABLES ACROSS CUSTOMERS
     */
    static async getOutstandingCustomers(userContext) {
        const filter = {
            outstandingBalance: { $gt: 0 },
        };
        const customers = await index_js_1.Customer.find(filter)
            .sort({ outstandingBalance: -1 })
            .lean();
        const totalOutstanding = customers.reduce((sum, c) => sum + (c.outstandingBalance || 0), 0);
        return {
            totalOutstanding,
            customerCount: customers.length,
            customers: customers.map((c) => ({
                id: c._id.toString(),
                name: c.name,
                phone: c.phone,
                customerType: c.customerType,
                creditLimit: c.creditLimit,
                outstandingBalance: c.outstandingBalance,
                availableCredit: Math.max(0, (c.creditLimit || 0) - (c.outstandingBalance || 0)),
            })),
        };
    }
    /**
     * 6. GET OVERDUE CUSTOMERS & INVOICES
     */
    static async getOverdueCustomers(userContext) {
        const now = new Date();
        const invFilter = {
            balanceDue: { $gt: 0 },
            dueDate: { $lt: now },
        };
        if (userContext.role !== 'SUPER_ADMIN') {
            invFilter.branchId = new mongoose_1.default.Types.ObjectId(userContext.branchId);
        }
        const overdueInvoices = await index_js_1.SalesInvoice.find(invFilter)
            .populate('customerId', 'name phone customerType')
            .populate('branchId', 'name code')
            .sort({ dueDate: 1 })
            .lean();
        const totalOverdue = overdueInvoices.reduce((sum, inv) => sum + inv.balanceDue, 0);
        return {
            totalOverdue,
            overdueCount: overdueInvoices.length,
            invoices: overdueInvoices,
        };
    }
}
exports.CollectionService = CollectionService;
//# sourceMappingURL=collection.service.js.map