import { Request, Response, NextFunction } from 'express';
import { IAccount, ISession } from '../models/index.js';
declare global {
    namespace Express {
        interface Request {
            account?: IAccount;
            sessionRecord?: ISession;
        }
    }
}
export declare const SESSION_COOKIE_NAME = "molty_session_id";
/**
 * Authenticates the caller via Session Cookie or Authorization Header.
 * Finds session by SHA-256 hash of the opaque session token.
 */
export declare function authenticate(req: Request, res: Response, next: NextFunction): Promise<void>;
/**
 * Role Guard: Requires Super Admin account.
 */
export declare function requireSuperAdmin(req: Request, res: Response, next: NextFunction): void;
/**
 * Role Guard: Requires Branch account.
 */
export declare function requireBranchAccount(req: Request, res: Response, next: NextFunction): void;
/**
 * Security Rule: Enforces that a Branch Account can only access its own assigned branch data.
 * Even if a branch user supplies a different `branchId` in body or query params, this middleware
 * strictly overrides or rejects cross-branch tampering.
 */
export declare function enforceBranchBoundary(req: Request, res: Response, next: NextFunction): void;
