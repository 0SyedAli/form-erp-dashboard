import { z } from 'zod';
export declare const brandSchema: z.ZodObject<{
    body: z.ZodObject<{
        code: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        logoUrl: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
        branchId: z.ZodOptional<z.ZodString>;
        hasThickness: z.ZodOptional<z.ZodBoolean>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        code: string;
        name: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    }, {
        code: string;
        name: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        code: string;
        name: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    };
}, {
    body: {
        code: string;
        name: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    };
}>;
export declare const updateBrandSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        code: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        logoUrl: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
        branchId: z.ZodOptional<z.ZodString>;
        hasThickness: z.ZodOptional<z.ZodBoolean>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        logoUrl?: string | undefined;
        hasThickness?: boolean | undefined;
    };
}>;
export declare const categorySchema: z.ZodObject<{
    body: z.ZodObject<{
        brandId: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        code: string;
        name: string;
        brandId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
    }, {
        code: string;
        name: string;
        brandId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        code: string;
        name: string;
        brandId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
    };
}, {
    body: {
        code: string;
        name: string;
        brandId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
    };
}>;
export declare const updateCategorySchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        brandId: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
        code: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
    };
}>;
export declare const productLineSchema: z.ZodObject<{
    body: z.ZodObject<{
        brandId: z.ZodString;
        categoryId: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        code: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        imageUrl: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        code: string;
        name: string;
        brandId: string;
        categoryId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        imageUrl?: string | undefined;
    }, {
        code: string;
        name: string;
        brandId: string;
        categoryId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        imageUrl?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        code: string;
        name: string;
        brandId: string;
        categoryId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        imageUrl?: string | undefined;
    };
}, {
    body: {
        code: string;
        name: string;
        brandId: string;
        categoryId: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        imageUrl?: string | undefined;
    };
}>;
export declare const updateProductLineSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        brandId: z.ZodOptional<z.ZodString>;
        categoryId: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
        code: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        imageUrl: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        code?: string | undefined;
        name?: string | undefined;
        description?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
    };
}>;
export declare const sizeSchema: z.ZodObject<{
    body: z.ZodObject<{
        length: z.ZodNumber;
        width: z.ZodNumber;
        unit: z.ZodDefault<z.ZodString>;
        displayLabel: z.ZodString;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        length: number;
        width: number;
        unit: string;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
    }, {
        length: number;
        width: number;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        unit?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        length: number;
        width: number;
        unit: string;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
    };
}, {
    body: {
        length: number;
        width: number;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        unit?: string | undefined;
    };
}>;
export declare const updateSizeSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        length: z.ZodOptional<z.ZodNumber>;
        width: z.ZodOptional<z.ZodNumber>;
        unit: z.ZodOptional<z.ZodString>;
        displayLabel: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        length?: number | undefined;
        width?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        length?: number | undefined;
        width?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        length?: number | undefined;
        width?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        length?: number | undefined;
        width?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    };
}>;
export declare const thicknessSchema: z.ZodObject<{
    body: z.ZodObject<{
        value: z.ZodNumber;
        unit: z.ZodDefault<z.ZodString>;
        displayLabel: z.ZodString;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        value: number;
        unit: string;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
    }, {
        value: number;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        unit?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        value: number;
        unit: string;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
    };
}, {
    body: {
        value: number;
        displayLabel: string;
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        unit?: string | undefined;
    };
}>;
export declare const updateThicknessSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        value: z.ZodOptional<z.ZodNumber>;
        unit: z.ZodOptional<z.ZodString>;
        displayLabel: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        value?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        value?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        value?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        value?: number | undefined;
        unit?: string | undefined;
        displayLabel?: string | undefined;
    };
}>;
export declare const createProductWithVariantSchema: z.ZodObject<{
    body: z.ZodObject<{
        brandId: z.ZodString;
        categoryId: z.ZodString;
        productLineId: z.ZodOptional<z.ZodString>;
        sizeId: z.ZodString;
        thicknessId: z.ZodOptional<z.ZodString>;
        listPrice: z.ZodNumber;
        purchasePercent: z.ZodOptional<z.ZodNumber>;
        purchasePrice: z.ZodOptional<z.ZodNumber>;
        retailPercent: z.ZodOptional<z.ZodNumber>;
        retailPrice: z.ZodOptional<z.ZodNumber>;
        wholesalePercent: z.ZodOptional<z.ZodNumber>;
        wholesalePrice: z.ZodOptional<z.ZodNumber>;
        distributorPercent: z.ZodOptional<z.ZodNumber>;
        distributorPrice: z.ZodOptional<z.ZodNumber>;
        stock: z.ZodDefault<z.ZodNumber>;
        minimumStock: z.ZodDefault<z.ZodNumber>;
        destinationBranchId: z.ZodOptional<z.ZodString>;
        imageUrl: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        brandId: string;
        categoryId: string;
        sizeId: string;
        listPrice: number;
        stock: number;
        minimumStock: number;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        thicknessId?: string | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        destinationBranchId?: string | undefined;
    }, {
        brandId: string;
        categoryId: string;
        sizeId: string;
        listPrice: number;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        thicknessId?: string | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
        destinationBranchId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        brandId: string;
        categoryId: string;
        sizeId: string;
        listPrice: number;
        stock: number;
        minimumStock: number;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        thicknessId?: string | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        destinationBranchId?: string | undefined;
    };
}, {
    body: {
        brandId: string;
        categoryId: string;
        sizeId: string;
        listPrice: number;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        thicknessId?: string | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
        destinationBranchId?: string | undefined;
    };
}>;
export declare const updateSkuSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        brandId: z.ZodOptional<z.ZodString>;
        categoryId: z.ZodOptional<z.ZodString>;
        productLineId: z.ZodOptional<z.ZodString>;
        sizeId: z.ZodOptional<z.ZodString>;
        thicknessId: z.ZodOptional<z.ZodString>;
        imageUrl: z.ZodOptional<z.ZodString>;
        listPrice: z.ZodOptional<z.ZodNumber>;
        purchasePercent: z.ZodOptional<z.ZodNumber>;
        purchasePrice: z.ZodOptional<z.ZodNumber>;
        retailPercent: z.ZodOptional<z.ZodNumber>;
        retailPrice: z.ZodOptional<z.ZodNumber>;
        wholesalePercent: z.ZodOptional<z.ZodNumber>;
        wholesalePrice: z.ZodOptional<z.ZodNumber>;
        distributorPercent: z.ZodOptional<z.ZodNumber>;
        distributorPrice: z.ZodOptional<z.ZodNumber>;
        stock: z.ZodOptional<z.ZodNumber>;
        minimumStock: z.ZodOptional<z.ZodNumber>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
        reason: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    };
}>;
export declare const updatePricesSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        brandId: z.ZodOptional<z.ZodString>;
        categoryId: z.ZodOptional<z.ZodString>;
        productLineId: z.ZodOptional<z.ZodString>;
        sizeId: z.ZodOptional<z.ZodString>;
        thicknessId: z.ZodOptional<z.ZodString>;
        imageUrl: z.ZodOptional<z.ZodString>;
        listPrice: z.ZodOptional<z.ZodNumber>;
        purchasePercent: z.ZodOptional<z.ZodNumber>;
        purchasePrice: z.ZodOptional<z.ZodNumber>;
        retailPercent: z.ZodOptional<z.ZodNumber>;
        retailPrice: z.ZodOptional<z.ZodNumber>;
        wholesalePercent: z.ZodOptional<z.ZodNumber>;
        wholesalePrice: z.ZodOptional<z.ZodNumber>;
        distributorPercent: z.ZodOptional<z.ZodNumber>;
        distributorPrice: z.ZodOptional<z.ZodNumber>;
        stock: z.ZodOptional<z.ZodNumber>;
        minimumStock: z.ZodOptional<z.ZodNumber>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>>;
        reason: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        imageUrl?: string | undefined;
        productLineId?: string | undefined;
        sizeId?: string | undefined;
        thicknessId?: string | undefined;
        listPrice?: number | undefined;
        purchasePrice?: number | undefined;
        retailPrice?: number | undefined;
        wholesalePrice?: number | undefined;
        distributorPrice?: number | undefined;
        reason?: string | undefined;
        purchasePercent?: number | undefined;
        retailPercent?: number | undefined;
        wholesalePercent?: number | undefined;
        distributorPercent?: number | undefined;
        stock?: number | undefined;
        minimumStock?: number | undefined;
    };
}>;
export declare const statusToggleSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        status: z.ZodEffects<z.ZodEnum<["ACTIVE", "INACTIVE", "active", "inactive"]>, "ACTIVE" | "INACTIVE", "ACTIVE" | "INACTIVE" | "active" | "inactive">;
    }, "strip", z.ZodTypeAny, {
        status: "ACTIVE" | "INACTIVE";
    }, {
        status: "ACTIVE" | "INACTIVE" | "active" | "inactive";
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status: "ACTIVE" | "INACTIVE";
    };
}, {
    params: {
        id: string;
    };
    body: {
        status: "ACTIVE" | "INACTIVE" | "active" | "inactive";
    };
}>;
export declare const idParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export declare const paginationQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        page: z.ZodDefault<z.ZodNumber>;
        limit: z.ZodDefault<z.ZodNumber>;
        search: z.ZodOptional<z.ZodString>;
        status: z.ZodDefault<z.ZodEnum<["ACTIVE", "INACTIVE", "ALL", "active", "inactive", "all"]>>;
        brandId: z.ZodOptional<z.ZodString>;
        categoryId: z.ZodOptional<z.ZodString>;
        productLineId: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status: "ACTIVE" | "INACTIVE" | "active" | "inactive" | "ALL" | "all";
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        productLineId?: string | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | "ALL" | "all" | undefined;
        limit?: number | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        productLineId?: string | undefined;
        page?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        status: "ACTIVE" | "INACTIVE" | "active" | "inactive" | "ALL" | "all";
        limit: number;
        page: number;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        productLineId?: string | undefined;
    };
}, {
    query: {
        status?: "ACTIVE" | "INACTIVE" | "active" | "inactive" | "ALL" | "all" | undefined;
        limit?: number | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        brandId?: string | undefined;
        categoryId?: string | undefined;
        productLineId?: string | undefined;
        page?: number | undefined;
    };
}>;
export type BrandInput = z.infer<typeof brandSchema>['body'];
export type CategoryInput = z.infer<typeof categorySchema>['body'];
export type ProductLineInput = z.infer<typeof productLineSchema>['body'];
export type SizeInput = z.infer<typeof sizeSchema>['body'];
export type ThicknessInput = z.infer<typeof thicknessSchema>['body'];
export type CreateProductWithVariantInput = z.infer<typeof createProductWithVariantSchema>['body'];
export type UpdatePricesInput = z.infer<typeof updatePricesSchema>['body'];
export type UpdateSkuInput = z.infer<typeof updateSkuSchema>['body'];
