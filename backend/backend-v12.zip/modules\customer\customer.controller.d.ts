import { Request, Response } from 'express';
export declare class CustomerController {
    private static getUserContext;
    private static handleError;
    static getCustomers(req: Request, res: Response): Promise<void>;
    static getCustomerById(req: Request, res: Response): Promise<void>;
    static createCustomer(req: Request, res: Response): Promise<void>;
    static updateCustomer(req: Request, res: Response): Promise<void>;
    static getCustomerLedger(req: Request, res: Response): Promise<void>;
    static getCustomerOutstanding(req: Request, res: Response): Promise<void>;
    static getCustomerInvoices(req: Request, res: Response): Promise<void>;
}
