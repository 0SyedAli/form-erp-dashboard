import mongoose, { Document } from 'mongoose';
import { SaleType, PaymentStatus, PaymentArrangement, InvoiceStatus, CustomerType } from '../constants/index.js';
export interface IInvoiceLineItem {
    variantId?: mongoose.Types.ObjectId;
    sku: string;
    productName: string;
    sizeLabel: string;
    thicknessLabel: string;
    quantity: number;
    unitPrice: number;
    lineTotal: number;
}
export interface ISalesInvoice extends Document {
    invoiceNumber: string;
    branchId: mongoose.Types.ObjectId;
    sourceBranchId?: mongoose.Types.ObjectId;
    isInterBranch?: boolean;
    customerId?: mongoose.Types.ObjectId;
    customerName: string;
    customerPhone?: string;
    customerType: CustomerType;
    saleType: SaleType;
    items: IInvoiceLineItem[];
    subtotal: number;
    discount: number;
    tax: number;
    total: number;
    paidAmount: number;
    balanceDue: number;
    paymentStatus: PaymentStatus;
    paymentArrangement: PaymentArrangement;
    status: InvoiceStatus;
    cashReceived?: number;
    changeReturned?: number;
    dueDate?: Date;
    idempotencyKey?: string;
    cashierName: string;
    creditOverride?: boolean;
    creditApprovedBy?: string;
    overrideReason?: string;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const SalesInvoice: mongoose.Model<ISalesInvoice, {}, {}, {}, mongoose.Document<unknown, {}, ISalesInvoice, {}, {}> & ISalesInvoice & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
