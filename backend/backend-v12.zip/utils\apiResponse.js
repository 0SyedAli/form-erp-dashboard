"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppError = void 0;
exports.sendSuccess = sendSuccess;
exports.sendError = sendError;
class AppError extends Error {
    statusCode;
    code;
    details;
    constructor(message, statusCode = 400, code = 'BAD_REQUEST', details) {
        super(message);
        this.name = 'AppError';
        this.statusCode = statusCode;
        this.code = code;
        this.details = details;
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.AppError = AppError;
function sendSuccess(res, data, message, statusCode = 200, meta) {
    const payload = {
        success: true,
        data,
        ...(message ? { message } : {}),
        ...(meta ? { meta } : {}),
    };
    return res.status(statusCode).json(payload);
}
function sendError(res, message, statusCode = 500, code = 'INTERNAL_ERROR', details) {
    const payload = {
        success: false,
        error: {
            code,
            message,
            ...(details ? { details } : {}),
        },
    };
    return res.status(statusCode).json(payload);
}
//# sourceMappingURL=apiResponse.js.map