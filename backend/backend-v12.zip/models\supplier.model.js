"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Supplier = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const SupplierSchema = new mongoose_1.Schema({
    code: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    name: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        index: true,
    },
    contactPerson: {
        type: String,
        trim: true,
    },
    phone: {
        type: String,
        required: true,
        trim: true,
    },
    whatsapp: {
        type: String,
        trim: true,
    },
    email: {
        type: String,
        trim: true,
        lowercase: true,
    },
    address: {
        type: String,
        default: '',
    },
    city: {
        type: String,
        default: 'Karachi',
    },
    ntn: {
        type: String,
        trim: true,
    },
    suppliedBrands: {
        type: [String],
        default: [],
    },
    creditEnabled: {
        type: Boolean,
        default: true,
    },
    defaultCreditDays: {
        type: Number,
        default: 30,
        min: 0,
    },
    paymentTerms: {
        type: String,
        default: 'Net 30 Days',
    },
    creditLimit: {
        type: Number,
        default: 1000000,
        min: 0,
    },
    openingPayable: {
        type: Number,
        default: 0,
        min: 0,
    },
    currentOutstanding: {
        type: Number,
        default: 0,
    },
    balancePayable: {
        type: Number,
        default: 0,
    },
    unallocatedAdvances: {
        type: Number,
        default: 0,
    },
    supplierCreditBalance: {
        type: Number,
        default: 0,
    },
    bankName: {
        type: String,
        trim: true,
    },
    bankAccountNumber: {
        type: String,
        trim: true,
    },
    status: {
        type: String,
        enum: ['ACTIVE', 'INACTIVE'],
        default: 'ACTIVE',
        index: true,
    },
    notes: {
        type: String,
    },
}, {
    timestamps: true,
});
// Virtual alias to ensure backward compatibility between currentOutstanding and balancePayable
SupplierSchema.pre('save', function (next) {
    if (this.isModified('currentOutstanding')) {
        this.balancePayable = this.currentOutstanding;
    }
    else if (this.isModified('balancePayable')) {
        this.currentOutstanding = this.balancePayable;
    }
    next();
});
exports.Supplier = mongoose_1.default.model('Supplier', SupplierSchema);
//# sourceMappingURL=supplier.model.js.map