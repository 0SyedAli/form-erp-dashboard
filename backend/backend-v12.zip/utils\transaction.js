"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.withTransaction = withTransaction;
exports.runTransaction = withTransaction;
const mongoose_1 = __importDefault(require("mongoose"));
const logger_js_1 = require("./logger.js");
const database_js_1 = require("../config/database.js");
const apiResponse_js_1 = require("./apiResponse.js");
/**
 * Executes a callback within a managed MongoDB multi-document ACID transaction.
 * Strictly verifies replica-set capability; fails safely if transactions are unsupported.
 */
async function withTransaction(callback, options = { strict: true }) {
    const dbStatus = (0, database_js_1.getDatabaseStatus)();
    // If connected to MongoDB and the topology supports transactions (Replica Set / Sharded)
    if (mongoose_1.default.connection.readyState === 1 && dbStatus.isReplicaSet) {
        const session = await mongoose_1.default.startSession();
        const maxAttempts = 3;
        let attempts = 0;
        try {
            while (attempts < maxAttempts) {
                attempts++;
                session.startTransaction({
                    readConcern: { level: 'snapshot' },
                    writeConcern: { w: 'majority' },
                });
                try {
                    const result = await callback(session);
                    await session.commitTransaction();
                    return result;
                }
                catch (error) {
                    if (session.inTransaction()) {
                        await session.abortTransaction();
                    }
                    const isTransient = error?.errorLabels?.includes('TransientTransactionError') ||
                        error?.code === 112 ||
                        error?.codeName === 'WriteConflict';
                    if (isTransient && attempts < maxAttempts) {
                        logger_js_1.logger.warn({ attempt: attempts }, 'Transient write conflict encountered, retrying atomic transaction...');
                        await new Promise((r) => setTimeout(r, 20 * attempts));
                        continue;
                    }
                    logger_js_1.logger.error({ error }, 'Transaction aborted due to error during atomic operation');
                    throw error;
                }
            }
        }
        finally {
            await session.endSession();
        }
    }
    // If transactions are required and replica set is absent, fail safely
    if (options.strict !== false) {
        logger_js_1.logger.error('Attempted atomic operation but MongoDB is not running in Replica Set mode');
        throw new apiResponse_js_1.AppError('Atomic transactions are unavailable: MongoDB Replica Set is required for financial or inventory multi-document consistency.', 503, 'TRANSACTIONS_UNAVAILABLE');
    }
    logger_js_1.logger.warn('Running non-strict operation without MongoDB transaction session (Replica Set not active)');
    return await callback(null);
}
//# sourceMappingURL=transaction.js.map