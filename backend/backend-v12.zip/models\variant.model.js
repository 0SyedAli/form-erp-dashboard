"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Variant = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const VariantSchema = new mongoose_1.Schema({
    productId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Product',
        required: true,
        index: true,
    },
    sizeId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Size',
        required: true,
        index: true,
    },
    thicknessId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Thickness',
        required: false,
        index: true,
    },
    sku: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    barcode: {
        type: String,
        trim: true,
        sparse: true,
        unique: true,
    },
    posDisplayName: {
        type: String,
        trim: true,
        index: true,
    },
    notes: {
        type: String,
        trim: true,
    },
    minStock: {
        type: Number,
        default: 0,
        min: 0,
    },
    listPrice: {
        type: Number,
        required: true,
        min: 0,
        default: 0,
    },
    purchasePrice: {
        type: Number,
        required: true,
        min: 0,
        default: 0,
    },
    purchaseDiscountPercent: {
        type: Number,
        min: 0,
        max: 100,
    },
    retailPrice: {
        type: Number,
        required: true,
        min: 0,
    },
    retailMarkupPercent: {
        type: Number,
        min: 0,
    },
    wholesalePrice: {
        type: Number,
        required: true,
        min: 0,
    },
    wholesaleDiscountPercent: {
        type: Number,
        min: 0,
        max: 100,
    },
    distributorPrice: {
        type: Number,
        min: 0,
        default: 0,
    },
    distributorDiscountPercent: {
        type: Number,
        min: 0,
        max: 100,
        default: 0,
    },
    status: {
        type: String,
        enum: ['ACTIVE', 'INACTIVE'],
        default: 'ACTIVE',
        index: true,
    },
}, {
    timestamps: true,
});
// Compound index to prevent duplicate specifications under the same base product
VariantSchema.index({ productId: 1, sizeId: 1, thicknessId: 1 }, { unique: true });
exports.Variant = mongoose_1.default.model('Variant', VariantSchema);
//# sourceMappingURL=variant.model.js.map