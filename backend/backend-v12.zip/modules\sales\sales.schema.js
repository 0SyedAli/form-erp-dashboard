"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteInvoiceSchema = exports.invoiceParamSchema = exports.salesQuerySchema = void 0;
const zod_1 = require("zod");
const index_js_1 = require("../../constants/index.js");
exports.salesQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        customerId: zod_1.z.string().optional(),
        scope: zod_1.z.enum(['sales', 'dispatches', 'all']).optional(),
        isInterBranch: zod_1.z
            .enum(['true', 'false'])
            .transform((v) => v === 'true')
            .optional(),
        saleType: zod_1.z.enum([index_js_1.SALE_TYPES.WALK_IN, index_js_1.SALE_TYPES.WHOLESALE, index_js_1.SALE_TYPES.DISTRIBUTOR]).optional(),
        paymentStatus: zod_1.z
            .enum([index_js_1.PAYMENT_STATUSES.PAID, index_js_1.PAYMENT_STATUSES.PARTIAL, index_js_1.PAYMENT_STATUSES.UNPAID])
            .optional(),
        search: zod_1.z.string().optional(),
        dateFrom: zod_1.z.string().optional(),
        dateTo: zod_1.z.string().optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('20'),
    }),
});
exports.invoiceParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Invoice ID is required'),
    }),
});
exports.deleteInvoiceSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Invoice ID is required'),
    }),
    body: zod_1.z
        .object({
        returnStock: zod_1.z.boolean().optional().default(true),
    })
        .optional(),
});
//# sourceMappingURL=sales.schema.js.map