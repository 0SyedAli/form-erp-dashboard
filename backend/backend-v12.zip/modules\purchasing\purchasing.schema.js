"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.idParamSchema = exports.poQuerySchema = exports.createPurchaseReturnSchema = exports.createSupplierPaymentSchema = exports.createSupplierBillSchema = exports.receiveOrderSchema = exports.updatePurchaseOrderSchema = exports.createPurchaseOrderSchema = exports.poItemSchema = void 0;
const zod_1 = require("zod");
exports.poItemSchema = zod_1.z.object({
    sku: zod_1.z.string().min(1, 'SKU is required'),
    quantity: zod_1.z.number().int().min(1, 'Quantity must be at least 1'),
    unitCost: zod_1.z.number().min(0, 'Unit cost must be non-negative'),
    lineDiscount: zod_1.z.number().min(0).optional().default(0),
    taxAmount: zod_1.z.number().min(0).optional().default(0),
});
exports.createPurchaseOrderSchema = zod_1.z.object({
    body: zod_1.z.object({
        supplierId: zod_1.z.string().min(1, 'Supplier ID is required'),
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        expectedDeliveryDate: zod_1.z.string().or(zod_1.z.date()).optional(),
        paymentTerms: zod_1.z.string().optional().default('Net 30 Days'),
        referenceNumber: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
        items: zod_1.z.array(exports.poItemSchema).min(1, 'Order must contain at least one line item'),
    }),
});
exports.updatePurchaseOrderSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Order ID is required'),
    }),
    body: zod_1.z.object({
        supplierId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        expectedDeliveryDate: zod_1.z.string().or(zod_1.z.date()).optional(),
        paymentTerms: zod_1.z.string().optional(),
        referenceNumber: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
        items: zod_1.z.array(exports.poItemSchema).optional(),
    }),
});
exports.receiveOrderSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Order ID is required'),
    }),
    body: zod_1.z.object({
        deliveryReference: zod_1.z.string().min(1, 'Delivery reference / challan number is required'),
        stockLocationId: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
        items: zod_1.z
            .array(zod_1.z.object({
            sku: zod_1.z.string().min(1, 'SKU is required'),
            quantityReceived: zod_1.z.number().int().min(0, 'Received quantity must be non-negative'),
            damagedQuantity: zod_1.z.number().int().min(0).optional().default(0),
        }))
            .min(1, 'At least one item must be received'),
    }),
});
exports.createSupplierBillSchema = zod_1.z.object({
    body: zod_1.z.object({
        supplierId: zod_1.z.string().min(1, 'Supplier ID is required'),
        supplierInvoiceNumber: zod_1.z.string().min(1, 'Supplier invoice reference is required'),
        branchId: zod_1.z.string().optional(),
        purchaseOrderId: zod_1.z.string().optional(),
        grnIds: zod_1.z.array(zod_1.z.string()).optional(),
        billDate: zod_1.z.string().or(zod_1.z.date()).optional(),
        dueDate: zod_1.z.string().or(zod_1.z.date()),
        notes: zod_1.z.string().optional(),
        items: zod_1.z
            .array(zod_1.z.object({
            sku: zod_1.z.string().min(1, 'SKU is required'),
            quantity: zod_1.z.number().int().min(1, 'Quantity must be at least 1'),
            unitCost: zod_1.z.number().min(0, 'Unit cost must be non-negative'),
            discount: zod_1.z.number().min(0).optional().default(0),
            tax: zod_1.z.number().min(0).optional().default(0),
        }))
            .min(1, 'Bill must contain at least one item'),
    }),
});
exports.createSupplierPaymentSchema = zod_1.z.object({
    body: zod_1.z.object({
        supplierId: zod_1.z.string().min(1, 'Supplier ID is required'),
        branchId: zod_1.z.string().optional(),
        amount: zod_1.z.number().min(1, 'Payment amount must be at least 1'),
        paymentMethod: zod_1.z
            .enum(['CASH', 'BANK_TRANSFER', 'CHEQUE', 'ONLINE', 'PAYPAK_CARD'])
            .default('BANK_TRANSFER'),
        reference: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
        chequeDate: zod_1.z.string().or(zod_1.z.date()).optional(),
        allocations: zod_1.z
            .array(zod_1.z.object({
            billId: zod_1.z.string().min(1, 'Bill ID is required'),
            allocatedAmount: zod_1.z.number().min(1, 'Allocated amount must be at least 1'),
        }))
            .optional(), // If omitted, oldest-due-first auto-allocation is applied
        idempotencyKey: zod_1.z.string().optional(),
    }),
});
exports.createPurchaseReturnSchema = zod_1.z.object({
    body: zod_1.z.object({
        supplierId: zod_1.z.string().min(1, 'Supplier ID is required'),
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        purchaseOrderId: zod_1.z.string().optional(),
        billId: zod_1.z.string().optional(),
        receiptId: zod_1.z.string().optional(),
        reason: zod_1.z.string().min(3, 'Return reason must be at least 3 characters'),
        notes: zod_1.z.string().optional(),
        items: zod_1.z
            .array(zod_1.z.object({
            sku: zod_1.z.string().min(1, 'SKU is required'),
            quantity: zod_1.z.number().int().min(1, 'Quantity must be at least 1'),
            unitCost: zod_1.z.number().min(0).optional(),
            reason: zod_1.z.string().optional(),
        }))
            .min(1, 'Return must contain at least one line item'),
    }),
});
exports.poQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        supplierId: zod_1.z.string().optional(),
        status: zod_1.z.string().optional(),
        search: zod_1.z.string().optional(),
        dateFrom: zod_1.z.string().optional(),
        dateTo: zod_1.z.string().optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('20'),
    }),
});
exports.idParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'ID is required'),
    }),
});
//# sourceMappingURL=purchasing.schema.js.map