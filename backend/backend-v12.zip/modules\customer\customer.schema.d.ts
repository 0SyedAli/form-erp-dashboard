import { z } from 'zod';
export declare const customerQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        search: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
        customerType: z.ZodOptional<z.ZodEnum<["WALK_IN", "WHOLESALE", "DISTRIBUTOR"]>>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "BLOCKED"]>>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        page?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
    };
}, {
    query: {
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        page?: string | undefined;
    };
}>;
export declare const createCustomerSchema: z.ZodObject<{
    body: z.ZodObject<{
        name: z.ZodString;
        phone: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        customerType: z.ZodDefault<z.ZodEnum<["WALK_IN", "WHOLESALE", "DISTRIBUTOR"]>>;
        businessName: z.ZodOptional<z.ZodString>;
        email: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
        address: z.ZodOptional<z.ZodString>;
        city: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        taxNumber: z.ZodOptional<z.ZodString>;
        creditEnabled: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
        creditLimit: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        creditTerms: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        defaultDueDays: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        name: string;
        city: string;
        phone: string;
        customerType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        creditEnabled: boolean;
        creditLimit: number;
        creditTerms: string;
        defaultDueDays: number;
        email?: string | undefined;
        branchId?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
    }, {
        name: string;
        phone: string;
        email?: string | undefined;
        branchId?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        creditTerms?: string | undefined;
        defaultDueDays?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        name: string;
        city: string;
        phone: string;
        customerType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        creditEnabled: boolean;
        creditLimit: number;
        creditTerms: string;
        defaultDueDays: number;
        email?: string | undefined;
        branchId?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
    };
}, {
    body: {
        name: string;
        phone: string;
        email?: string | undefined;
        branchId?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        notes?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        creditTerms?: string | undefined;
        defaultDueDays?: number | undefined;
    };
}>;
export declare const updateCustomerSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        phone: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
        customerType: z.ZodOptional<z.ZodEnum<["WALK_IN", "WHOLESALE", "DISTRIBUTOR"]>>;
        businessName: z.ZodOptional<z.ZodString>;
        email: z.ZodUnion<[z.ZodOptional<z.ZodString>, z.ZodLiteral<"">]>;
        address: z.ZodOptional<z.ZodString>;
        city: z.ZodOptional<z.ZodString>;
        taxNumber: z.ZodOptional<z.ZodString>;
        creditEnabled: z.ZodOptional<z.ZodBoolean>;
        creditLimit: z.ZodOptional<z.ZodNumber>;
        creditTerms: z.ZodOptional<z.ZodString>;
        defaultDueDays: z.ZodOptional<z.ZodNumber>;
        status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "BLOCKED"]>>;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        branchId?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        creditTerms?: string | undefined;
        defaultDueDays?: number | undefined;
    }, {
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        branchId?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        creditTerms?: string | undefined;
        defaultDueDays?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        branchId?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        creditTerms?: string | undefined;
        defaultDueDays?: number | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        status?: "ACTIVE" | "INACTIVE" | "BLOCKED" | undefined;
        name?: string | undefined;
        email?: string | undefined;
        branchId?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        notes?: string | undefined;
        customerType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        businessName?: string | undefined;
        taxNumber?: string | undefined;
        creditEnabled?: boolean | undefined;
        creditLimit?: number | undefined;
        creditTerms?: string | undefined;
        defaultDueDays?: number | undefined;
    };
}>;
export declare const customerParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    query: z.ZodOptional<z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        branchId?: string | undefined;
    }, {
        branchId?: string | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    query?: {
        branchId?: string | undefined;
    } | undefined;
}, {
    params: {
        id: string;
    };
    query?: {
        branchId?: string | undefined;
    } | undefined;
}>;
export type CustomerQuery = z.infer<typeof customerQuerySchema>['query'];
export type CreateCustomerInput = z.infer<typeof createCustomerSchema>['body'];
export type UpdateCustomerInput = z.infer<typeof updateCustomerSchema>['body'];
