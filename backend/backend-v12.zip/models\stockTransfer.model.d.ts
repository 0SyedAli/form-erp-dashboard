import mongoose, { Document } from 'mongoose';
export declare const TRANSFER_STATUSES: {
    readonly DRAFT: "DRAFT";
    readonly PENDING_APPROVAL: "PENDING_APPROVAL";
    readonly APPROVED: "APPROVED";
    readonly DISPATCHED: "DISPATCHED";
    readonly RECEIVED: "RECEIVED";
    readonly CANCELLED: "CANCELLED";
};
export type TransferStatus = (typeof TRANSFER_STATUSES)[keyof typeof TRANSFER_STATUSES];
export interface ITransferItem {
    sku: string;
    variantId?: mongoose.Types.ObjectId;
    quantity: number;
}
export interface IStockTransfer extends Document {
    transferNumber: string;
    fromBranchId: mongoose.Types.ObjectId;
    toBranchId: mongoose.Types.ObjectId;
    fromStockLocationId: mongoose.Types.ObjectId;
    toStockLocationId: mongoose.Types.ObjectId;
    items: ITransferItem[];
    status: TransferStatus;
    initiatedBy: string;
    approvedBy?: string;
    approvedAt?: Date;
    receivedBy?: string;
    dispatchedAt?: Date;
    receivedAt?: Date;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const StockTransfer: mongoose.Model<IStockTransfer, {}, {}, {}, mongoose.Document<unknown, {}, IStockTransfer, {}, {}> & IStockTransfer & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
