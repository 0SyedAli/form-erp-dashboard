"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchAccountController = void 0;
const branch_account_service_js_1 = require("./branch-account.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class BranchAccountController {
    static async getAccount(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const result = await branch_account_service_js_1.BranchAccountService.getBranchAccount(branchId);
            (0, apiResponse_js_1.sendSuccess)(res, result);
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to retrieve branch account.', 500, 'INTERNAL_ERROR');
        }
    }
    static async createAccount(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const adminId = req.account?._id.toString();
            const result = await branch_account_service_js_1.BranchAccountService.createBranchAccount(branchId, req.body, adminId);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Branch account created successfully.', 201);
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to create branch account.', 500, 'INTERNAL_ERROR');
        }
    }
    static async updateAccount(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const adminId = req.account?._id.toString();
            const result = await branch_account_service_js_1.BranchAccountService.updateBranchAccount(branchId, req.body, adminId);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Branch account updated successfully.');
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to update branch account.', 500, 'INTERNAL_ERROR');
        }
    }
    static async resetPassword(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const adminId = req.account?._id.toString();
            const result = await branch_account_service_js_1.BranchAccountService.resetPassword(branchId, req.body, adminId);
            (0, apiResponse_js_1.sendSuccess)(res, result, result.message);
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to reset branch password.', 500, 'INTERNAL_ERROR');
        }
    }
    static async updatePermissions(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const adminId = req.account?._id.toString();
            const result = await branch_account_service_js_1.BranchAccountService.updatePermissions(branchId, req.body, adminId);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Branch permissions updated successfully.');
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to update branch permissions.', 500, 'INTERNAL_ERROR');
        }
    }
    static async deactivateAccount(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const adminId = req.account?._id.toString();
            const result = await branch_account_service_js_1.BranchAccountService.deactivateAccount(branchId, adminId);
            (0, apiResponse_js_1.sendSuccess)(res, result, result.message);
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to deactivate branch account.', 500, 'INTERNAL_ERROR');
        }
    }
    static async createBranch(req, res) {
        try {
            const adminId = req.account?._id.toString();
            const result = await branch_account_service_js_1.BranchAccountService.createBranch(req.body, adminId);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Branch and account created successfully.', 201);
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, 'Failed to create branch.', 500, 'INTERNAL_ERROR');
        }
    }
    static async updateBranch(req, res) {
        try {
            const branchId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const result = await branch_account_service_js_1.BranchAccountService.updateBranch(branchId, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Branch updated successfully.');
        }
        catch (error) {
            if (error.statusCode) {
                (0, apiResponse_js_1.sendError)(res, error.message, error.statusCode, error.code);
                return;
            }
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update branch.', 500, 'INTERNAL_ERROR');
        }
    }
}
exports.BranchAccountController = BranchAccountController;
//# sourceMappingURL=branch-account.controller.js.map