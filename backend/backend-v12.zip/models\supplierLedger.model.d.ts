import mongoose, { Document } from 'mongoose';
export type SupplierLedgerEntryType = 'BILL' | 'PAYMENT' | 'DEBIT_NOTE' | 'ADVANCE' | 'OPENING_BALANCE' | 'REVERSAL';
export interface ISupplierLedgerEntry extends Document {
    supplierId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    entryDate: Date;
    entryType: SupplierLedgerEntryType;
    referenceNumber: string;
    referenceBillId?: string;
    referencePaymentId?: string;
    debit: number;
    credit: number;
    runningBalance: number;
    narration: string;
    performedBy: string;
    timestamp: Date;
}
export declare const SupplierLedgerEntry: mongoose.Model<ISupplierLedgerEntry, {}, {}, {}, mongoose.Document<unknown, {}, ISupplierLedgerEntry, {}, {}> & ISupplierLedgerEntry & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
