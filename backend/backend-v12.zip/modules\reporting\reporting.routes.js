"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reportingRoutes = void 0;
const express_1 = require("express");
const reporting_controller_js_1 = require("./reporting.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
exports.reportingRoutes = (0, express_1.Router)();
// Apply session authentication to all reporting endpoints
exports.reportingRoutes.use(auth_middleware_js_1.authenticate);
// 1. Dashboards
exports.reportingRoutes.get('/dashboard/admin', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getAdminDashboard);
exports.reportingRoutes.get('/dashboard/branch', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), auth_middleware_js_1.enforceBranchBoundary, reporting_controller_js_1.ReportingController.getBranchDashboard);
// 2. Sales Reports
exports.reportingRoutes.get('/sales/summary', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getSalesSummary);
exports.reportingRoutes.get('/sales/trends', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getSalesTrends);
exports.reportingRoutes.get('/sales/by-branch', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getSalesByBranch);
exports.reportingRoutes.get('/sales/by-tier', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getSalesByTier);
exports.reportingRoutes.get('/sales/by-product', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getSalesByProduct);
// 3. Receivables & Collections Reports
exports.reportingRoutes.get('/receivables/summary', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getReceivablesSummary);
exports.reportingRoutes.get('/receivables/aging', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getReceivablesAging);
exports.reportingRoutes.get('/collections/summary', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getCollectionsSummary);
// 4. Inventory Reports
exports.reportingRoutes.get('/inventory/summary', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getInventorySummary);
exports.reportingRoutes.get('/inventory/low-stock', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getInventoryLowStock);
exports.reportingRoutes.get('/inventory/valuation', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getInventoryValuation);
exports.reportingRoutes.get('/inventory/movements', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getInventoryMovements);
// 5. Purchasing & Payables Reports
exports.reportingRoutes.get('/purchases/summary', (0, branchPermission_middleware_js_1.requireBranchPermission)('reports'), reporting_controller_js_1.ReportingController.getPurchasingSummary);
exports.reportingRoutes.get('/purchases/by-supplier', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getPurchasingBySupplier);
exports.reportingRoutes.get('/purchases/by-branch', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getPurchasingByBranch);
exports.reportingRoutes.get('/payables/summary', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getPayablesSummary);
exports.reportingRoutes.get('/payables/aging', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getPayablesAging);
// 6. Cross-Module Financial Audit & Reconciliation
exports.reportingRoutes.get('/reconciliation', auth_middleware_js_1.requireSuperAdmin, reporting_controller_js_1.ReportingController.getReconciliationAudit);
//# sourceMappingURL=reporting.routes.js.map