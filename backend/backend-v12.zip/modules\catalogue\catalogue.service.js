"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CatalogueService = void 0;
exports.generateSmartProductLineAbbr = generateSmartProductLineAbbr;
exports.generateSkuCode = generateSkuCode;
exports.invalidateMasterMetadataCache = invalidateMasterMetadataCache;
const mongoose_1 = __importDefault(require("mongoose"));
const index_js_1 = require("../../models/index.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
const pos_service_js_1 = require("../pos/pos.service.js");
const financial_js_1 = require("../../utils/financial.js");
function generateSmartProductLineAbbr(plNameOrCode) {
    if (!plNameOrCode)
        return '';
    let clean = plNameOrCode
        .replace(/^PL[-_]?/i, '')
        .replace(/[-_]\d+$/, '')
        .replace(/\+\+/g, ' DPLUS ')
        .replace(/\+/g, ' PLUS ')
        .replace(/&/g, ' AND ')
        .replace(/[^A-Za-z0-9\s]/g, ' ')
        .trim();
    const words = clean.split(/\s+/).filter(Boolean);
    if (words.length === 0)
        return 'GEN';
    if (words.length === 1) {
        if (words[0].toLowerCase() === 'commander')
            return 'CMDR';
        return words[0].slice(0, 4).toUpperCase();
    }
    // 2 words: e.g. "Flex Firm" -> "FLFM", "Flex Soft" -> "FLSF"
    if (words.length === 2) {
        const w1 = words[0].slice(0, 2);
        let w2 = words[1].slice(0, 2);
        if (words[1].toLowerCase() === 'firm')
            w2 = 'FM';
        else if (words[1].toLowerCase() === 'soft')
            w2 = 'SF';
        else if (words[1].toLowerCase() === 'foam')
            w2 = 'FO';
        return (w1 + w2).toUpperCase().padEnd(4, 'X').slice(0, 4);
    }
    // 3 words: e.g. "Molty Sleep Memory" -> "MSPM"
    if (words.length === 3) {
        const w1 = words[0][0];
        const w2 = words[1].slice(0, 2);
        const w3 = words[2][0];
        return (w1 + w2 + w3).toUpperCase().slice(0, 4);
    }
    // 4 words or more: specific distinctive abbreviations
    const lower = clean.toLowerCase();
    if (lower.includes('memory ortho'))
        return 'EFME'; // Ext Firm Memory Ortho
    if (lower.includes('cool gel ortho'))
        return 'EFCG'; // Ext Firm Cool Gel Ortho
    if (lower.includes('molty ortho duo'))
        return '3MOD'; // 3in1 Molty Ortho Duo
    if (lower.includes('molty ortho fold'))
        return 'MOFB'; // Molty Ortho Fold-A-Bed
    if (lower.includes('molty firm fold'))
        return 'MFMB'; // Molty Firm Fold-A-Bed
    if (lower.includes('molty foam fold'))
        return 'MFFB'; // Molty Foam Fold-A-Bed
    if (lower.includes('master fold'))
        return 'MAFB'; // Master Fold-A-Bed
    if (lower.includes('jet khi fold'))
        return 'JKFB'; // Jet KHI Fold-A-Bed
    if (lower.includes('molty ortho')) {
        if (lower.includes('ext firm'))
            return 'EFMO';
        return 'MOOR';
    }
    return words.slice(0, 4).map(w => w[0]).join('').toUpperCase().slice(0, 4);
}
function generateSkuCode(brandCode, categoryCode, sizeDisplayLabel, thicknessValue, productLineCodeOrName) {
    const bCode = (brandCode || 'MOLT').replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 4) || 'MOLT';
    const cCode = (categoryCode || 'CAT').replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 4) || 'CAT';
    const plCode = productLineCodeOrName ? generateSmartProductLineAbbr(productLineCodeOrName) : '';
    const sLabel = (sizeDisplayLabel || 'STD')
        .replace(/[\s×xX]/g, 'X')
        .replace(/[^0-9X]/g, '')
        .toUpperCase();
    const tVal = thicknessValue !== undefined && thicknessValue !== null ? String(thicknessValue).replace(/[^0-9]/g, '') : '';
    const spec = tVal ? `${sLabel}-${tVal}` : sLabel;
    return plCode ? `${bCode}-${cCode}-${plCode}-${spec}` : `${bCode}-${cCode}-${spec}`;
}
let masterMetadataCache = null;
const MASTER_METADATA_TTL_MS = 10 * 60 * 1000; // 10 minutes cache
function invalidateMasterMetadataCache() {
    masterMetadataCache = null;
}
async function getMasterMetadata() {
    const now = Date.now();
    if (masterMetadataCache && now - masterMetadataCache.timestamp < MASTER_METADATA_TTL_MS) {
        return masterMetadataCache;
    }
    const [brands, categories, lines, sizes, thicknesses] = await Promise.all([
        index_js_1.Brand.find().select('_id name code description logoUrl status hasThickness').sort({ name: 1 }).lean(),
        index_js_1.Category.find().select('_id name code description status brandId').sort({ name: 1 }).lean(),
        index_js_1.ProductLine.find().select('_id name code description status brandId categoryId').sort({ name: 1 }).lean(),
        index_js_1.Size.find().select('_id displayLabel length width unit status').sort({ length: 1, width: 1 }).lean(),
        index_js_1.Thickness.find().select('_id displayLabel value unit status').sort({ value: 1 }).lean(),
    ]);
    const brandMap = new Map();
    brands.forEach((b) => brandMap.set(b._id.toString(), b));
    const categoryMap = new Map();
    categories.forEach((c) => categoryMap.set(c._id.toString(), c));
    const lineMap = new Map();
    lines.forEach((l) => lineMap.set(l._id.toString(), l));
    const sizeMap = new Map();
    sizes.forEach((s) => sizeMap.set(s._id.toString(), s));
    const thicknessMap = new Map();
    thicknesses.forEach((t) => thicknessMap.set(t._id.toString(), t));
    masterMetadataCache = {
        timestamp: now,
        brands: brands,
        categories: categories,
        lines: lines,
        sizes: sizes,
        thicknesses: thicknesses,
        brandMap,
        categoryMap,
        lineMap,
        sizeMap,
        thicknessMap,
    };
    return masterMetadataCache;
}
class CatalogueService {
    // ==========================================
    // BRANDS
    // ==========================================
    static async getBrands(query = {}) {
        // Ultra-fast in-memory path (< 1ms)
        if (!query?.search && (!query?.branchId || query.branchId === 'ALL')) {
            const meta = await getMasterMetadata();
            if (query?.status && query.status !== 'ALL') {
                return meta.brands.filter((b) => b.status === query.status);
            }
            return meta.brands;
        }
        const filter = {};
        if (query?.status && query.status !== 'ALL') {
            filter.status = query.status;
        }
        if (query?.branchId && query.branchId !== 'ALL' && mongoose_1.default.Types.ObjectId.isValid(query.branchId)) {
            filter.$or = [
                { branchId: new mongoose_1.default.Types.ObjectId(query.branchId) },
                { branchId: { $exists: false } },
                { branchId: null },
            ];
        }
        if (query?.search) {
            const searchOr = [
                { name: { $regex: query.search, $options: 'i' } },
                { code: { $regex: query.search, $options: 'i' } },
            ];
            if (filter.$or) {
                filter.$and = [{ $or: filter.$or }, { $or: searchOr }];
                delete filter.$or;
            }
            else {
                filter.$or = searchOr;
            }
        }
        return index_js_1.Brand.find(filter).sort({ name: 1 }).lean();
    }
    static async getBrandById(id) {
        let brand = null;
        if (mongoose_1.default.Types.ObjectId.isValid(id)) {
            brand = await index_js_1.Brand.findById(id);
        }
        if (!brand) {
            const cleanCode = id.replace(/^BRAND-/i, '').replace(/-\d+$/, '').toUpperCase();
            brand = await index_js_1.Brand.findOne({
                $or: [
                    { code: id.toUpperCase() },
                    { code: cleanCode },
                    { code: { $regex: new RegExp(`^${cleanCode}`, 'i') } },
                ],
            });
        }
        if (!brand)
            throw new apiResponse_js_1.AppError(`Brand '${id}' not found.`, 404, 'BRAND_NOT_FOUND');
        return brand;
    }
    static async createBrand(input) {
        const code = input.code.trim().toUpperCase();
        const existing = await index_js_1.Brand.findOne({ code });
        const targetStatus = input.status ? input.status.toUpperCase() : 'ACTIVE';
        const hasThickness = input.hasThickness !== undefined ? input.hasThickness : true;
        if (existing) {
            if (input.name)
                existing.name = input.name.trim();
            if (input.description !== undefined)
                existing.description = input.description?.trim();
            if (input.logoUrl !== undefined)
                existing.logoUrl = input.logoUrl;
            existing.hasThickness = hasThickness;
            existing.status = targetStatus;
            invalidateMasterMetadataCache();
            return existing.save();
        }
        invalidateMasterMetadataCache();
        return index_js_1.Brand.create({
            code,
            name: input.name.trim(),
            description: input.description?.trim(),
            logoUrl: input.logoUrl,
            hasThickness,
            status: targetStatus,
        });
    }
    static async updateBrand(id, input) {
        const brand = await this.getBrandById(id);
        if (input.code && input.code.toUpperCase() !== brand.code) {
            const existing = await index_js_1.Brand.findOne({ code: input.code.toUpperCase(), _id: { $ne: brand._id } });
            if (existing)
                throw new apiResponse_js_1.AppError(`Brand code '${input.code}' already exists.`, 409, 'DUPLICATE_BRAND_CODE');
            brand.code = input.code.toUpperCase();
        }
        if (input.name)
            brand.name = input.name.trim();
        if (input.description !== undefined)
            brand.description = input.description.trim();
        if (input.logoUrl !== undefined)
            brand.logoUrl = input.logoUrl;
        if (input.hasThickness !== undefined)
            brand.hasThickness = input.hasThickness;
        if (input.status)
            brand.status = input.status.toUpperCase();
        invalidateMasterMetadataCache();
        return brand.save();
    }
    static async toggleBrandStatus(id, status) {
        const brand = await this.getBrandById(id);
        brand.status = status;
        return brand.save();
    }
    static async deleteBrand(id) {
        const brand = await this.getBrandById(id);
        const brandId = brand._id;
        // Find all categories for this brand
        const categories = await index_js_1.Category.find({ brandId });
        const categoryIds = categories.map((c) => c._id);
        // Find all products for this brand
        const products = await index_js_1.Product.find({ $or: [{ brandId }, { categoryId: { $in: categoryIds } }] });
        const productIds = products.map((p) => p._id);
        // Find all variants for these products
        const variants = await index_js_1.Variant.find({ productId: { $in: productIds } });
        const variantIds = variants.map((v) => v._id);
        const skus = variants.map((v) => v.sku);
        // Delete stock balances and price histories for these variants
        await index_js_1.StockBalance.deleteMany({ $or: [{ variantId: { $in: variantIds } }, { sku: { $in: skus } }] });
        await index_js_1.PriceHistory.deleteMany({ variantId: { $in: variantIds } });
        // Delete variants
        await index_js_1.Variant.deleteMany({ _id: { $in: variantIds } });
        // Delete products
        await index_js_1.Product.deleteMany({ _id: { $in: productIds } });
        // Delete categories
        await index_js_1.Category.deleteMany({ _id: { $in: categoryIds } });
        // Delete brand
        await index_js_1.Brand.findByIdAndDelete(brandId);
        return { deleted: true, message: `Brand '${brand.name}' removed successfully.` };
    }
    // ==========================================
    // CATEGORIES
    // ==========================================
    static async getCategories(query = {}) {
        // Ultra-fast in-memory path (< 1ms)
        if (!query?.search && (!query?.branchId || query.branchId === 'ALL')) {
            const meta = await getMasterMetadata();
            let res = meta.categories;
            if (query?.brandId) {
                res = res.filter((c) => c.brandId?.toString() === query.brandId);
            }
            if (query?.status && query.status !== 'ALL') {
                res = res.filter((c) => c.status === query.status);
            }
            return res.map((c) => ({
                ...c,
                brandId: meta.brandMap.get(c.brandId?.toString()) || c.brandId,
            }));
        }
        const filter = {};
        if (query?.brandId) {
            filter.brandId = query.brandId;
        }
        if (query?.status && query.status !== 'ALL') {
            filter.status = query.status;
        }
        if (query?.branchId && query.branchId !== 'ALL' && mongoose_1.default.Types.ObjectId.isValid(query.branchId)) {
            filter.$or = [
                { branchId: new mongoose_1.default.Types.ObjectId(query.branchId) },
                { branchId: { $exists: false } },
                { branchId: null },
            ];
        }
        if (query?.search) {
            const searchOr = [
                { name: { $regex: query.search, $options: 'i' } },
                { code: { $regex: query.search, $options: 'i' } },
            ];
            if (filter.$or) {
                filter.$and = [{ $or: filter.$or }, { $or: searchOr }];
                delete filter.$or;
            }
            else {
                filter.$or = searchOr;
            }
        }
        return index_js_1.Category.find(filter).populate('brandId', 'name code').sort({ name: 1 }).lean();
    }
    static async getCategoryById(id) {
        let category = null;
        if (mongoose_1.default.Types.ObjectId.isValid(id)) {
            category = await index_js_1.Category.findById(id).populate('brandId', 'name code');
        }
        if (!category) {
            const cleanCode = id.replace(/^CAT-/i, '').replace(/-\d+$/, '').toUpperCase();
            category = await index_js_1.Category.findOne({
                $or: [
                    { code: id.toUpperCase() },
                    { code: cleanCode },
                    { code: { $regex: new RegExp(`^${cleanCode}`, 'i') } },
                    { name: id },
                ],
            }).populate('brandId', 'name code');
        }
        if (!category)
            throw new apiResponse_js_1.AppError(`Category '${id}' not found.`, 404, 'CATEGORY_NOT_FOUND');
        return category;
    }
    static async createCategory(input) {
        const brand = await index_js_1.Brand.findById(input.brandId);
        if (!brand)
            throw new apiResponse_js_1.AppError(`Brand '${input.brandId}' does not exist.`, 404, 'BRAND_NOT_FOUND');
        const existing = await index_js_1.Category.findOne({
            brandId: brand._id,
            code: input.code.toUpperCase(),
        });
        if (existing) {
            throw new apiResponse_js_1.AppError(`Category code '${input.code}' already exists under brand '${brand.name}'.`, 409, 'DUPLICATE_CATEGORY_CODE');
        }
        return index_js_1.Category.create({
            brandId: brand._id,
            code: input.code.toUpperCase(),
            name: input.name.trim(),
            description: input.description?.trim(),
            status: 'ACTIVE',
        });
    }
    static async updateCategory(id, input) {
        const category = await this.getCategoryById(id);
        if (input.code && input.code.toUpperCase() !== category.code) {
            const existing = await index_js_1.Category.findOne({
                brandId: category.brandId,
                code: input.code.toUpperCase(),
                _id: { $ne: id },
            });
            if (existing)
                throw new apiResponse_js_1.AppError(`Category code '${input.code}' already exists.`, 409, 'DUPLICATE_CATEGORY_CODE');
            category.code = input.code.toUpperCase();
        }
        if (input.name)
            category.name = input.name.trim();
        if (input.description !== undefined)
            category.description = input.description.trim();
        if (input.status)
            category.status = input.status.toUpperCase();
        return category.save();
    }
    static async toggleCategoryStatus(id, status) {
        const category = await this.getCategoryById(id);
        category.status = status;
        return category.save();
    }
    static async deleteCategory(id) {
        const category = await this.getCategoryById(id);
        const categoryId = category._id;
        // Find products for this category
        const products = await index_js_1.Product.find({ categoryId });
        const productIds = products.map((p) => p._id);
        const variants = await index_js_1.Variant.find({ productId: { $in: productIds } });
        const variantIds = variants.map((v) => v._id);
        const skus = variants.map((v) => v.sku);
        await index_js_1.StockBalance.deleteMany({ $or: [{ variantId: { $in: variantIds } }, { sku: { $in: skus } }] });
        await index_js_1.PriceHistory.deleteMany({ variantId: { $in: variantIds } });
        await index_js_1.Variant.deleteMany({ _id: { $in: variantIds } });
        await index_js_1.Product.deleteMany({ _id: { $in: productIds } });
        await index_js_1.Category.findByIdAndDelete(categoryId);
        return { deleted: true, message: `Category '${category.name}' removed successfully.` };
    }
    // ==========================================
    // PRODUCT LINES (SUB-CATEGORIES)
    // ==========================================
    static async getProductLines(query = {}) {
        // Ultra-fast in-memory path (< 1ms)
        if (!query?.search && (!query?.branchId || query.branchId === 'ALL')) {
            const meta = await getMasterMetadata();
            let res = meta.lines;
            if (query?.brandId) {
                res = res.filter((l) => l.brandId?.toString() === query.brandId);
            }
            if (query?.categoryId) {
                res = res.filter((l) => l.categoryId?.toString() === query.categoryId);
            }
            if (query?.status && query.status !== 'ALL') {
                res = res.filter((l) => l.status === query.status);
            }
            return res.map((l) => ({
                ...l,
                brandId: meta.brandMap.get(l.brandId?.toString()) || l.brandId,
                categoryId: meta.categoryMap.get(l.categoryId?.toString()) || l.categoryId,
            }));
        }
        const filter = {};
        if (query?.brandId) {
            filter.brandId = query.brandId;
        }
        if (query?.categoryId) {
            filter.categoryId = query.categoryId;
        }
        if (query?.status && query.status !== 'ALL') {
            filter.status = query.status;
        }
        if (query?.branchId && query.branchId !== 'ALL' && mongoose_1.default.Types.ObjectId.isValid(query.branchId)) {
            filter.$or = [
                { branchId: new mongoose_1.default.Types.ObjectId(query.branchId) },
                { branchId: { $exists: false } },
                { branchId: null },
            ];
        }
        if (query?.search) {
            const searchOr = [
                { name: { $regex: query.search, $options: 'i' } },
                { code: { $regex: query.search, $options: 'i' } },
            ];
            if (filter.$or) {
                filter.$and = [{ $or: filter.$or }, { $or: searchOr }];
                delete filter.$or;
            }
            else {
                filter.$or = searchOr;
            }
        }
        return index_js_1.ProductLine.find(filter)
            .populate('brandId', 'name code')
            .populate('categoryId', 'name code')
            .sort({ name: 1 })
            .lean();
    }
    static async getProductLineById(id) {
        let productLine = null;
        if (mongoose_1.default.Types.ObjectId.isValid(id)) {
            productLine = await index_js_1.ProductLine.findById(id)
                .populate('brandId', 'name code')
                .populate('categoryId', 'name code');
        }
        if (!productLine) {
            const cleanCode = id.replace(/^PL-/i, '').replace(/-\d+$/, '').toUpperCase();
            productLine = await index_js_1.ProductLine.findOne({
                $or: [
                    { code: id.toUpperCase() },
                    { code: cleanCode },
                    { code: { $regex: new RegExp(`^${cleanCode}`, 'i') } },
                    { name: id },
                ],
            })
                .populate('brandId', 'name code')
                .populate('categoryId', 'name code');
        }
        if (!productLine)
            throw new apiResponse_js_1.AppError(`Product Line '${id}' not found.`, 404, 'PRODUCT_LINE_NOT_FOUND');
        return productLine;
    }
    static async createProductLine(input) {
        const [brand, category] = await Promise.all([
            index_js_1.Brand.findById(input.brandId),
            index_js_1.Category.findById(input.categoryId),
        ]);
        if (!brand)
            throw new apiResponse_js_1.AppError(`Brand '${input.brandId}' does not exist.`, 404, 'BRAND_NOT_FOUND');
        if (!category)
            throw new apiResponse_js_1.AppError(`Category '${input.categoryId}' does not exist.`, 404, 'CATEGORY_NOT_FOUND');
        const existing = await index_js_1.ProductLine.findOne({
            brandId: brand._id,
            categoryId: category._id,
            name: new RegExp(`^${input.name.trim()}$`, 'i'),
        });
        if (existing) {
            throw new apiResponse_js_1.AppError(`Product Line '${input.name}' already exists under category '${category.name}'.`, 409, 'DUPLICATE_PRODUCT_LINE');
        }
        return index_js_1.ProductLine.create({
            brandId: brand._id,
            categoryId: category._id,
            code: input.code.toUpperCase(),
            name: input.name.trim(),
            description: input.description?.trim(),
            imageUrl: input.imageUrl?.trim() || '',
            status: 'ACTIVE',
            ...(input.branchId ? { branchId: input.branchId } : {}),
        });
    }
    static async updateProductLine(id, input) {
        const productLine = await this.getProductLineById(id);
        if (input.code && input.code.toUpperCase() !== productLine.code) {
            const existing = await index_js_1.ProductLine.findOne({
                code: input.code.toUpperCase(),
                _id: { $ne: id },
            });
            if (existing)
                throw new apiResponse_js_1.AppError(`Product Line code '${input.code}' already exists.`, 409, 'DUPLICATE_PRODUCT_LINE_CODE');
            productLine.code = input.code.toUpperCase();
        }
        const targetBrandId = input.brandId || productLine.brandId;
        const targetCategoryId = input.categoryId || productLine.categoryId;
        const targetName = input.name ? input.name.trim() : productLine.name;
        if (input.name || input.brandId || input.categoryId) {
            const existingName = await index_js_1.ProductLine.findOne({
                brandId: targetBrandId,
                categoryId: targetCategoryId,
                name: { $regex: new RegExp(`^${targetName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') },
                _id: { $ne: id },
            });
            if (existingName) {
                throw new apiResponse_js_1.AppError(`A product line named '${targetName}' already exists for this brand and category (Code: ${existingName.code}).`, 409, 'DUPLICATE_PRODUCT_LINE_NAME');
            }
        }
        if (input.name)
            productLine.name = input.name.trim();
        if (input.description !== undefined)
            productLine.description = input.description?.trim();
        if (input.imageUrl !== undefined)
            productLine.imageUrl = input.imageUrl?.trim() || '';
        if (input.brandId)
            productLine.brandId = input.brandId;
        if (input.categoryId)
            productLine.categoryId = input.categoryId;
        if (input.status)
            productLine.status = input.status.toUpperCase();
        return productLine.save();
    }
    static async toggleProductLineStatus(id, status) {
        const productLine = await this.getProductLineById(id);
        productLine.status = status;
        return productLine.save();
    }
    static async deleteProductLine(id) {
        const productLine = await this.getProductLineById(id);
        const productLineId = productLine._id;
        // Find products for this product line
        const products = await index_js_1.Product.find({ productLineId });
        const productIds = products.map((p) => p._id);
        const variants = await index_js_1.Variant.find({ productId: { $in: productIds } });
        const variantIds = variants.map((v) => v._id);
        const skus = variants.map((v) => v.sku);
        await index_js_1.StockBalance.deleteMany({ $or: [{ variantId: { $in: variantIds } }, { sku: { $in: skus } }] });
        await index_js_1.PriceHistory.deleteMany({ variantId: { $in: variantIds } });
        await index_js_1.Variant.deleteMany({ _id: { $in: variantIds } });
        await index_js_1.Product.deleteMany({ _id: { $in: productIds } });
        await index_js_1.ProductLine.findByIdAndDelete(productLineId);
        return { deleted: true, message: `Product Line '${productLine.name}' removed successfully.` };
    }
    // ==========================================
    // SIZES
    // ==========================================
    static async getSizes(query) {
        const meta = await getMasterMetadata();
        if (query?.status && query.status !== 'ALL') {
            return meta.sizes.filter((s) => s.status === query.status);
        }
        return meta.sizes;
    }
    static async createSize(input) {
        const existing = await index_js_1.Size.findOne({
            length: input.length,
            width: input.width,
            unit: input.unit || 'in',
        });
        const targetStatus = input.status ? input.status.toUpperCase() : 'ACTIVE';
        invalidateMasterMetadataCache();
        if (existing) {
            if (input.displayLabel)
                existing.displayLabel = input.displayLabel.trim();
            existing.status = targetStatus;
            return existing.save();
        }
        return index_js_1.Size.create({
            length: input.length,
            width: input.width,
            unit: input.unit || 'in',
            displayLabel: input.displayLabel.trim(),
            status: targetStatus,
        });
    }
    static async getSizeById(id) {
        let size = null;
        if (mongoose_1.default.Types.ObjectId.isValid(id)) {
            size = await index_js_1.Size.findById(id);
        }
        if (!size) {
            size = await index_js_1.Size.findOne({
                $or: [{ displayLabel: id }, { displayLabel: { $regex: new RegExp(`^${id}`, 'i') } }],
            });
        }
        if (!size)
            throw new apiResponse_js_1.AppError(`Size '${id}' not found.`, 404, 'SIZE_NOT_FOUND');
        return size;
    }
    static async updateSize(id, input) {
        const size = await this.getSizeById(id);
        if (input.displayLabel)
            size.displayLabel = input.displayLabel.trim();
        if (input.length)
            size.length = input.length;
        if (input.width)
            size.width = input.width;
        if (input.unit)
            size.unit = input.unit;
        if (input.status)
            size.status = input.status.toUpperCase();
        invalidateMasterMetadataCache();
        return size.save();
    }
    static async toggleSizeStatus(id, status) {
        const size = await this.getSizeById(id);
        size.status = status;
        invalidateMasterMetadataCache();
        return size.save();
    }
    static async deleteSize(id) {
        const size = await this.getSizeById(id);
        const sizeId = size._id;
        const variants = await index_js_1.Variant.find({ sizeId });
        const variantIds = variants.map((v) => v._id);
        const skus = variants.map((v) => v.sku);
        await index_js_1.StockBalance.deleteMany({ $or: [{ variantId: { $in: variantIds } }, { sku: { $in: skus } }] });
        await index_js_1.PriceHistory.deleteMany({ variantId: { $in: variantIds } });
        await index_js_1.Variant.deleteMany({ _id: { $in: variantIds } });
        await index_js_1.Size.findByIdAndDelete(sizeId);
        invalidateMasterMetadataCache();
        return { deleted: true, message: `Size '${size.displayLabel}' removed successfully.` };
    }
    // ==========================================
    // THICKNESSES
    // ==========================================
    static async getThicknesses(query) {
        const meta = await getMasterMetadata();
        if (query?.status && query.status !== 'ALL') {
            return meta.thicknesses.filter((t) => t.status === query.status);
        }
        return meta.thicknesses;
    }
    static async getThicknessById(id) {
        let thickness = null;
        if (mongoose_1.default.Types.ObjectId.isValid(id)) {
            thickness = await index_js_1.Thickness.findById(id);
        }
        if (!thickness) {
            thickness = await index_js_1.Thickness.findOne({
                $or: [{ displayLabel: id }, { value: isNaN(Number(id)) ? -1 : Number(id) }],
            });
        }
        if (!thickness)
            throw new apiResponse_js_1.AppError(`Thickness '${id}' not found.`, 404, 'THICKNESS_NOT_FOUND');
        return thickness;
    }
    static async createThickness(input) {
        const existing = await index_js_1.Thickness.findOne({ value: input.value });
        const targetStatus = input.status ? input.status.toUpperCase() : 'ACTIVE';
        invalidateMasterMetadataCache();
        if (existing) {
            if (input.displayLabel)
                existing.displayLabel = input.displayLabel.trim();
            existing.status = targetStatus;
            return existing.save();
        }
        return index_js_1.Thickness.create({
            value: input.value,
            unit: input.unit || 'in',
            displayLabel: input.displayLabel.trim(),
            status: targetStatus,
        });
    }
    static async updateThickness(id, input) {
        const thickness = await this.getThicknessById(id);
        if (input.displayLabel)
            thickness.displayLabel = input.displayLabel.trim();
        if (input.value)
            thickness.value = input.value;
        if (input.unit)
            thickness.unit = input.unit;
        if (input.status)
            thickness.status = input.status.toUpperCase();
        invalidateMasterMetadataCache();
        return thickness.save();
    }
    static async toggleThicknessStatus(id, status) {
        const thickness = await this.getThicknessById(id);
        thickness.status = status;
        invalidateMasterMetadataCache();
        return thickness.save();
    }
    static async deleteThickness(id) {
        const thickness = await this.getThicknessById(id);
        const thicknessId = thickness._id;
        const variants = await index_js_1.Variant.find({ thicknessId });
        const variantIds = variants.map((v) => v._id);
        const skus = variants.map((v) => v.sku);
        await index_js_1.StockBalance.deleteMany({ $or: [{ variantId: { $in: variantIds } }, { sku: { $in: skus } }] });
        await index_js_1.PriceHistory.deleteMany({ variantId: { $in: variantIds } });
        await index_js_1.Variant.deleteMany({ _id: { $in: variantIds } });
        await index_js_1.Thickness.findByIdAndDelete(thicknessId);
        return { deleted: true, message: `Thickness '${thickness.displayLabel}' removed successfully.` };
    }
    // ==========================================
    // PRODUCTS & SIMPLIFIED PRODUCT CREATION
    // ==========================================
    static async getProducts(query) {
        const page = Math.max(1, query.page || 1);
        const limit = Math.max(1, Math.min(1000, query.limit || 10));
        const skip = (page - 1) * limit;
        const filter = {};
        if (query.status && query.status !== 'ALL') {
            filter.status = query.status;
        }
        if (query.brandId) {
            filter.brandId = query.brandId;
        }
        if (query.categoryId) {
            filter.categoryId = query.categoryId;
        }
        if (query.productLineId) {
            filter.productLineId = query.productLineId;
        }
        if (query.search) {
            filter.name = { $regex: query.search, $options: 'i' };
        }
        if (query.branchId && query.branchId !== 'ALL' && mongoose_1.default.Types.ObjectId.isValid(query.branchId)) {
            filter.$or = [
                { branchId: new mongoose_1.default.Types.ObjectId(query.branchId) },
                { branchId: { $exists: false } },
                { branchId: null },
            ];
        }
        const meta = await getMasterMetadata();
        const [products, total] = await Promise.all([
            index_js_1.Product.find(filter)
                .populate('branchId', 'name code shopNumber city')
                .sort({ name: 1 })
                .skip(skip)
                .limit(limit)
                .lean(),
            index_js_1.Product.countDocuments(filter),
        ]);
        // Populate variants for each product on this slice
        const productIds = products.map((p) => p._id);
        const variants = await index_js_1.Variant.find({ productId: { $in: productIds } })
            .sort({ sku: 1 })
            .lean();
        const variantsByProduct = new Map();
        for (const v of variants) {
            const pId = v.productId.toString();
            const sId = v.sizeId ? v.sizeId.toString() : '';
            const tId = v.thicknessId ? v.thicknessId.toString() : '';
            const sizeObj = meta.sizeMap.get(sId);
            const thickObj = meta.thicknessMap.get(tId);
            if (!variantsByProduct.has(pId))
                variantsByProduct.set(pId, []);
            variantsByProduct.get(pId).push({
                id: v._id.toString(),
                sku: v.sku,
                productId: pId,
                size: sizeObj || null,
                sizeId: sId,
                thickness: thickObj || null,
                thicknessId: tId,
                listPrice: (0, financial_js_1.toRupees)(v.listPrice),
                purchasePrice: (0, financial_js_1.toRupees)(v.purchasePrice),
                retailPrice: (0, financial_js_1.toRupees)(v.retailPrice),
                wholesalePrice: (0, financial_js_1.toRupees)(v.wholesalePrice),
                distributorPrice: (0, financial_js_1.toRupees)(v.distributorPrice || 0),
                posDisplayName: v.posDisplayName || '',
                notes: v.notes || '',
                status: v.status,
            });
        }
        const items = products.map((p) => {
            const b = meta.brandMap.get(p.brandId?.toString()) || p.brandId;
            const c = meta.categoryMap.get(p.categoryId?.toString()) || p.categoryId;
            const pl = meta.lineMap.get(p.productLineId?.toString()) || p.productLineId;
            const bCode = b?.code || 'MF';
            const cCode = c?.code || 'CAT';
            const code = p.code || `${bCode}-${cCode}`.toUpperCase();
            const bId = b?._id ? b._id.toString() : b?.toString() || '';
            const cId = c?._id ? c._id.toString() : c?.toString() || '';
            const plId = pl?._id ? pl._id.toString() : pl?.toString() || '';
            const plImage = (pl && typeof pl === 'object' && pl.imageUrl) ? pl.imageUrl : (p.imageUrl || undefined);
            return {
                id: p._id.toString(),
                name: p.name,
                code,
                brandId: bId,
                categoryId: cId,
                productLineId: plId || undefined,
                productLine: pl,
                imageUrl: plImage,
                branchId: p.branchId?._id ? p.branchId._id.toString() : p.branchId?.toString() || undefined,
                branch: p.branchId,
                brand: b,
                category: c,
                status: p.status,
                variants: variantsByProduct.get(p._id.toString()) || [],
                createdAt: p.createdAt,
            };
        });
        return {
            items,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit),
            },
        };
    }
    static async getProductById(id) {
        const product = await index_js_1.Product.findById(id)
            .populate('brandId', 'name code logoUrl')
            .populate('categoryId', 'name code')
            .populate('productLineId', 'name code imageUrl');
        if (!product)
            throw new apiResponse_js_1.AppError(`Product '${id}' not found.`, 404, 'PRODUCT_NOT_FOUND');
        const variants = await index_js_1.Variant.find({ productId: product._id })
            .populate('sizeId', 'length width displayLabel')
            .populate('thicknessId', 'value displayLabel');
        return {
            id: product._id.toString(),
            name: product.name,
            brand: product.brandId,
            category: product.categoryId,
            productLine: product.productLineId,
            status: product.status,
            variants: variants.map((v) => ({
                id: v._id.toString(),
                sku: v.sku,
                size: v.sizeId,
                thickness: v.thicknessId,
                listPrice: (0, financial_js_1.toRupees)(v.listPrice),
                purchasePrice: (0, financial_js_1.toRupees)(v.purchasePrice),
                purchaseDiscountPercent: v.purchaseDiscountPercent,
                retailPrice: (0, financial_js_1.toRupees)(v.retailPrice),
                retailMarkupPercent: v.retailMarkupPercent,
                wholesalePrice: (0, financial_js_1.toRupees)(v.wholesalePrice),
                wholesaleDiscountPercent: v.wholesaleDiscountPercent,
                distributorPrice: (0, financial_js_1.toRupees)(v.distributorPrice || 0),
                distributorDiscountPercent: v.distributorDiscountPercent,
                posDisplayName: v.posDisplayName || '',
                notes: v.notes || '',
                status: v.status,
            })),
            createdAt: product.createdAt,
        };
    }
    static async resolvePrimaryBranchAndLocation(callerBranchId, destinationBranchId) {
        let branch = null;
        if (destinationBranchId && mongoose_1.default.Types.ObjectId.isValid(destinationBranchId)) {
            branch = await index_js_1.Branch.findById(destinationBranchId);
        }
        if (!branch && callerBranchId && mongoose_1.default.Types.ObjectId.isValid(callerBranchId)) {
            branch = await index_js_1.Branch.findById(callerBranchId);
        }
        if (!branch) {
            branch =
                (await index_js_1.Branch.findOne({ $or: [{ code: 'MAIN' }, { isMain: true }, { code: 'SHOP-12' }] })) ||
                    (await index_js_1.Branch.findOne({ isActive: true })) ||
                    (await index_js_1.Branch.findOne());
        }
        if (!branch)
            return null;
        let location = await index_js_1.StockLocation.findOne({
            branchId: branch._id,
            $or: [{ code: 'MAIN-LOC-01' }, { code: 'LOC-FLOOR' }, { type: 'SALES_FLOOR' }],
        });
        if (!location) {
            location = await index_js_1.StockLocation.findOne({ branchId: branch._id });
        }
        if (!location) {
            location = await index_js_1.StockLocation.create({
                branchId: branch._id,
                name: `${branch.name} Sales Floor`,
                code: `${branch.code || 'LOC'}-FLOOR`,
                type: 'SALES_FLOOR',
                status: 'ACTIVE',
            });
        }
        return { branch, location };
    }
    /**
     * Main Simplified Product Creation Workflow:
     * Brand -> Category -> Size -> Thickness -> Pricing -> Opening Stock
     */
    static async createProductWithVariant(input, accountId, callerBranchId) {
        // 1. Resolve master entities
        const resolveEntity = async (model, idOrCode) => {
            if (!idOrCode)
                return null;
            if (mongoose_1.default.Types.ObjectId.isValid(idOrCode)) {
                const doc = await model.findById(idOrCode);
                if (doc)
                    return doc;
            }
            return await model.findOne({
                $or: [
                    { code: idOrCode },
                    { name: idOrCode },
                    { displayLabel: idOrCode },
                ],
            });
        };
        const [brand, category, productLine, size, thickness] = await Promise.all([
            resolveEntity(index_js_1.Brand, input.brandId),
            resolveEntity(index_js_1.Category, input.categoryId),
            input.productLineId ? resolveEntity(index_js_1.ProductLine, input.productLineId) : Promise.resolve(null),
            resolveEntity(index_js_1.Size, input.sizeId),
            input.thicknessId ? resolveEntity(index_js_1.Thickness, input.thicknessId) : Promise.resolve(null),
        ]);
        if (!brand || brand.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Brand not found or inactive.', 400, 'INVALID_BRAND');
        }
        if (!category || category.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Category not found or inactive.', 400, 'INVALID_CATEGORY');
        }
        if (category.brandId.toString() !== brand._id.toString()) {
            throw new apiResponse_js_1.AppError(`Category '${category.name}' does not belong to Brand '${brand.name}'.`, 400, 'CATEGORY_BRAND_MISMATCH');
        }
        if (!size || size.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Size not found or inactive.', 400, 'INVALID_SIZE');
        }
        const brandRequiresThickness = brand.hasThickness !== false;
        if (brandRequiresThickness) {
            if (!thickness || thickness.status !== 'ACTIVE') {
                throw new apiResponse_js_1.AppError(`Thickness is required for Brand '${brand.name}'.`, 400, 'INVALID_THICKNESS');
            }
        }
        // 2. Resolve primary branch and location for opening stock & product association
        const branchAndLoc = await this.resolvePrimaryBranchAndLocation(callerBranchId, input.destinationBranchId);
        const targetBranch = branchAndLoc?.branch;
        if (!targetBranch) {
            throw new apiResponse_js_1.AppError('A valid branch must be selected to register this product.', 400, 'BRANCH_REQUIRED');
        }
        // Generate Product Name: Product Line Name (or Brand Name + Category Name if no line)
        const productName = productLine ? productLine.name : `${brand.name} - ${category.name}`;
        // 3. Generate unique SKU and validate variant does not already exist BEFORE touching products
        const plIdentifier = productLine?.name || productLine?.code || '';
        const sku = generateSkuCode(brand.code, category.code, size.displayLabel, thickness ? thickness.value : undefined, plIdentifier);
        const existingVariant = await index_js_1.Variant.findOne({ sku });
        if (existingVariant) {
            const thickText = thickness?.displayLabel ? `, ${thickness.displayLabel}` : '';
            throw new apiResponse_js_1.AppError(`A variant with SKU '${sku}' (${productName}, ${size.displayLabel}${thickText}) already exists.`, 409, 'SKU_ALREADY_EXISTS');
        }
        // 4. Compute and Reconcile Authoritative Integer-Paisa Pricing BEFORE creating product
        const listPricePaisa = (0, financial_js_1.toPaisa)(input.listPrice);
        if (listPricePaisa <= 0) {
            throw new apiResponse_js_1.AppError('List Price must be greater than zero.', 400, 'INVALID_LIST_PRICE');
        }
        // Purchase Price
        let purchasePricePaisa = 0;
        let purchaseDiscountPercent = input.purchasePercent ?? 0;
        if (input.purchasePrice !== undefined) {
            purchasePricePaisa = (0, financial_js_1.toPaisa)(input.purchasePrice);
            purchaseDiscountPercent = (0, financial_js_1.calculateDiscountPercent)(listPricePaisa, purchasePricePaisa);
        }
        else {
            purchasePricePaisa = (0, financial_js_1.calculatePurchasePrice)(listPricePaisa, purchaseDiscountPercent);
        }
        // Retail Price
        let retailPricePaisa = 0;
        let retailMarkupPercent = input.retailPercent ?? 0;
        if (input.retailPrice !== undefined) {
            retailPricePaisa = (0, financial_js_1.toPaisa)(input.retailPrice);
            retailMarkupPercent = (0, financial_js_1.calculateMarkupPercent)(listPricePaisa, retailPricePaisa);
        }
        else {
            retailPricePaisa = (0, financial_js_1.calculateRetailPrice)(listPricePaisa, retailMarkupPercent);
        }
        // Wholesale Price
        let wholesalePricePaisa = 0;
        let wholesaleDiscountPercent = input.wholesalePercent ?? 0;
        if (input.wholesalePrice !== undefined) {
            wholesalePricePaisa = (0, financial_js_1.toPaisa)(input.wholesalePrice);
            wholesaleDiscountPercent = (0, financial_js_1.calculateDiscountPercent)(listPricePaisa, wholesalePricePaisa);
        }
        else {
            wholesalePricePaisa = (0, financial_js_1.calculateWholesalePrice)(listPricePaisa, wholesaleDiscountPercent);
        }
        // Distributor Price
        let distributorPricePaisa = 0;
        let distributorDiscountPercent = input.distributorPercent ?? 0;
        if (input.distributorPrice !== undefined) {
            distributorPricePaisa = (0, financial_js_1.toPaisa)(input.distributorPrice);
            distributorDiscountPercent = (0, financial_js_1.calculateDiscountPercent)(listPricePaisa, distributorPricePaisa);
        }
        else {
            distributorPricePaisa = (0, financial_js_1.calculateDistributorPrice)(listPricePaisa, distributorDiscountPercent);
        }
        // Find or create base Product (scoped strictly to target branch and productLine if present)
        let isNewlyCreatedProduct = false;
        const productQuery = {
            brandId: brand._id,
            categoryId: category._id,
            branchId: targetBranch._id,
        };
        if (productLine) {
            productQuery.productLineId = productLine._id;
        }
        let product = await index_js_1.Product.findOne(productQuery);
        if (!product) {
            product = await index_js_1.Product.create({
                brandId: brand._id,
                categoryId: category._id,
                ...(productLine ? { productLineId: productLine._id } : {}),
                name: productName,
                branchId: targetBranch._id,
                imageUrl: input.imageUrl?.trim() || '',
                status: 'ACTIVE',
            });
            isNewlyCreatedProduct = true;
        }
        else if (input.imageUrl && input.imageUrl.trim()) {
            product.imageUrl = input.imageUrl.trim();
            await product.save();
        }
        let variant;
        try {
            // 5. Create Variant
            variant = await index_js_1.Variant.create({
                productId: product._id,
                sizeId: size._id,
                ...(thickness ? { thicknessId: thickness._id } : {}),
                sku,
                listPrice: listPricePaisa,
                purchasePrice: purchasePricePaisa,
                purchaseDiscountPercent,
                retailPrice: retailPricePaisa,
                retailMarkupPercent,
                wholesalePrice: wholesalePricePaisa,
                wholesaleDiscountPercent,
                distributorPrice: distributorPricePaisa,
                distributorDiscountPercent,
                status: 'ACTIVE',
            });
            // 6. Record Initial Price History
            const accountObjectId = accountId && mongoose_1.default.Types.ObjectId.isValid(accountId)
                ? new mongoose_1.default.Types.ObjectId(accountId)
                : undefined;
            await index_js_1.PriceHistory.insertMany([
                {
                    variantId: variant._id,
                    sku,
                    tier: 'LIST',
                    previousPrice: 0,
                    newPrice: listPricePaisa,
                    changedByAccountId: accountObjectId,
                    reason: 'Initial Product Catalogue Registration',
                },
                {
                    variantId: variant._id,
                    sku,
                    tier: 'PURCHASE',
                    previousPrice: 0,
                    newPrice: purchasePricePaisa,
                    newPercent: purchaseDiscountPercent,
                    changedByAccountId: accountObjectId,
                    reason: 'Initial Product Catalogue Registration',
                },
                {
                    variantId: variant._id,
                    sku,
                    tier: 'RETAIL',
                    previousPrice: 0,
                    newPrice: retailPricePaisa,
                    newPercent: retailMarkupPercent,
                    changedByAccountId: accountObjectId,
                    reason: 'Initial Product Catalogue Registration',
                },
                {
                    variantId: variant._id,
                    sku,
                    tier: 'WHOLESALE',
                    previousPrice: 0,
                    newPrice: wholesalePricePaisa,
                    newPercent: wholesaleDiscountPercent,
                    changedByAccountId: accountObjectId,
                    reason: 'Initial Product Catalogue Registration',
                },
                {
                    variantId: variant._id,
                    sku,
                    tier: 'DISTRIBUTOR',
                    previousPrice: 0,
                    newPrice: distributorPricePaisa,
                    newPercent: distributorDiscountPercent,
                    changedByAccountId: accountObjectId,
                    reason: 'Initial Product Catalogue Registration',
                },
            ]);
            // 7. Initial Stock Balance Handling
            const stockQty = Math.max(0, input.stock || 0);
            const minStockQty = input.minimumStock !== undefined ? Math.max(0, input.minimumStock) : 5;
            let initialStockCreated = false;
            if (branchAndLoc) {
                const { branch: targetBranch, location: floorLocation } = branchAndLoc;
                let stockBalance = await index_js_1.StockBalance.findOne({
                    branchId: targetBranch._id,
                    stockLocationId: floorLocation._id,
                    sku,
                });
                if (!stockBalance) {
                    stockBalance = await index_js_1.StockBalance.create({
                        branchId: targetBranch._id,
                        stockLocationId: floorLocation._id,
                        sku,
                        variantId: variant._id,
                        onHand: stockQty,
                        reserved: 0,
                        reorderLevel: minStockQty,
                    });
                }
                else {
                    stockBalance.onHand = stockQty;
                    stockBalance.reorderLevel = minStockQty;
                    stockBalance.variantId = variant._id;
                    await stockBalance.save();
                }
                if (stockQty > 0) {
                    await index_js_1.StockMovement.create({
                        movementNumber: `MOV-INIT-${sku}-${Date.now().toString().slice(-6)}`,
                        branchId: targetBranch._id,
                        stockLocationId: floorLocation._id,
                        sku,
                        movementType: 'OPENING_BALANCE',
                        quantityDifference: stockQty,
                        previousBalance: 0,
                        newBalance: stockQty,
                        referenceType: 'OPENING_BALANCE',
                        reason: 'Product catalogue opening stock registration',
                        performedBy: accountId || 'System',
                        timestamp: new Date(),
                    });
                }
                initialStockCreated = true;
            }
            return {
                product: {
                    id: product._id.toString(),
                    name: product.name,
                    brand: { id: brand._id.toString(), name: brand.name, code: brand.code },
                    category: { id: category._id.toString(), name: category.name, code: category.code },
                },
                variant: {
                    id: variant._id.toString(),
                    sku: variant.sku,
                    size: { id: size._id.toString(), label: size.displayLabel },
                    thickness: { id: thickness._id.toString(), label: thickness.displayLabel },
                    listPrice: (0, financial_js_1.toRupees)(variant.listPrice),
                    purchasePrice: (0, financial_js_1.toRupees)(variant.purchasePrice),
                    purchaseDiscountPercent: variant.purchaseDiscountPercent,
                    retailPrice: (0, financial_js_1.toRupees)(variant.retailPrice),
                    retailMarkupPercent: variant.retailMarkupPercent,
                    wholesalePrice: (0, financial_js_1.toRupees)(variant.wholesalePrice),
                    wholesaleDiscountPercent: variant.wholesaleDiscountPercent,
                    distributorPrice: (0, financial_js_1.toRupees)(variant.distributorPrice || 0),
                    distributorDiscountPercent: variant.distributorDiscountPercent,
                    initialStockCommitted: initialStockCreated,
                    onHand: input.stock || 0,
                    minimumStock: input.minimumStock ?? 5,
                },
            };
        }
        catch (variantErr) {
            // Rollback newly created product if variant creation or stock balance failed
            if (isNewlyCreatedProduct && product?._id) {
                await index_js_1.Product.findByIdAndDelete(product._id).catch(() => { });
            }
            throw variantErr;
        }
    }
    // ==========================================
    // SKUs & PRICING
    // ==========================================
    static async getSkus(query, isSuperAdmin = false) {
        const andConditions = [];
        if (query.productId) {
            andConditions.push({ productId: query.productId });
        }
        if (isSuperAdmin) {
            if (query.status && query.status !== 'ALL') {
                andConditions.push({ status: query.status });
            }
        }
        else {
            // Non-admin branch accounts are strictly restricted to ACTIVE catalogue records
            andConditions.push({ status: 'ACTIVE' });
        }
        if (query.branchId && query.branchId !== 'ALL' && mongoose_1.default.Types.ObjectId.isValid(query.branchId)) {
            const branchProducts = await index_js_1.Product.find({ branchId: new mongoose_1.default.Types.ObjectId(query.branchId) }).select('_id').lean();
            const branchProductIds = branchProducts.map((p) => p._id);
            andConditions.push({ productId: { $in: branchProductIds } });
        }
        // Direct Brand / Category / ProductLine filters
        if (query.brandId || query.categoryId || query.productLineId) {
            const prodQuery = {};
            if (query.brandId)
                prodQuery.brandId = query.brandId;
            if (query.categoryId)
                prodQuery.categoryId = query.categoryId;
            if (query.productLineId)
                prodQuery.productLineId = query.productLineId;
            const matchingProductDocs = await index_js_1.Product.find(prodQuery).select('_id').lean();
            const pIds = matchingProductDocs.map((p) => p._id);
            andConditions.push({ productId: { $in: pIds } });
        }
        // Multi-dimensional High-Speed Search Engine (Memory-cached dictionaries + indexed lookup)
        if (query.search && query.search.trim()) {
            const rawTerm = query.search.trim();
            const escapedTerm = rawTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(escapedTerm, 'i');
            // 1. Instant resolution from server in-memory master cache (< 0.1ms without 5 DB round-trips)
            const meta = await getMasterMetadata();
            const mBrands = meta.brands.filter((b) => regex.test(b.name));
            const mCategories = meta.categories.filter((c) => regex.test(c.name));
            const mLines = meta.lines.filter((l) => regex.test(l.name));
            const mSizes = meta.sizes.filter((s) => regex.test(s.displayLabel) ||
                (s.length && s.width && regex.test(`${s.length}x${s.width}`)) ||
                (s.length && s.width && regex.test(`${s.length} × ${s.width}`)));
            const mThicknesses = meta.thicknesses.filter((t) => regex.test(t.displayLabel) || (t.value !== undefined && regex.test(String(t.value))));
            // 2. Targeted product query
            const mProductFilter = {
                $or: [
                    { name: regex },
                    ...(mBrands.length > 0 ? [{ brandId: { $in: mBrands.map((b) => b._id) } }] : []),
                    ...(mCategories.length > 0 ? [{ categoryId: { $in: mCategories.map((c) => c._id) } }] : []),
                    ...(mLines.length > 0 ? [{ productLineId: { $in: mLines.map((l) => l._id) } }] : []),
                ],
            };
            const mProducts = await index_js_1.Product.find(mProductFilter).select('_id').lean();
            const searchOrClauses = [
                { sku: regex },
                { posDisplayName: regex },
            ];
            if (mProducts.length > 0) {
                searchOrClauses.push({ productId: { $in: mProducts.map((p) => p._id) } });
            }
            if (mSizes.length > 0) {
                searchOrClauses.push({ sizeId: { $in: mSizes.map((s) => s._id) } });
            }
            if (mThicknesses.length > 0) {
                searchOrClauses.push({ thicknessId: { $in: mThicknesses.map((t) => t._id) } });
            }
            andConditions.push({ $or: searchOrClauses });
        }
        // Stock Status filter ('IN_STOCK' or 'OUT_OF_STOCK')
        if (query.stockStatus === 'IN_STOCK' || query.stockStatus === 'in_stock') {
            const stockCriteria = { onHand: { $gt: 0 } };
            if (query.branchId)
                stockCriteria.branchId = query.branchId;
            const inStockBalances = await index_js_1.StockBalance.find(stockCriteria).select('variantId sku').lean();
            const inStockVariantIds = inStockBalances.map((s) => s.variantId).filter(Boolean);
            const inStockSkus = inStockBalances.map((s) => s.sku).filter(Boolean);
            andConditions.push({
                $or: [
                    { _id: { $in: inStockVariantIds } },
                    { sku: { $in: inStockSkus } },
                ],
            });
        }
        else if (query.stockStatus === 'OUT_OF_STOCK' || query.stockStatus === 'out_of_stock') {
            const stockCriteria = { onHand: { $gt: 0 } };
            if (query.branchId)
                stockCriteria.branchId = query.branchId;
            const inStockBalances = await index_js_1.StockBalance.find(stockCriteria).select('variantId sku').lean();
            const inStockVariantIds = inStockBalances.map((s) => s.variantId).filter(Boolean);
            const inStockSkus = inStockBalances.map((s) => s.sku).filter(Boolean);
            andConditions.push({
                _id: { $nin: inStockVariantIds },
                sku: { $nin: inStockSkus },
            });
        }
        else if (query.stockStatus === 'LOW_STOCK' || query.stockStatus === 'low_stock') {
            const stockCriteria = { onHand: { $gt: 0 } };
            if (query.branchId)
                stockCriteria.branchId = query.branchId;
            const candidateBalances = await index_js_1.StockBalance.find(stockCriteria).select('variantId sku onHand reserved reorderLevel').lean();
            const lowStockVariantIds = [];
            const lowStockSkus = [];
            candidateBalances.forEach((sb) => {
                const onHand = sb.onHand || 0;
                const reserved = sb.reserved || 0;
                const available = Math.max(0, onHand - reserved);
                const reorder = sb.reorderLevel ?? 5;
                if (available > 0 && available <= reorder) {
                    if (sb.variantId)
                        lowStockVariantIds.push(sb.variantId);
                    if (sb.sku)
                        lowStockSkus.push(sb.sku);
                }
            });
            andConditions.push({
                $or: [
                    { _id: { $in: lowStockVariantIds } },
                    { sku: { $in: lowStockSkus } },
                ],
            });
        }
        const filter = andConditions.length > 0 ? { $and: andConditions } : {};
        const meta = await getMasterMetadata();
        // 3. Paginated Query Builder - ultra-lean
        let queryBuilder = index_js_1.Variant.find(filter)
            .populate('productId', 'name brandId categoryId productLineId branchId')
            .sort({ sku: 1 });
        const page = Math.max(1, query.page || 1);
        const isPaginated = Boolean(query.page || (query.limit && query.limit > 0));
        const isFetchAll = query.all === true || query.limit === -1 || query.limit === 0 || !isPaginated;
        const limit = isFetchAll ? 0 : (query.limit && query.limit > 0 ? query.limit : 10);
        if (limit > 0) {
            const skip = (page - 1) * limit;
            queryBuilder = queryBuilder.skip(skip).limit(limit);
        }
        // Parallel count & query execution (concurrency cuts latency by 50%)
        const [total, activeCount, variants] = await Promise.all([
            index_js_1.Variant.countDocuments(filter),
            index_js_1.Variant.countDocuments({ ...filter, status: 'ACTIVE' }),
            queryBuilder.lean(),
        ]);
        // 4. Stock balances only for the returned slice of items
        const variantIds = variants.map((v) => v._id);
        const variantSkus = variants.map((v) => v.sku);
        let stockBalances = [];
        if (variantIds.length > 0) {
            const stockQuery = {
                $or: [{ variantId: { $in: variantIds } }, { sku: { $in: variantSkus } }],
            };
            if (query.branchId) {
                stockQuery.branchId = query.branchId;
            }
            stockBalances = await index_js_1.StockBalance.find(stockQuery).lean();
        }
        const stockMap = new Map();
        stockBalances.forEach((sb) => {
            const existing = stockMap.get(sb.sku) || { onHand: 0, reserved: 0, reorderLevel: sb.reorderLevel ?? 5 };
            existing.onHand += sb.onHand || 0;
            existing.reserved += sb.reserved || 0;
            stockMap.set(sb.sku, existing);
        });
        const items = variants.map((v) => {
            const stockInfo = stockMap.get(v.sku) || { onHand: 0, reserved: 0, reorderLevel: 5 };
            const p = v.productId;
            const pId = p?._id ? p._id.toString() : p?.toString() || '';
            const bId = p?.brandId ? p.brandId.toString() : '';
            const cId = p?.categoryId ? p.categoryId.toString() : '';
            const plId = p?.productLineId ? p.productLineId.toString() : '';
            const sId = v.sizeId ? v.sizeId.toString() : '';
            const tId = v.thicknessId ? v.thicknessId.toString() : '';
            const b = meta.brandMap.get(bId) || p?.brandId;
            const c = meta.categoryMap.get(cId) || p?.categoryId;
            const pl = meta.lineMap.get(plId) || p?.productLineId;
            const sizeObj = meta.sizeMap.get(sId) || v.sizeId;
            const thickObj = meta.thicknessMap.get(tId) || v.thicknessId;
            const onHand = stockInfo.onHand;
            const reserved = stockInfo.reserved;
            const available = Math.max(0, onHand - reserved);
            const baseObj = {
                id: v._id.toString(),
                sku: v.sku,
                posDisplayName: v.posDisplayName || '',
                productName: p?.name || 'Mattress',
                productId: pId,
                brandId: bId,
                branchId: p?.branchId?.toString() || '',
                categoryId: cId,
                productLineId: plId,
                productLineName: pl?.name || '',
                sizeId: sId,
                thicknessId: tId,
                brand: b,
                category: c,
                productLine: pl,
                size: sizeObj,
                thickness: thickObj,
                listPrice: (0, financial_js_1.toRupees)(v.listPrice),
                retailPrice: (0, financial_js_1.toRupees)(v.retailPrice),
                walkInPrice: (0, financial_js_1.toRupees)(v.retailPrice),
                wholesalePrice: (0, financial_js_1.toRupees)(v.wholesalePrice),
                distributorPrice: (0, financial_js_1.toRupees)(v.distributorPrice),
                stock: onHand,
                onHand,
                reserved,
                available,
                minimumStock: stockInfo.reorderLevel,
                reorderLevel: stockInfo.reorderLevel,
                status: v.status,
            };
            // Only expose purchase cost to Super Admin
            if (isSuperAdmin) {
                baseObj.purchasePrice = (0, financial_js_1.toRupees)(v.purchasePrice);
            }
            return baseObj;
        });
        return {
            items,
            pagination: {
                page,
                limit: limit > 0 ? limit : total,
                total,
                totalPages: limit > 0 ? (Math.ceil(total / limit) || 1) : 1,
            },
            counts: {
                total,
                active: activeCount,
                inactive: Math.max(0, total - activeCount),
            },
        };
    }
    static async getSkuById(id, isSuperAdmin = false) {
        let variant;
        if (mongoose_1.default.Types.ObjectId.isValid(id)) {
            variant = await index_js_1.Variant.findById(id);
        }
        if (!variant) {
            variant = await index_js_1.Variant.findOne({ sku: id.toUpperCase() });
        }
        if (!variant)
            throw new apiResponse_js_1.AppError(`SKU '${id}' not found.`, 404, 'SKU_NOT_FOUND');
        // Non-admin branch accounts cannot inspect INACTIVE SKUs
        if (!isSuperAdmin && variant.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError(`SKU '${id}' not found.`, 404, 'SKU_NOT_FOUND');
        }
        await variant.populate([
            {
                path: 'productId',
                populate: [
                    { path: 'brandId', select: 'name code' },
                    { path: 'categoryId', select: 'name code' },
                    { path: 'productLineId', select: 'name code' },
                ],
            },
            { path: 'sizeId', select: 'length width displayLabel' },
            { path: 'thicknessId', select: 'value displayLabel' },
        ]);
        const stockDoc = (await index_js_1.StockBalance.findOne({ variantId: variant._id })) ||
            (await index_js_1.StockBalance.findOne({ sku: variant.sku }));
        const res = {
            id: variant._id.toString(),
            sku: variant.sku,
            product: variant.productId,
            size: variant.sizeId,
            thickness: variant.thicknessId,
            listPrice: (0, financial_js_1.toRupees)(variant.listPrice),
            retailPrice: (0, financial_js_1.toRupees)(variant.retailPrice),
            retailMarkupPercent: variant.retailMarkupPercent,
            wholesalePrice: (0, financial_js_1.toRupees)(variant.wholesalePrice),
            wholesaleDiscountPercent: variant.wholesaleDiscountPercent,
            distributorPrice: (0, financial_js_1.toRupees)(variant.distributorPrice || 0),
            distributorDiscountPercent: variant.distributorDiscountPercent,
            status: variant.status,
            stock: stockDoc ? stockDoc.onHand : 0,
            minimumStock: stockDoc?.reorderLevel ?? 5,
        };
        if (isSuperAdmin) {
            res.purchasePrice = (0, financial_js_1.toRupees)(variant.purchasePrice);
            res.purchaseDiscountPercent = variant.purchaseDiscountPercent;
        }
        return res;
    }
    static async updateSku(id, input, accountId) {
        const variant = mongoose_1.default.Types.ObjectId.isValid(id)
            ? await index_js_1.Variant.findById(id)
            : await index_js_1.Variant.findOne({ sku: id.toUpperCase() });
        if (!variant)
            throw new apiResponse_js_1.AppError(`SKU '${id}' not found.`, 404, 'SKU_NOT_FOUND');
        await variant.populate([
            {
                path: 'productId',
                populate: [
                    { path: 'brandId' },
                    { path: 'categoryId' },
                    { path: 'productLineId' },
                ],
            },
            'sizeId',
            'thicknessId',
        ]);
        const resolveEntity = async (model, idOrCode) => {
            if (!idOrCode)
                return null;
            if (mongoose_1.default.Types.ObjectId.isValid(idOrCode)) {
                const doc = await model.findById(idOrCode);
                if (doc)
                    return doc;
            }
            return await model.findOne({
                $or: [
                    { code: idOrCode },
                    { code: idOrCode.toUpperCase() },
                    { name: idOrCode },
                    { displayLabel: idOrCode },
                ],
            });
        };
        const currentProd = variant.productId;
        const currentBrand = currentProd?.brandId;
        const currentCat = currentProd?.categoryId;
        const currentLine = currentProd?.productLineId;
        const currentSize = variant.sizeId;
        const currentThick = variant.thicknessId;
        const brand = input.brandId
            ? await resolveEntity(index_js_1.Brand, input.brandId)
            : currentBrand;
        const category = input.categoryId
            ? await resolveEntity(index_js_1.Category, input.categoryId)
            : currentCat;
        const productLine = input.productLineId
            ? await resolveEntity(index_js_1.ProductLine, input.productLineId)
            : (currentLine?._id ? currentLine : (currentLine ? await resolveEntity(index_js_1.ProductLine, currentLine.toString()) : null));
        const size = input.sizeId
            ? await resolveEntity(index_js_1.Size, input.sizeId)
            : currentSize;
        const thickness = input.thicknessId
            ? await resolveEntity(index_js_1.Thickness, input.thicknessId)
            : currentThick;
        if (!brand || brand.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Brand not found or inactive.', 400, 'INVALID_BRAND');
        }
        if (!category || category.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Category not found or inactive.', 400, 'INVALID_CATEGORY');
        }
        if (category.brandId.toString() !== brand._id.toString()) {
            throw new apiResponse_js_1.AppError(`Category '${category.name}' does not belong to Brand '${brand.name}'.`, 400, 'CATEGORY_BRAND_MISMATCH');
        }
        if (!size || size.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Size not found or inactive.', 400, 'INVALID_SIZE');
        }
        if (!thickness || thickness.status !== 'ACTIVE') {
            throw new apiResponse_js_1.AppError('Thickness not found or inactive.', 400, 'INVALID_THICKNESS');
        }
        // Preserve product identity: do NOT reassign to an arbitrary product if hierarchy is unchanged
        let product = null;
        const currentBrandIdStr = (currentBrand?._id || currentBrand)?.toString();
        const currentCatIdStr = (currentCat?._id || currentCat)?.toString();
        const currentLineIdStr = (currentLine?._id || currentLine)?.toString();
        const targetBrandIdStr = brand?._id?.toString();
        const targetCatIdStr = category?._id?.toString();
        const targetLineIdStr = productLine?._id?.toString();
        const isProductHierarchySame = currentProd &&
            currentBrandIdStr === targetBrandIdStr &&
            currentCatIdStr === targetCatIdStr &&
            (!targetLineIdStr || !currentLineIdStr || currentLineIdStr === targetLineIdStr);
        if (isProductHierarchySame) {
            product = currentProd;
            if (productLine && !currentProd.productLineId) {
                product.productLineId = productLine._id;
                await product.save();
            }
        }
        else {
            const prodQuery = {
                brandId: brand._id,
                categoryId: category._id,
            };
            if (productLine) {
                prodQuery.productLineId = productLine._id;
            }
            if (currentProd?.branchId) {
                prodQuery.branchId = currentProd.branchId;
            }
            product = await index_js_1.Product.findOne(prodQuery);
            if (!product) {
                const lineSuffix = productLine?.name ? ` - ${productLine.name}` : '';
                product = await index_js_1.Product.create({
                    brandId: brand._id,
                    categoryId: category._id,
                    ...(productLine ? { productLineId: productLine._id } : {}),
                    ...(currentProd?.branchId ? { branchId: currentProd.branchId } : {}),
                    name: `${brand.name} - ${category.name}${lineSuffix}`,
                    imageUrl: input.imageUrl?.trim() || '',
                    status: 'ACTIVE',
                });
            }
        }
        if (input.imageUrl && input.imageUrl.trim() && product) {
            product.imageUrl = input.imageUrl.trim();
            await product.save();
        }
        variant.productId = product._id;
        variant.sizeId = size._id;
        variant.thicknessId = thickness._id;
        // Check for duplicate variant under the target product
        const duplicateVariant = await index_js_1.Variant.findOne({
            _id: { $ne: variant._id },
            productId: product._id,
            sizeId: size._id,
            thicknessId: thickness._id,
        });
        if (duplicateVariant) {
            throw new apiResponse_js_1.AppError(`A variant with size '${size.displayLabel}' and thickness '${thickness.displayLabel || thickness.value}' already exists for product '${product.name}' (SKU: ${duplicateVariant.sku}).`, 409, 'DUPLICATE_VARIANT');
        }
        // Check if specifications actually changed before mutating SKU
        const isSpecChanged = (input.brandId && input.brandId !== currentBrandIdStr) ||
            (input.categoryId && input.categoryId !== currentCatIdStr) ||
            (input.productLineId && input.productLineId !== currentLineIdStr) ||
            (input.sizeId && input.sizeId !== currentSize?._id?.toString()) ||
            (input.thicknessId && input.thicknessId !== currentThick?._id?.toString());
        if (isSpecChanged) {
            const plCode = productLine?.name || productLine?.code;
            const newSku = generateSkuCode(brand.code, category.code, size.displayLabel, thickness.value, plCode);
            const oldSku = variant.sku;
            if (newSku !== oldSku) {
                const duplicate = await index_js_1.Variant.findOne({ sku: newSku, _id: { $ne: variant._id } });
                if (duplicate) {
                    throw new apiResponse_js_1.AppError(`A mattress variant with SKU '${newSku}' already exists.`, 409, 'DUPLICATE_SKU');
                }
                variant.sku = newSku;
                // Update associated stock records
                await index_js_1.StockBalance.updateMany({ $or: [{ variantId: variant._id }, { sku: oldSku }] }, { $set: { sku: newSku, variantId: variant._id } });
                await index_js_1.StockMovement.updateMany({ sku: oldSku }, { $set: { sku: newSku } });
            }
        }
        if (input.status) {
            variant.status = input.status.toUpperCase();
        }
        const accountObjectId = accountId && mongoose_1.default.Types.ObjectId.isValid(accountId)
            ? new mongoose_1.default.Types.ObjectId(accountId)
            : undefined;
        const auditHistoryRecords = [];
        // 1. List Price update
        let currentListPaisa = variant.listPrice;
        if (input.listPrice !== undefined) {
            const newListPaisa = (0, financial_js_1.toPaisa)(input.listPrice);
            if (newListPaisa !== currentListPaisa) {
                auditHistoryRecords.push({
                    variantId: variant._id,
                    sku: variant.sku,
                    tier: 'LIST',
                    previousPrice: currentListPaisa,
                    newPrice: newListPaisa,
                    changedByAccountId: accountObjectId,
                    reason: input.reason || 'List Price Update',
                });
                currentListPaisa = newListPaisa;
                variant.listPrice = newListPaisa;
            }
        }
        // 2. Purchase Price update
        if (input.purchasePrice !== undefined || input.purchasePercent !== undefined) {
            const newPurchasePaisa = input.purchasePrice !== undefined
                ? (0, financial_js_1.toPaisa)(input.purchasePrice)
                : (0, financial_js_1.calculatePurchasePrice)(currentListPaisa, input.purchasePercent ?? variant.purchaseDiscountPercent ?? 0);
            const newPct = input.purchasePercent !== undefined
                ? input.purchasePercent
                : (0, financial_js_1.calculateDiscountPercent)(currentListPaisa, newPurchasePaisa);
            if (newPurchasePaisa !== variant.purchasePrice) {
                auditHistoryRecords.push({
                    variantId: variant._id,
                    sku: variant.sku,
                    tier: 'PURCHASE',
                    previousPrice: variant.purchasePrice,
                    newPrice: newPurchasePaisa,
                    previousPercent: variant.purchaseDiscountPercent,
                    newPercent: newPct,
                    changedByAccountId: accountObjectId,
                    reason: input.reason || 'Purchase Price Update',
                });
                variant.purchasePrice = newPurchasePaisa;
                variant.purchaseDiscountPercent = newPct;
            }
        }
        // 3. Retail Price update
        if (input.retailPrice !== undefined || input.retailPercent !== undefined) {
            const newRetailPaisa = input.retailPrice !== undefined
                ? (0, financial_js_1.toPaisa)(input.retailPrice)
                : (0, financial_js_1.calculateRetailPrice)(currentListPaisa, input.retailPercent ?? variant.retailMarkupPercent ?? 0);
            const newPct = input.retailPercent !== undefined
                ? input.retailPercent
                : (0, financial_js_1.calculateMarkupPercent)(currentListPaisa, newRetailPaisa);
            if (newRetailPaisa !== variant.retailPrice) {
                auditHistoryRecords.push({
                    variantId: variant._id,
                    sku: variant.sku,
                    tier: 'RETAIL',
                    previousPrice: variant.retailPrice,
                    newPrice: newRetailPaisa,
                    previousPercent: variant.retailMarkupPercent,
                    newPercent: newPct,
                    changedByAccountId: accountObjectId,
                    reason: input.reason || 'Retail Price Update',
                });
                variant.retailPrice = newRetailPaisa;
                variant.retailMarkupPercent = newPct;
            }
        }
        // 4. Wholesale Price update
        if (input.wholesalePrice !== undefined || input.wholesalePercent !== undefined) {
            const newWholesalePaisa = input.wholesalePrice !== undefined
                ? (0, financial_js_1.toPaisa)(input.wholesalePrice)
                : (0, financial_js_1.calculateWholesalePrice)(currentListPaisa, input.wholesalePercent ?? variant.wholesaleDiscountPercent ?? 0);
            const newPct = input.wholesalePercent !== undefined
                ? input.wholesalePercent
                : (0, financial_js_1.calculateDiscountPercent)(currentListPaisa, newWholesalePaisa);
            if (newWholesalePaisa !== variant.wholesalePrice) {
                auditHistoryRecords.push({
                    variantId: variant._id,
                    sku: variant.sku,
                    tier: 'WHOLESALE',
                    previousPrice: variant.wholesalePrice,
                    newPrice: newWholesalePaisa,
                    previousPercent: variant.wholesaleDiscountPercent,
                    newPercent: newPct,
                    changedByAccountId: accountObjectId,
                    reason: input.reason || 'Wholesale Price Update',
                });
                variant.wholesalePrice = newWholesalePaisa;
                variant.wholesaleDiscountPercent = newPct;
            }
        }
        // 5. Distributor Price update
        if (input.distributorPrice !== undefined || input.distributorPercent !== undefined) {
            const newDistributorPaisa = input.distributorPrice !== undefined
                ? (0, financial_js_1.toPaisa)(input.distributorPrice)
                : (0, financial_js_1.calculateDistributorPrice)(currentListPaisa, input.distributorPercent ?? variant.distributorDiscountPercent ?? 0);
            const newPct = input.distributorPercent !== undefined
                ? input.distributorPercent
                : (0, financial_js_1.calculateDiscountPercent)(currentListPaisa, newDistributorPaisa);
            if (newDistributorPaisa !== variant.distributorPrice) {
                auditHistoryRecords.push({
                    variantId: variant._id,
                    sku: variant.sku,
                    tier: 'DISTRIBUTOR',
                    previousPrice: variant.distributorPrice,
                    newPrice: newDistributorPaisa,
                    previousPercent: variant.distributorDiscountPercent,
                    newPercent: newPct,
                    changedByAccountId: accountObjectId,
                    reason: input.reason || 'Distributor Price Update',
                });
                variant.distributorPrice = newDistributorPaisa;
                variant.distributorDiscountPercent = newPct;
            }
        }
        // 6. Stock & Minimum Stock updates
        if (input.stock !== undefined || input.minimumStock !== undefined) {
            let stockDoc = (await index_js_1.StockBalance.findOne({ variantId: variant._id })) ||
                (await index_js_1.StockBalance.findOne({ sku: variant.sku }));
            const branchAndLoc = await this.resolvePrimaryBranchAndLocation();
            if (!stockDoc && branchAndLoc) {
                stockDoc = await index_js_1.StockBalance.create({
                    branchId: branchAndLoc.branch._id,
                    stockLocationId: branchAndLoc.location._id,
                    sku: variant.sku,
                    variantId: variant._id,
                    onHand: 0,
                    reserved: 0,
                    reorderLevel: 5,
                });
            }
            if (stockDoc) {
                if (!stockDoc.variantId) {
                    stockDoc.variantId = variant._id;
                }
                // Auto-heal missing stockLocationId or branchId so location error never happens
                if (!stockDoc.stockLocationId && branchAndLoc?.location) {
                    stockDoc.stockLocationId = branchAndLoc.location._id;
                }
                if (!stockDoc.branchId && branchAndLoc?.branch) {
                    stockDoc.branchId = branchAndLoc.branch._id;
                }
                const effectiveLocId = stockDoc.stockLocationId || branchAndLoc?.location?._id;
                const effectiveBranchId = stockDoc.branchId || branchAndLoc?.branch?._id;
                if (input.stock !== undefined) {
                    const oldOnHand = stockDoc.onHand || 0;
                    const newOnHand = Math.max(0, input.stock);
                    if (oldOnHand !== newOnHand && effectiveLocId && effectiveBranchId) {
                        stockDoc.onHand = newOnHand;
                        await index_js_1.StockMovement.create({
                            movementNumber: `MOV-EDIT-${variant.sku}-${Date.now().toString().slice(-6)}`,
                            branchId: effectiveBranchId,
                            stockLocationId: effectiveLocId,
                            sku: variant.sku,
                            movementType: 'ADMINISTRATIVE_ADJUSTMENT',
                            quantityDifference: newOnHand - oldOnHand,
                            previousBalance: oldOnHand,
                            newBalance: newOnHand,
                            referenceType: 'ADJUSTMENT',
                            reason: input.reason || 'Product catalogue edit stock update',
                            performedBy: accountId || 'System',
                            timestamp: new Date(),
                        });
                    }
                }
                if (input.minimumStock !== undefined) {
                    stockDoc.reorderLevel = Math.max(0, input.minimumStock);
                }
                await stockDoc.save();
            }
        }
        try {
            await variant.save();
        }
        catch (saveErr) {
            if (saveErr?.code === 11000) {
                throw new apiResponse_js_1.AppError(`A variant with these specifications or SKU already exists in this product catalogue.`, 409, 'DUPLICATE_VARIANT');
            }
            throw saveErr;
        }
        if (auditHistoryRecords.length > 0) {
            await index_js_1.PriceHistory.insertMany(auditHistoryRecords);
        }
        const finalStockDoc = (await index_js_1.StockBalance.findOne({ variantId: variant._id })) ||
            (await index_js_1.StockBalance.findOne({ sku: variant.sku }));
        pos_service_js_1.PosService.invalidatePOSCache();
        return {
            id: variant._id.toString(),
            sku: variant.sku,
            listPrice: (0, financial_js_1.toRupees)(variant.listPrice),
            purchasePrice: (0, financial_js_1.toRupees)(variant.purchasePrice),
            purchaseDiscountPercent: variant.purchaseDiscountPercent,
            retailPrice: (0, financial_js_1.toRupees)(variant.retailPrice),
            retailMarkupPercent: variant.retailMarkupPercent,
            wholesalePrice: (0, financial_js_1.toRupees)(variant.wholesalePrice),
            wholesaleDiscountPercent: variant.wholesaleDiscountPercent,
            distributorPrice: (0, financial_js_1.toRupees)(variant.distributorPrice || 0),
            distributorDiscountPercent: variant.distributorDiscountPercent,
            stock: finalStockDoc ? finalStockDoc.onHand : 0,
            minimumStock: finalStockDoc?.reorderLevel ?? 5,
            changesRecorded: auditHistoryRecords.length,
        };
    }
    static async updateSkuPrices(id, input, accountId) {
        return this.updateSku(id, input, accountId);
    }
    static async getSkuPriceHistory(id) {
        const variant = mongoose_1.default.Types.ObjectId.isValid(id)
            ? await index_js_1.Variant.findById(id)
            : await index_js_1.Variant.findOne({ sku: id.toUpperCase() });
        if (!variant)
            throw new apiResponse_js_1.AppError(`SKU '${id}' not found.`, 404, 'SKU_NOT_FOUND');
        const history = await index_js_1.PriceHistory.find({ variantId: variant._id })
            .populate('changedByAccountId', 'name loginId role')
            .sort({ createdAt: -1 });
        return history.map((h) => ({
            id: h._id.toString(),
            sku: h.sku,
            tier: h.tier,
            previousPrice: (0, financial_js_1.toRupees)(h.previousPrice),
            newPrice: (0, financial_js_1.toRupees)(h.newPrice),
            previousPercent: h.previousPercent,
            newPercent: h.newPercent,
            changedBy: h.changedByAccountId,
            reason: h.reason,
            createdAt: h.createdAt,
        }));
    }
    static async toggleSkuStatus(id, status) {
        const variant = mongoose_1.default.Types.ObjectId.isValid(id)
            ? await index_js_1.Variant.findById(id)
            : await index_js_1.Variant.findOne({ sku: id.toUpperCase() });
        if (!variant)
            throw new apiResponse_js_1.AppError(`SKU '${id}' not found.`, 404, 'SKU_NOT_FOUND');
        variant.status = status;
        return variant.save();
    }
    static async getBranches() {
        const branches = await index_js_1.Branch.find({ isActive: true }).sort({ name: 1 }).lean();
        return branches.map((b) => ({
            ...b,
            id: b._id.toString(),
            _id: b._id.toString(),
        }));
    }
    static async importCatalogueFromRows(rows, callerBranchId, options) {
        if (!Array.isArray(rows) || rows.length === 0) {
            throw new apiResponse_js_1.AppError('No rows provided for import.', 400, 'EMPTY_IMPORT_DATA');
        }
        // Resolve branch and stock location
        let targetBranch = null;
        if (callerBranchId && mongoose_1.default.Types.ObjectId.isValid(callerBranchId)) {
            targetBranch = await index_js_1.Branch.findById(callerBranchId);
        }
        if (!targetBranch) {
            targetBranch = await index_js_1.Branch.findOne({ isActive: true });
        }
        if (!targetBranch) {
            targetBranch = await index_js_1.Branch.findOne({});
        }
        let targetLocation = null;
        if (targetBranch) {
            targetLocation = await index_js_1.StockLocation.findOne({ branchId: targetBranch._id, isDefault: true })
                || await index_js_1.StockLocation.findOne({ branchId: targetBranch._id });
            if (!targetLocation) {
                targetLocation = await index_js_1.StockLocation.create({
                    branchId: targetBranch._id,
                    name: `${targetBranch.name} - Main Location`,
                    code: `LOC-MAIN-${targetBranch.code || 'MAIN'}`,
                    type: 'WAREHOUSE',
                    isDefault: true,
                });
            }
        }
        // Pre-load all catalogue metadata in parallel (1 single fast fetch)
        const [allBrands, allCategories, allLines, allProducts, allSizes, allThicks, allVariants, allBalances] = await Promise.all([
            index_js_1.Brand.find({}).lean(),
            index_js_1.Category.find({}).lean(),
            index_js_1.ProductLine.find({}).lean(),
            index_js_1.Product.find({}).lean(),
            index_js_1.Size.find({}).lean(),
            index_js_1.Thickness.find({}).lean(),
            index_js_1.Variant.find({}).select('_id productId sizeId thicknessId sku listPrice retailPrice wholesalePrice distributorPrice notes minStock posDisplayName').lean(),
            targetBranch ? index_js_1.StockBalance.find({ branchId: targetBranch._id }).lean() : Promise.resolve([]),
        ]);
        const brandsCache = new Map();
        const categoriesCache = new Map();
        const productLinesCache = new Map();
        const productsCache = new Map();
        const sizesCache = new Map();
        const thicknessesCache = new Map();
        // Seed caches from DB
        for (const b of allBrands) {
            brandsCache.set(b.name.toLowerCase(), b);
            if (b.code)
                brandsCache.set(b.code.toLowerCase(), b);
        }
        for (const c of allCategories) {
            categoriesCache.set(`${c.brandId.toString()}::${c.name.toLowerCase()}`, c);
        }
        for (const pl of allLines) {
            productLinesCache.set(`${pl.brandId.toString()}::${pl.categoryId.toString()}::${pl.name.toLowerCase()}`, pl);
            productLinesCache.set(pl.code.toUpperCase(), pl);
        }
        for (const p of allProducts) {
            const plId = p.productLineId ? p.productLineId.toString() : '';
            productsCache.set(`${p.brandId.toString()}::${p.categoryId.toString()}::${plId}`, p);
        }
        for (const s of allSizes) {
            sizesCache.set(`${s.length}x${s.width}_${(s.displayLabel || '').toLowerCase()}`, s);
            sizesCache.set(`${s.length}x${s.width}`, s);
        }
        for (const t of allThicks) {
            thicknessesCache.set(`${t.value}`, t);
        }
        // Existing variants index by productId + sizeId + thicknessId
        const existingVariantMap = new Map();
        const existingSkuSet = new Set();
        for (const v of allVariants) {
            if (v.productId && v.sizeId && v.thicknessId) {
                existingVariantMap.set(`${v.productId.toString()}::${v.sizeId.toString()}::${v.thicknessId.toString()}`, v);
            }
            if (v.sku)
                existingSkuSet.add(v.sku.toUpperCase());
        }
        // Existing balance index by variantId and sku
        const existingBalanceMap = new Map();
        for (const b of allBalances) {
            if (b.variantId)
                existingBalanceMap.set(b.variantId.toString(), b);
            if (b.sku)
                existingBalanceMap.set(b.sku.toUpperCase(), b);
        }
        // Bulk collection buffers for high-speed batch operations
        const variantsToInsert = [];
        const priceHistoriesToInsert = [];
        const stockBalancesToInsert = [];
        const stockMovementsToInsert = [];
        const variantBulkUpdates = [];
        const balanceBulkOps = [];
        const syncPriceHistories = [];
        const syncStockMovements = [];
        const duplicates = [];
        const created = [];
        const updated = [];
        const seenInFile = new Set();
        const now = new Date();
        const getCol = (row, ...keys) => {
            for (const k of keys) {
                if (row[k] !== undefined && row[k] !== null && String(row[k]).trim() !== '') {
                    return String(row[k]).trim();
                }
                const lowerKey = k.toLowerCase().replace(/[^a-z0-9]/g, '');
                for (const rowKey of Object.keys(row)) {
                    if (rowKey.toLowerCase().replace(/[^a-z0-9]/g, '') === lowerKey) {
                        if (row[rowKey] !== undefined && row[rowKey] !== null && String(row[rowKey]).trim() !== '') {
                            return String(row[rowKey]).trim();
                        }
                    }
                }
            }
            return '';
        };
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const itemNo = getCol(row, 'Item #', 'Item', 'Item No', 'No', '#') || (i + 1).toString();
            const brandRaw = getCol(row, 'Brand');
            const categoryRaw = getCol(row, 'Category');
            const productLineRaw = getCol(row, 'Product Line', 'ProductLine', 'Line');
            // Skip completely empty lines
            if (!brandRaw && !categoryRaw && !productLineRaw)
                continue;
            const brandName = brandRaw || 'MoltyFoam';
            const categoryName = categoryRaw || 'General';
            const productLineName = productLineRaw || 'Standard';
            const posDisplayNameRaw = getCol(row, 'POS Display Name', 'POSDisplayName', 'POS Name', 'DisplayName');
            const lengthRaw = getCol(row, 'Length (in)', 'Length', 'L');
            const widthRaw = getCol(row, 'Width (in)', 'Width', 'W');
            const heightRaw = getCol(row, 'Height (in)', 'Height', 'Thickness (in)', 'Thickness', 'Depth');
            const displayLabelRaw = getCol(row, 'Display label', 'Display Label', 'Size');
            const notes = getCol(row, 'Variant / Notes', 'Variant', 'Notes', 'Description') || 'Standard';
            const stockRaw = getCol(row, 'Current Stock', 'Stock', 'Qty', 'Quantity');
            const minStockRaw = getCol(row, 'Minimum Stock', 'Min Stock', 'MinStock', 'Reorder Level');
            const priceRaw = getCol(row, 'List Price', 'Price', 'Retail Price', 'ListPrice');
            const effectiveDateRaw = getCol(row, 'Effective Date', 'Date');
            let length = parseFloat(lengthRaw) || 0;
            let width = parseFloat(widthRaw) || 0;
            let height = parseFloat(heightRaw) || 0;
            if ((length === 0 || width === 0) && displayLabelRaw) {
                const parts = displayLabelRaw.toLowerCase().split(/[x*×]/);
                if (parts.length >= 2) {
                    length = parseFloat(parts[0]) || 0;
                    width = parseFloat(parts[1]) || 0;
                    if (parts.length >= 3 && height === 0) {
                        height = parseFloat(parts[2]) || 0;
                    }
                }
            }
            const displayLabel = (length > 0 && width > 0)
                ? `${length}x${width}`
                : (displayLabelRaw || 'Standard');
            const posDisplayName = posDisplayNameRaw || `${productLineName} ${displayLabel}${height > 0 ? `x${height}` : ''}`;
            const fileKey = `${brandName.toLowerCase()}::${categoryName.toLowerCase()}::${productLineName.toLowerCase()}::${displayLabel.toLowerCase()}::${height}`;
            if (seenInFile.has(fileKey)) {
                duplicates.push({
                    itemNo,
                    posDisplayName,
                    brand: brandName,
                    category: categoryName,
                    productLine: productLineName,
                    size: displayLabel,
                    height,
                    reason: 'Duplicate entry in uploaded file',
                });
                continue;
            }
            seenInFile.add(fileKey);
            const cleanPriceStr = priceRaw.replace(/[^0-9.]/g, '');
            const listPrice = parseFloat(cleanPriceStr) || 0;
            const currentStock = parseInt(stockRaw.replace(/[^0-9-]/g, ''), 10) || 0;
            const minStock = parseInt(minStockRaw.replace(/[^0-9-]/g, ''), 10) || 0;
            let effectiveDate = new Date();
            if (effectiveDateRaw) {
                const parsedD = new Date(effectiveDateRaw);
                if (!isNaN(parsedD.getTime()))
                    effectiveDate = parsedD;
            }
            // 1. Resolve Brand
            const brandKey = brandName.toLowerCase();
            let brand = brandsCache.get(brandKey);
            if (!brand) {
                brand = await index_js_1.Brand.findOne({
                    $or: [
                        { name: { $regex: new RegExp(`^${brandName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') } },
                        { code: brandName.toUpperCase() },
                    ],
                });
                if (!brand) {
                    const brandCode = brandName.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 6) || 'BRD';
                    brand = await index_js_1.Brand.create({
                        name: brandName,
                        code: brandCode,
                        status: 'ACTIVE',
                        ...(targetBranch ? { branchId: targetBranch._id } : {}),
                    });
                }
                brandsCache.set(brandKey, brand);
            }
            // 2. Resolve Category
            const catKey = `${brand._id.toString()}::${categoryName.toLowerCase()}`;
            let category = categoriesCache.get(catKey);
            if (!category) {
                category = await index_js_1.Category.findOne({
                    brandId: brand._id,
                    name: { $regex: new RegExp(`^${categoryName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') },
                });
                if (!category) {
                    const catCode = `${categoryName.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 4)}-${brand.code.slice(0, 3)}`;
                    category = await index_js_1.Category.create({
                        brandId: brand._id,
                        name: categoryName,
                        code: catCode,
                        status: 'ACTIVE',
                        ...(targetBranch ? { branchId: targetBranch._id } : {}),
                    });
                }
                categoriesCache.set(catKey, category);
            }
            // 3. Resolve Product Line
            const plKey = `${brand._id.toString()}::${category._id.toString()}::${productLineName.toLowerCase()}`;
            let productLine = productLinesCache.get(plKey);
            if (!productLine) {
                productLine = await index_js_1.ProductLine.findOne({
                    brandId: brand._id,
                    categoryId: category._id,
                    name: { $regex: new RegExp(`^${productLineName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') },
                });
                if (!productLine) {
                    const plCode = `PL-${productLineName.replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 8)}`;
                    let candidateCode = plCode;
                    let plCount = 1;
                    while (await index_js_1.ProductLine.findOne({ code: candidateCode })) {
                        candidateCode = `${plCode}-${plCount++}`;
                    }
                    productLine = await index_js_1.ProductLine.create({
                        brandId: brand._id,
                        categoryId: category._id,
                        name: productLineName,
                        code: candidateCode,
                        status: 'ACTIVE',
                        ...(targetBranch ? { branchId: targetBranch._id } : {}),
                    });
                }
                productLinesCache.set(plKey, productLine);
            }
            // 4. Resolve Base Product
            const prodKey = `${brand._id.toString()}::${category._id.toString()}::${productLine._id.toString()}`;
            let product = productsCache.get(prodKey);
            if (!product) {
                product = await index_js_1.Product.findOne({
                    brandId: brand._id,
                    categoryId: category._id,
                    productLineId: productLine._id,
                });
                if (!product) {
                    product = await index_js_1.Product.create({
                        brandId: brand._id,
                        categoryId: category._id,
                        productLineId: productLine._id,
                        name: productLineName,
                        posDisplayName,
                        code: productLine.code,
                        status: 'ACTIVE',
                        ...(targetBranch ? { branchId: targetBranch._id } : {}),
                    });
                }
                productsCache.set(prodKey, product);
            }
            // 5. Resolve Size (with smart fallback and race-safe catch)
            const targetLength = length > 0 ? length : 78;
            const targetWidth = width > 0 ? width : 72;
            const sizeKey = `${targetLength}x${targetWidth}_${displayLabel.toLowerCase()}`;
            let size = sizesCache.get(sizeKey);
            if (!size) {
                size = await index_js_1.Size.findOne({
                    $or: [
                        { length: targetLength, width: targetWidth },
                        { displayLabel: { $regex: new RegExp(`^${displayLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') } },
                    ],
                });
                if (!size) {
                    try {
                        size = await index_js_1.Size.create({
                            length: targetLength,
                            width: targetWidth,
                            unit: 'in',
                            displayLabel,
                            status: 'ACTIVE',
                        });
                    }
                    catch {
                        size = await index_js_1.Size.findOne({
                            $or: [
                                { length: targetLength, width: targetWidth },
                                { displayLabel },
                            ],
                        });
                        if (!size)
                            size = await index_js_1.Size.findOne({});
                    }
                }
                if (size)
                    sizesCache.set(sizeKey, size);
            }
            // 6. Resolve Thickness (pehle targetHeight nikalenge taake value: 4 search ho aur duplicate error na aaye)
            const targetHeight = height > 0 ? height : 4;
            const thickKey = `${targetHeight}`;
            let thickness = thicknessesCache.get(thickKey);
            if (!thickness) {
                thickness = await index_js_1.Thickness.findOne({ value: targetHeight });
                if (!thickness) {
                    try {
                        thickness = await index_js_1.Thickness.create({
                            value: targetHeight,
                            unit: 'in',
                            displayLabel: `${targetHeight}"`,
                            status: 'ACTIVE',
                        });
                    }
                    catch {
                        thickness = await index_js_1.Thickness.findOne({ value: targetHeight });
                        if (!thickness)
                            thickness = await index_js_1.Thickness.findOne({});
                    }
                }
                if (thickness)
                    thicknessesCache.set(thickKey, thickness);
            }
            // 7. Instant In-Memory Duplicate Check (O(1))
            const varKey = `${product._id.toString()}::${size._id.toString()}::${thickness._id.toString()}`;
            const existingVariant = existingVariantMap.get(varKey);
            if (existingVariant) {
                if (options?.updateDuplicates) {
                    const pricePaisa = (0, financial_js_1.toPaisa)(listPrice);
                    const varId = existingVariant._id;
                    // Queue variant price & detail update
                    variantBulkUpdates.push({
                        updateOne: {
                            filter: { _id: varId },
                            update: {
                                $set: {
                                    listPrice: pricePaisa,
                                    purchasePrice: pricePaisa,
                                    retailPrice: pricePaisa,
                                    wholesalePrice: pricePaisa,
                                    distributorPrice: pricePaisa,
                                    ...(posDisplayNameRaw ? { posDisplayName } : {}),
                                    ...(notes ? { notes } : {}),
                                    minStock,
                                },
                            },
                        },
                    });
                    // Queue Price History
                    syncPriceHistories.push({
                        variantId: varId,
                        sku: existingVariant.sku,
                        tier: 'RETAIL',
                        previousPrice: existingVariant.retailPrice || 0,
                        newPrice: pricePaisa,
                        reason: 'EXCEL_CATALOGUE_SYNC',
                        createdAt: now,
                        updatedAt: now,
                    });
                    // Stock balance handling
                    if (targetBranch && targetLocation) {
                        const existingBal = existingBalanceMap.get(varId.toString()) ||
                            existingBalanceMap.get((existingVariant.sku || '').toUpperCase());
                        const prevOnHand = existingBal ? (existingBal.onHand || 0) : 0;
                        if (existingBal) {
                            balanceBulkOps.push({
                                updateOne: {
                                    filter: { _id: existingBal._id },
                                    update: {
                                        $set: {
                                            onHand: currentStock,
                                            reorderLevel: minStock,
                                            stockLocationId: existingBal.stockLocationId || targetLocation._id,
                                        },
                                    },
                                },
                            });
                            existingBal.onHand = currentStock;
                        }
                        else {
                            const newBalId = new mongoose_1.default.Types.ObjectId();
                            const newBalDoc = {
                                _id: newBalId,
                                branchId: targetBranch._id,
                                stockLocationId: targetLocation._id,
                                variantId: varId,
                                sku: existingVariant.sku,
                                onHand: currentStock,
                                reserved: 0,
                                reorderLevel: minStock,
                                createdAt: now,
                                updatedAt: now,
                            };
                            balanceBulkOps.push({ insertOne: { document: newBalDoc } });
                            existingBalanceMap.set(varId.toString(), newBalDoc);
                            existingBalanceMap.set((existingVariant.sku || '').toUpperCase(), newBalDoc);
                        }
                        if (currentStock !== prevOnHand) {
                            syncStockMovements.push({
                                movementNumber: `MOV-SYNC-${existingVariant.sku}-${Date.now().toString().slice(-6)}-${updated.length + 1}`,
                                branchId: targetBranch._id,
                                stockLocationId: targetLocation._id,
                                sku: existingVariant.sku,
                                movementType: 'ADMINISTRATIVE_ADJUSTMENT',
                                quantityDifference: currentStock - prevOnHand,
                                previousBalance: prevOnHand,
                                newBalance: currentStock,
                                referenceType: 'EXCEL_SYNC',
                                reason: `Excel catalogue sync stock update (${itemNo})`,
                                performedBy: 'System',
                                timestamp: now,
                                createdAt: now,
                                updatedAt: now,
                            });
                        }
                    }
                    updated.push({
                        itemNo,
                        sku: existingVariant.sku,
                        posDisplayName,
                        brand: brandName,
                        category: categoryName,
                        productLine: productLineName,
                        size: displayLabel,
                        height: targetHeight,
                        price: listPrice,
                        stock: currentStock,
                    });
                    continue;
                }
                duplicates.push({
                    itemNo,
                    posDisplayName,
                    brand: brandName,
                    category: categoryName,
                    productLine: productLineName,
                    size: displayLabel,
                    height: targetHeight,
                    reason: `Already exists in database (SKU: ${existingVariant.sku})`,
                });
                continue;
            }
            // 8. Generate Unique SKU (Instant in-memory uniqueness verification)
            const baseSku = generateSkuCode(brand.code, category.code, size.displayLabel, thickness.value, productLine.name || productLine.code);
            let uniqueSku = baseSku;
            let skuSuffix = 1;
            while (existingSkuSet.has(uniqueSku.toUpperCase())) {
                uniqueSku = `${baseSku}-${skuSuffix++}`;
            }
            existingSkuSet.add(uniqueSku.toUpperCase());
            // 9. Pricing rule: listPrice = retailPrice = wholesalePrice
            const pricePaisa = (0, financial_js_1.toPaisa)(listPrice);
            const newVariantId = new mongoose_1.default.Types.ObjectId();
            const newVariantDoc = {
                _id: newVariantId,
                productId: product._id,
                sizeId: size._id,
                thicknessId: thickness._id,
                sku: uniqueSku,
                posDisplayName,
                notes,
                minStock,
                listPrice: pricePaisa,
                purchasePrice: pricePaisa,
                retailPrice: pricePaisa,
                wholesalePrice: pricePaisa,
                distributorPrice: pricePaisa,
                status: 'ACTIVE',
                createdAt: now,
                updatedAt: now,
            };
            variantsToInsert.push(newVariantDoc);
            existingVariantMap.set(varKey, newVariantDoc);
            // 10. Initial Price History Record (in-memory buffer)
            priceHistoriesToInsert.push({
                variantId: newVariantId,
                sku: uniqueSku,
                tier: 'RETAIL',
                previousPrice: 0,
                newPrice: pricePaisa,
                reason: 'EXCEL_CATALOGUE_IMPORT',
                createdAt: now,
                updatedAt: now,
            });
            // 11. Initial Stock Balance (in-memory buffer)
            if (targetBranch && targetLocation) {
                stockBalancesToInsert.push({
                    branchId: targetBranch._id,
                    stockLocationId: targetLocation._id,
                    variantId: newVariantId,
                    sku: uniqueSku,
                    onHand: currentStock,
                    reserved: 0,
                    reorderLevel: minStock,
                    createdAt: now,
                    updatedAt: now,
                });
                if (currentStock > 0) {
                    stockMovementsToInsert.push({
                        movementNumber: `MOV-INIT-${uniqueSku}-${Date.now().toString().slice(-6)}-${created.length + 1}`,
                        branchId: targetBranch._id,
                        stockLocationId: targetLocation._id,
                        sku: uniqueSku,
                        movementType: 'OPENING_BALANCE',
                        quantityDifference: currentStock,
                        previousBalance: 0,
                        newBalance: currentStock,
                        referenceType: 'EXCEL_IMPORT',
                        reason: `Excel catalogue initial stock import (${itemNo})`,
                        performedBy: 'System',
                        timestamp: now,
                        createdAt: now,
                        updatedAt: now,
                    });
                }
            }
            created.push({
                itemNo,
                sku: uniqueSku,
                posDisplayName,
                brand: brandName,
                category: categoryName,
                productLine: productLineName,
                size: displayLabel,
                height: targetHeight,
                price: listPrice,
                stock: currentStock,
            });
        }
        // =========================================================================
        // HIGH-SPEED BATCH EXECUTION: Flush all buffers in bulk chunks (1000 items)
        // =========================================================================
        const BATCH_SIZE = 1000;
        if (variantsToInsert.length > 0) {
            for (let b = 0; b < variantsToInsert.length; b += BATCH_SIZE) {
                await index_js_1.Variant.insertMany(variantsToInsert.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        if (priceHistoriesToInsert.length > 0) {
            for (let b = 0; b < priceHistoriesToInsert.length; b += BATCH_SIZE) {
                await index_js_1.PriceHistory.insertMany(priceHistoriesToInsert.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        if (stockBalancesToInsert.length > 0) {
            for (let b = 0; b < stockBalancesToInsert.length; b += BATCH_SIZE) {
                await index_js_1.StockBalance.insertMany(stockBalancesToInsert.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        if (stockMovementsToInsert.length > 0) {
            for (let b = 0; b < stockMovementsToInsert.length; b += BATCH_SIZE) {
                await index_js_1.StockMovement.insertMany(stockMovementsToInsert.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        // Flush duplicate updates
        if (variantBulkUpdates.length > 0) {
            for (let b = 0; b < variantBulkUpdates.length; b += BATCH_SIZE) {
                await index_js_1.Variant.bulkWrite(variantBulkUpdates.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        if (balanceBulkOps.length > 0) {
            for (let b = 0; b < balanceBulkOps.length; b += BATCH_SIZE) {
                await index_js_1.StockBalance.bulkWrite(balanceBulkOps.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        if (syncPriceHistories.length > 0) {
            for (let b = 0; b < syncPriceHistories.length; b += BATCH_SIZE) {
                await index_js_1.PriceHistory.insertMany(syncPriceHistories.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        if (syncStockMovements.length > 0) {
            for (let b = 0; b < syncStockMovements.length; b += BATCH_SIZE) {
                await index_js_1.StockMovement.insertMany(syncStockMovements.slice(b, b + BATCH_SIZE), { ordered: false });
            }
        }
        pos_service_js_1.PosService.invalidatePOSCache();
        return {
            totalRows: rows.length,
            successCount: created.length,
            duplicateCount: duplicates.length,
            updatedCount: updated.length,
            duplicates,
            created,
            updated,
        };
    }
}
exports.CatalogueService = CatalogueService;
//# sourceMappingURL=catalogue.service.js.map