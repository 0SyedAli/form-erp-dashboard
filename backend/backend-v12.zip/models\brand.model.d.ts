import mongoose, { Document } from 'mongoose';
export interface IBrand extends Document {
    code: string;
    name: string;
    description?: string;
    logoUrl?: string;
    hasThickness?: boolean;
    branchId?: mongoose.Types.ObjectId;
    status: 'ACTIVE' | 'INACTIVE';
    createdAt: Date;
    updatedAt: Date;
}
export declare const Brand: mongoose.Model<IBrand, {}, {}, {}, mongoose.Document<unknown, {}, IBrand, {}, {}> & IBrand & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
