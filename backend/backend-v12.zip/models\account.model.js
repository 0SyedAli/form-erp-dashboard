"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Account = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const index_js_1 = require("../constants/index.js");
const PermissionsSchema = new mongoose_1.Schema({
    pos: { type: Boolean, default: true },
    viewOwnSales: { type: Boolean, default: true },
    viewProducts: { type: Boolean, default: true },
    addEditProducts: { type: Boolean, default: false },
    viewStock: { type: Boolean, default: true },
    manageStock: { type: Boolean, default: false },
    stockTransfers: { type: Boolean, default: false },
    customers: { type: Boolean, default: true },
    customerCredit: { type: Boolean, default: false },
    purchases: { type: Boolean, default: false },
    suppliers: { type: Boolean, default: false },
    reports: { type: Boolean, default: false },
    returns: { type: Boolean, default: false },
    discountsOverrides: { type: Boolean, default: false },
}, { _id: false });
const AccountSchema = new mongoose_1.Schema({
    loginId: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true,
        index: true,
    },
    name: {
        type: String,
        required: true,
        trim: true,
    },
    email: {
        type: String,
        trim: true,
        lowercase: true,
    },
    passwordHash: {
        type: String,
        required: true,
    },
    role: {
        type: String,
        enum: Object.values(index_js_1.ACCOUNT_ROLES),
        required: true,
        default: index_js_1.ACCOUNT_ROLES.BRANCH,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        default: null,
        index: true,
    },
    permissions: {
        type: PermissionsSchema,
        default: () => ({ ...index_js_1.STANDARD_BRANCH_PERMISSIONS }),
    },
    isActive: {
        type: Boolean,
        default: true,
        index: true,
    },
    lastLoginAt: {
        type: Date,
    },
}, {
    timestamps: true,
    toJSON: {
        transform(_doc, ret) {
            delete ret.passwordHash;
            return ret;
        },
    },
    toObject: {
        transform(_doc, ret) {
            delete ret.passwordHash;
            return ret;
        },
    },
});
exports.Account = mongoose_1.default.model('Account', AccountSchema);
//# sourceMappingURL=account.model.js.map