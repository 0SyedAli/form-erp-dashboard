export declare const posRoutes: import("express-serve-static-core").Router;
