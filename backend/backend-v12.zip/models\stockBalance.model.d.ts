import mongoose, { Document } from 'mongoose';
export interface IStockBalance extends Document {
    branchId: mongoose.Types.ObjectId;
    stockLocationId: mongoose.Types.ObjectId;
    sku: string;
    variantId?: mongoose.Types.ObjectId;
    onHand: number;
    reserved: number;
    reorderLevel: number;
    updatedAt: Date;
}
export declare const StockBalance: mongoose.Model<IStockBalance, {}, {}, {}, mongoose.Document<unknown, {}, IStockBalance, {}, {}> & IStockBalance & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
