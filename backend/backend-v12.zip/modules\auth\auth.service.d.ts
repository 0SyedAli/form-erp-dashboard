import { LoginInput, ChangePasswordInput } from './auth.schema.js';
export declare class AuthService {
    /**
     * Authenticates user, creates hashed session in MongoDB, and logs audit trail.
     */
    static login(input: LoginInput, ipAddress?: string, userAgent?: string): Promise<{
        rawToken: string;
        expiresAt: Date;
        account: {
            id: string;
            loginId: string;
            name: string;
            email: string | undefined;
            role: import("../../constants/index.js").AccountRole;
            branchId: string | undefined;
            permissions: {
                pos: boolean;
                viewOwnSales: boolean;
                viewProducts: boolean;
                addEditProducts: boolean;
                viewStock: boolean;
                manageStock: boolean;
                stockTransfers: boolean;
                customers: boolean;
                customerCredit: boolean;
                collections: boolean;
                purchases: boolean;
                suppliers: boolean;
                reports: boolean;
                returns: boolean;
                discountsOverrides: boolean;
            };
            branch: {
                id: any;
                code: any;
                name: any;
                shopNumber: any;
                type: any;
                city: any;
            } | null;
        };
    }>;
    /**
     * Invalidates active session.
     */
    static logout(rawToken: string, accountId?: string): Promise<void>;
    /**
     * Returns current authenticated account context.
     */
    static getProfile(accountId: string): Promise<{
        id: string;
        loginId: string;
        name: string;
        email: string | undefined;
        role: import("../../constants/index.js").AccountRole;
        branchId: string | undefined;
        permissions: {
            pos: boolean;
            viewOwnSales: boolean;
            viewProducts: boolean;
            addEditProducts: boolean;
            viewStock: boolean;
            manageStock: boolean;
            stockTransfers: boolean;
            customers: boolean;
            customerCredit: boolean;
            collections: boolean;
            purchases: boolean;
            suppliers: boolean;
            reports: boolean;
            returns: boolean;
            discountsOverrides: boolean;
        };
        branch: {
            id: any;
            code: any;
            name: any;
            shopNumber: any;
            type: any;
            city: any;
        } | null;
    }>;
    /**
     * Changes account password and invalidates all other active sessions.
     */
    static changePassword(accountId: string, input: ChangePasswordInput, currentRawToken?: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
