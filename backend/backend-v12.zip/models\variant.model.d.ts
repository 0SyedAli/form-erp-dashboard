import mongoose, { Document } from 'mongoose';
export interface IVariant extends Document {
    productId: mongoose.Types.ObjectId;
    sizeId: mongoose.Types.ObjectId;
    thicknessId?: mongoose.Types.ObjectId;
    sku: string;
    barcode?: string;
    posDisplayName?: string;
    notes?: string;
    minStock?: number;
    listPrice: number;
    purchasePrice: number;
    purchaseDiscountPercent?: number;
    retailPrice: number;
    retailMarkupPercent?: number;
    wholesalePrice: number;
    wholesaleDiscountPercent?: number;
    distributorPrice?: number;
    distributorDiscountPercent?: number;
    status: 'ACTIVE' | 'INACTIVE';
    createdAt: Date;
    updatedAt: Date;
}
export declare const Variant: mongoose.Model<IVariant, {}, {}, {}, mongoose.Document<unknown, {}, IVariant, {}, {}> & IVariant & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
