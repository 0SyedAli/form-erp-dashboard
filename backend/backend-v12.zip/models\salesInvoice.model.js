"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesInvoice = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const index_js_1 = require("../constants/index.js");
const InvoiceLineItemSchema = new mongoose_1.Schema({
    variantId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Variant' },
    sku: { type: String, required: true },
    productName: { type: String, required: true },
    sizeLabel: { type: String, required: true },
    thicknessLabel: { type: String, required: true },
    quantity: { type: Number, required: true, min: 1 },
    unitPrice: { type: Number, required: true, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
}, { _id: false });
const SalesInvoiceSchema = new mongoose_1.Schema({
    invoiceNumber: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    sourceBranchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        index: true,
    },
    isInterBranch: {
        type: Boolean,
        default: false,
        index: true,
    },
    customerId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Customer',
        index: true,
    },
    customerName: {
        type: String,
        required: true,
        trim: true,
        default: 'Walk-in Customer',
    },
    customerPhone: {
        type: String,
        trim: true,
    },
    customerType: {
        type: String,
        enum: Object.values(index_js_1.CUSTOMER_TYPES),
        default: index_js_1.CUSTOMER_TYPES.WALK_IN,
    },
    saleType: {
        type: String,
        enum: Object.values(index_js_1.SALE_TYPES),
        required: true,
        default: index_js_1.SALE_TYPES.WALK_IN,
        index: true,
    },
    items: {
        type: [InvoiceLineItemSchema],
        required: true,
        validate: [(v) => v.length > 0, 'Invoice must contain at least one line item'],
    },
    subtotal: {
        type: Number,
        required: true,
        min: 0,
    },
    discount: {
        type: Number,
        default: 0,
        min: 0,
    },
    tax: {
        type: Number,
        default: 0,
        min: 0,
    },
    total: {
        type: Number,
        required: true,
        min: 0,
    },
    paidAmount: {
        type: Number,
        required: true,
        min: 0,
    },
    balanceDue: {
        type: Number,
        required: true,
        min: 0,
    },
    paymentStatus: {
        type: String,
        enum: Object.values(index_js_1.PAYMENT_STATUSES),
        required: true,
        default: index_js_1.PAYMENT_STATUSES.PAID,
        index: true,
    },
    paymentArrangement: {
        type: String,
        enum: Object.values(index_js_1.PAYMENT_ARRANGEMENTS),
        required: true,
        default: index_js_1.PAYMENT_ARRANGEMENTS.CASH,
    },
    status: {
        type: String,
        enum: Object.values(index_js_1.INVOICE_STATUSES),
        default: index_js_1.INVOICE_STATUSES.CONFIRMED,
        index: true,
    },
    cashReceived: {
        type: Number,
        default: 0,
    },
    changeReturned: {
        type: Number,
        default: 0,
    },
    dueDate: {
        type: Date,
        index: true,
    },
    idempotencyKey: {
        type: String,
        unique: true,
        sparse: true,
        index: true,
    },
    cashierName: {
        type: String,
        required: true,
    },
    creditOverride: {
        type: Boolean,
        default: false,
    },
    creditApprovedBy: {
        type: String,
    },
    overrideReason: {
        type: String,
    },
    notes: {
        type: String,
    },
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
});
SalesInvoiceSchema.virtual('netAmount').get(function () {
    return this.total;
});
SalesInvoiceSchema.virtual('grossAmount').get(function () {
    return this.subtotal;
});
SalesInvoiceSchema.virtual('discountAmount').get(function () {
    return this.discount;
});
SalesInvoiceSchema.virtual('amountPaid').get(function () {
    return this.paidAmount;
});
SalesInvoiceSchema.virtual('amountDue').get(function () {
    return this.balanceDue;
});
SalesInvoiceSchema.virtual('date').get(function () {
    return this.createdAt;
});
SalesInvoiceSchema.index({ branchId: 1, createdAt: -1 });
SalesInvoiceSchema.index({ customerId: 1, branchId: 1, balanceDue: 1 });
exports.SalesInvoice = mongoose_1.default.model('SalesInvoice', SalesInvoiceSchema);
//# sourceMappingURL=salesInvoice.model.js.map