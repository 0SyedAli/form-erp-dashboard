import { Request, Response } from 'express';
export declare class ReportingController {
    private static getValidatedUser;
    static getAdminDashboard(req: Request, res: Response): Promise<void>;
    static getBranchDashboard(req: Request, res: Response): Promise<void>;
    static getSalesSummary(req: Request, res: Response): Promise<void>;
    static getSalesTrends(req: Request, res: Response): Promise<void>;
    static getSalesByBranch(req: Request, res: Response): Promise<void>;
    static getSalesByTier(req: Request, res: Response): Promise<void>;
    static getSalesByProduct(req: Request, res: Response): Promise<void>;
    static getReceivablesSummary(req: Request, res: Response): Promise<void>;
    static getReceivablesAging(req: Request, res: Response): Promise<void>;
    static getCollectionsSummary(req: Request, res: Response): Promise<void>;
    static getInventorySummary(req: Request, res: Response): Promise<void>;
    static getInventoryLowStock(req: Request, res: Response): Promise<void>;
    static getInventoryValuation(req: Request, res: Response): Promise<void>;
    static getInventoryMovements(req: Request, res: Response): Promise<void>;
    static getPurchasingSummary(req: Request, res: Response): Promise<void>;
    static getPurchasingBySupplier(req: Request, res: Response): Promise<void>;
    static getPurchasingByBranch(req: Request, res: Response): Promise<void>;
    static getPayablesSummary(req: Request, res: Response): Promise<void>;
    static getPayablesAging(req: Request, res: Response): Promise<void>;
    static getReconciliationAudit(req: Request, res: Response): Promise<void>;
}
