"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.collectionRoutes = void 0;
const express_1 = require("express");
const collection_controller_js_1 = require("./collection.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const collection_schema_js_1 = require("./collection.schema.js");
exports.collectionRoutes = (0, express_1.Router)();
exports.collectionRoutes.post('/', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['collections', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(collection_schema_js_1.createCollectionSchema), collection_controller_js_1.CollectionController.createCollection);
exports.collectionRoutes.get('/', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['collections', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(collection_schema_js_1.collectionQuerySchema), collection_controller_js_1.CollectionController.getCollections);
exports.collectionRoutes.get('/outstanding', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['collections', 'pos']), collection_controller_js_1.CollectionController.getOutstanding);
exports.collectionRoutes.get('/overdue', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['collections', 'pos']), collection_controller_js_1.CollectionController.getOverdue);
exports.collectionRoutes.get('/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['collections', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(collection_schema_js_1.collectionParamSchema), collection_controller_js_1.CollectionController.getCollectionById);
exports.collectionRoutes.get('/:id/receipt', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['collections', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(collection_schema_js_1.collectionParamSchema), collection_controller_js_1.CollectionController.getCollectionReceipt);
//# sourceMappingURL=collection.routes.js.map