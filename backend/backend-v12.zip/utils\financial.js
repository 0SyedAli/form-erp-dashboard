"use strict";
/**
 * Molty Foam ERP — Decimal-Safe Financial Utilities & Pricing Engine
 *
 * Floating-point representation in JavaScript (IEEE 754) introduces rounding inaccuracies:
 * e.g., 0.1 + 0.2 === 0.30000000000000004.
 *
 * To ensure 100% financial audit integrity, all monetary calculations inside the
 * backend are computed using safe integer arithmetic (Paisa: 1 PKR = 100 Paisa),
 * and rounded explicitly before persistence and invoice ledger entry posting.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PAISA_FACTOR = void 0;
exports.toPaisa = toPaisa;
exports.toRupees = toRupees;
exports.roundCurrency = roundCurrency;
exports.calculatePurchasePrice = calculatePurchasePrice;
exports.calculateRetailPrice = calculateRetailPrice;
exports.calculateWholesalePrice = calculateWholesalePrice;
exports.calculateDistributorPrice = calculateDistributorPrice;
exports.calculateDiscountPercent = calculateDiscountPercent;
exports.calculateMarkupPercent = calculateMarkupPercent;
exports.validatePriceReconciliation = validatePriceReconciliation;
exports.calculateLineTotal = calculateLineTotal;
exports.calculateInvoiceTotals = calculateInvoiceTotals;
exports.PAISA_FACTOR = 100;
/**
 * Converts a Pakistani Rupee amount into Integer Paisa.
 */
function toPaisa(rupees) {
    if (typeof rupees !== 'number' || isNaN(rupees) || !isFinite(rupees))
        return 0;
    return Math.round(rupees * exports.PAISA_FACTOR);
}
/**
 * Converts Integer Paisa back to exact Pakistani Rupees.
 */
function toRupees(paisa) {
    if (typeof paisa !== 'number' || isNaN(paisa) || !isFinite(paisa))
        return 0;
    return Math.round(paisa) / exports.PAISA_FACTOR;
}
/**
 * Rounds any Rupee currency amount to 2 decimal places cleanly.
 */
function roundCurrency(rupees) {
    return toRupees(toPaisa(rupees));
}
/**
 * Pricing Engine Calculations (Integer Paisa Standard)
 */
function calculatePurchasePrice(listPricePaisa, discountPercent) {
    if (listPricePaisa <= 0)
        return 0;
    const pct = Math.max(0, Math.min(100, discountPercent));
    return Math.round(listPricePaisa * (1 - pct / 100));
}
function calculateRetailPrice(listPricePaisa, markupPercent) {
    if (listPricePaisa <= 0)
        return 0;
    const pct = Math.max(0, markupPercent);
    return Math.round(listPricePaisa * (1 + pct / 100));
}
function calculateWholesalePrice(listPricePaisa, discountPercent) {
    if (listPricePaisa <= 0)
        return 0;
    const pct = Math.max(0, Math.min(100, discountPercent));
    return Math.round(listPricePaisa * (1 - pct / 100));
}
function calculateDistributorPrice(listPricePaisa, discountPercent) {
    if (listPricePaisa <= 0)
        return 0;
    const pct = Math.max(0, Math.min(100, discountPercent));
    return Math.round(listPricePaisa * (1 - pct / 100));
}
function calculateDiscountPercent(listPricePaisa, pricePaisa) {
    if (listPricePaisa <= 0 || pricePaisa >= listPricePaisa)
        return 0;
    const rawPct = ((listPricePaisa - pricePaisa) / listPricePaisa) * 100;
    return Math.round(rawPct * 100) / 100;
}
function calculateMarkupPercent(listPricePaisa, pricePaisa) {
    if (listPricePaisa <= 0 || pricePaisa <= listPricePaisa)
        return 0;
    const rawPct = ((pricePaisa - listPricePaisa) / listPricePaisa) * 100;
    return Math.round(rawPct * 100) / 100;
}
/**
 * Validates that a user-submitted price matches its submitted percentage within rounding tolerance.
 * Tolerance is 100 Paisa (1 PKR) or 1%.
 */
function validatePriceReconciliation(listPricePaisa, submittedPricePaisa, submittedPercent, type) {
    if (listPricePaisa <= 0)
        return true;
    let expectedPaisa = 0;
    if (type === 'PURCHASE') {
        expectedPaisa = calculatePurchasePrice(listPricePaisa, submittedPercent);
    }
    else if (type === 'RETAIL') {
        expectedPaisa = calculateRetailPrice(listPricePaisa, submittedPercent);
    }
    else if (type === 'WHOLESALE') {
        expectedPaisa = calculateWholesalePrice(listPricePaisa, submittedPercent);
    }
    else if (type === 'DISTRIBUTOR') {
        expectedPaisa = calculateDistributorPrice(listPricePaisa, submittedPercent);
    }
    const diff = Math.abs(expectedPaisa - submittedPricePaisa);
    // Allow up to 100 Paisa (1 PKR) rounding difference
    return diff <= 100;
}
/**
 * Calculates line total safely: Quantity * Unit Price
 */
function calculateLineTotal(quantity, unitPriceRupees) {
    const q = Math.max(0, Math.round(quantity));
    const pricePaisa = toPaisa(unitPriceRupees);
    const totalPaisa = q * pricePaisa;
    return toRupees(totalPaisa);
}
/**
 * Computes subtotal, total, and balance due with integer-safe arithmetic.
 */
function calculateInvoiceTotals(items, discountRupees = 0, taxRupees = 0, paidRupees = 0) {
    let subtotalPaisa = 0;
    for (const item of items) {
        const q = Math.max(0, Math.round(item.quantity));
        const pPaisa = toPaisa(item.unitPrice);
        subtotalPaisa += q * pPaisa;
    }
    const discountPaisa = Math.max(0, toPaisa(discountRupees));
    const taxPaisa = Math.max(0, toPaisa(taxRupees));
    const totalPaisa = Math.max(0, subtotalPaisa - discountPaisa + taxPaisa);
    const paidPaisa = Math.max(0, toPaisa(paidRupees));
    const balanceDuePaisa = Math.max(0, totalPaisa - paidPaisa);
    return {
        subtotal: toRupees(subtotalPaisa),
        discount: toRupees(discountPaisa),
        tax: toRupees(taxPaisa),
        total: toRupees(totalPaisa),
        paidAmount: toRupees(paidPaisa),
        balanceDue: toRupees(balanceDuePaisa),
    };
}
//# sourceMappingURL=financial.js.map