"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PosController = void 0;
const pos_service_js_1 = require("./pos.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class PosController {
    static getUserContext(req) {
        return {
            accountId: req.account?._id?.toString() || '',
            loginId: req.account?.loginId || '',
            role: req.account?.role || 'BRANCH',
            branchId: req.account?.branchId?._id?.toString() || req.account?.branchId?.toString(),
            name: req.account?.branchId?.name,
            permissions: req.account?.permissions,
        };
    }
    static handleError(res, error, defaultMessage, defaultStatus = 500) {
        const err = error;
        const isWriteConflict = err.code === 112 ||
            err.codeName === 'WriteConflict' ||
            (err.errorLabels && err.errorLabels.includes('TransientTransactionError'));
        if (isWriteConflict) {
            (0, apiResponse_js_1.sendError)(res, 'Concurrent checkout conflict. Please retry the sale.', 409, 'WRITE_CONFLICT');
            return;
        }
        const msg = err.message || defaultMessage;
        const status = err.statusCode || defaultStatus;
        const code = err.code ||
            (status === 404
                ? 'NOT_FOUND'
                : status === 403
                    ? 'FORBIDDEN'
                    : status === 409
                        ? 'CONFLICT'
                        : 'INTERNAL_ERROR');
        (0, apiResponse_js_1.sendError)(res, msg, status, code, err.details);
    }
    static async getBootstrap(req, res) {
        try {
            const branchId = req.query.branchId || req.account?.assignedBranchId?.toString();
            const clientVersion = req.headers['if-none-match'] || req.query.version;
            const data = await pos_service_js_1.PosService.getPOSBootstrap(branchId, clientVersion);
            if (data.notModified) {
                res.status(304).end();
                return;
            }
            if (data.versionHash) {
                res.setHeader('ETag', data.versionHash);
            }
            (0, apiResponse_js_1.sendSuccess)(res, data, 'POS bootstrap data loaded successfully.');
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to retrieve POS bootstrap data.');
        }
    }
    static async getOutOfStock(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const branchId = req.query.branchId || userContext.branchId;
            const data = await pos_service_js_1.PosService.getPOSOutOfStockCatalogue(userContext, branchId);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Out of stock catalogue retrieved successfully.');
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to retrieve out of stock catalogue.');
        }
    }
    static async getCatalogue(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const data = await pos_service_js_1.PosService.getPOSCatalogue(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'POS catalogue retrieved successfully.');
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to retrieve POS catalogue.');
        }
    }
    static async getAvailability(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const skuId = Array.isArray(req.params.skuId) ? req.params.skuId[0] : req.params.skuId;
            const data = await pos_service_js_1.PosService.getSkuAvailability(skuId, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock availability retrieved.');
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to fetch SKU availability.');
        }
    }
    static async checkout(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const result = await pos_service_js_1.PosService.checkout(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, result, result.message, result.isReplay ? 200 : 201);
        }
        catch (error) {
            PosController.handleError(res, error, 'Checkout failed.');
        }
    }
    static async getHeldSales(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const data = await pos_service_js_1.PosService.getHeldSales(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Held sales retrieved.');
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to retrieve held sales.');
        }
    }
    static async createHeldSale(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const data = await pos_service_js_1.PosService.createHeldSale(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Sale held successfully.', 201);
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to hold sale.');
        }
    }
    static async resumeHeldSale(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await pos_service_js_1.PosService.resumeHeldSale(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Held sale resumed.');
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to resume held sale.');
        }
    }
    static async deleteHeldSale(req, res) {
        try {
            const userContext = PosController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await pos_service_js_1.PosService.deleteHeldSale(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, data.message);
        }
        catch (error) {
            PosController.handleError(res, error, 'Failed to delete held sale.');
        }
    }
}
exports.PosController = PosController;
//# sourceMappingURL=pos.controller.js.map