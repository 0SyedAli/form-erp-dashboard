import mongoose, { Document } from 'mongoose';
export interface IPurchaseOrderItem {
    sku: string;
    variantId?: mongoose.Types.ObjectId;
    productName: string;
    brandName?: string;
    categoryName?: string;
    sizeLabel?: string;
    thicknessLabel?: string;
    orderedQuantity: number;
    receivedQuantity: number;
    unitCost: number;
    lineDiscount?: number;
    taxAmount?: number;
    lineTotal: number;
}
export type PurchaseOrderStatus = 'DRAFT' | 'PENDING_APPROVAL' | 'APPROVED' | 'PARTIALLY_RECEIVED' | 'FULLY_RECEIVED' | 'CANCELLED' | 'CLOSED';
export interface IPurchaseOrder extends Document {
    orderNumber: string;
    supplierId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    stockLocationId?: mongoose.Types.ObjectId;
    items: IPurchaseOrderItem[];
    subtotal: number;
    discountAmount: number;
    taxAmount: number;
    totalAmount: number;
    status: PurchaseOrderStatus;
    orderDate: Date;
    expectedDeliveryDate?: Date;
    paymentTerms: string;
    referenceNumber?: string;
    createdBy: string;
    createdByName?: string;
    approvedBy?: string;
    approvedByName?: string;
    approvedAt?: Date;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PurchaseOrder: mongoose.Model<IPurchaseOrder, {}, {}, {}, mongoose.Document<unknown, {}, IPurchaseOrder, {}, {}> & IPurchaseOrder & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
