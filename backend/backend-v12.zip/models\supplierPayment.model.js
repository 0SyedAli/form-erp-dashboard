"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierPayment = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const AllocationSchema = new mongoose_1.Schema({
    billId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'SupplierBill', required: true },
    billNumber: { type: String, required: true },
    supplierInvoiceNumber: { type: String },
    allocatedAmount: { type: Number, required: true, min: 0 },
    previousDue: { type: Number },
    newDue: { type: Number },
}, { _id: false });
const SupplierPaymentSchema = new mongoose_1.Schema({
    paymentNumber: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    supplierId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Supplier',
        required: true,
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    amount: {
        type: Number,
        required: true,
        min: 1,
    },
    paymentMethod: {
        type: String,
        enum: ['CASH', 'BANK_TRANSFER', 'CHEQUE', 'ONLINE', 'PAYPAK_CARD'],
        default: 'BANK_TRANSFER',
    },
    reference: {
        type: String,
        trim: true,
    },
    chequeDate: {
        type: Date,
    },
    chequeStatus: {
        type: String,
        enum: ['PENDING_CLEARANCE', 'CLEARED', 'BOUNCED'],
        default: 'CLEARED',
    },
    allocations: [AllocationSchema],
    unallocatedAdvance: {
        type: Number,
        default: 0,
        min: 0,
    },
    paidBy: {
        type: String,
        required: true,
    },
    createdBy: {
        type: String,
    },
    notes: {
        type: String,
    },
    paymentDate: {
        type: Date,
        default: Date.now,
        index: true,
    },
}, {
    timestamps: true,
});
exports.SupplierPayment = mongoose_1.default.model('SupplierPayment', SupplierPaymentSchema);
//# sourceMappingURL=supplierPayment.model.js.map