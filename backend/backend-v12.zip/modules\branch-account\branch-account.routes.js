"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.branchAccountRoutes = void 0;
const express_1 = require("express");
const branch_account_controller_js_1 = require("./branch-account.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const branch_account_schema_js_1 = require("./branch-account.schema.js");
exports.branchAccountRoutes = (0, express_1.Router)();
// Apply Super Admin authentication guard to all branch account management routes
exports.branchAccountRoutes.use(auth_middleware_js_1.authenticate, auth_middleware_js_1.requireSuperAdmin);
exports.branchAccountRoutes.post('/branches', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.createBranchSchema), branch_account_controller_js_1.BranchAccountController.createBranch);
exports.branchAccountRoutes.patch('/branches/:id', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.updateBranchDetailsSchema), branch_account_controller_js_1.BranchAccountController.updateBranch);
exports.branchAccountRoutes.get('/branches/:id/account', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.branchParamSchema), branch_account_controller_js_1.BranchAccountController.getAccount);
exports.branchAccountRoutes.post('/branches/:id/account', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.createBranchAccountSchema), branch_account_controller_js_1.BranchAccountController.createAccount);
exports.branchAccountRoutes.patch('/branches/:id/account', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.updateBranchAccountSchema), branch_account_controller_js_1.BranchAccountController.updateAccount);
exports.branchAccountRoutes.post('/branches/:id/reset-password', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.resetPasswordSchema), branch_account_controller_js_1.BranchAccountController.resetPassword);
exports.branchAccountRoutes.patch('/branches/:id/permissions', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.updatePermissionsSchema), branch_account_controller_js_1.BranchAccountController.updatePermissions);
exports.branchAccountRoutes.post('/branches/:id/deactivate-account', (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.branchParamSchema), branch_account_controller_js_1.BranchAccountController.deactivateAccount);
//# sourceMappingURL=branch-account.routes.js.map