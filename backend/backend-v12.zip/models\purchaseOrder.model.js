"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.PurchaseOrder = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const PurchaseOrderItemSchema = new mongoose_1.Schema({
    sku: { type: String, required: true },
    variantId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Variant' },
    productName: { type: String, default: '' },
    brandName: { type: String },
    categoryName: { type: String },
    sizeLabel: { type: String },
    thicknessLabel: { type: String },
    orderedQuantity: { type: Number, required: true, min: 1 },
    receivedQuantity: { type: Number, default: 0, min: 0 },
    unitCost: { type: Number, required: true, min: 0 },
    lineDiscount: { type: Number, default: 0, min: 0 },
    taxAmount: { type: Number, default: 0, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
}, { _id: false });
const PurchaseOrderSchema = new mongoose_1.Schema({
    orderNumber: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    supplierId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Supplier',
        required: true,
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    stockLocationId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'StockLocation',
        index: true,
    },
    items: [PurchaseOrderItemSchema],
    subtotal: {
        type: Number,
        required: true,
        min: 0,
    },
    discountAmount: {
        type: Number,
        default: 0,
        min: 0,
    },
    taxAmount: {
        type: Number,
        default: 0,
        min: 0,
    },
    totalAmount: {
        type: Number,
        required: true,
        min: 0,
    },
    status: {
        type: String,
        enum: [
            'DRAFT',
            'PENDING_APPROVAL',
            'APPROVED',
            'PARTIALLY_RECEIVED',
            'FULLY_RECEIVED',
            'CANCELLED',
            'CLOSED',
        ],
        default: 'DRAFT',
        index: true,
    },
    orderDate: {
        type: Date,
        default: Date.now,
        index: true,
    },
    expectedDeliveryDate: {
        type: Date,
    },
    paymentTerms: {
        type: String,
        default: 'Net 30 Days',
    },
    referenceNumber: {
        type: String,
        trim: true,
    },
    createdBy: {
        type: String,
        required: true,
    },
    createdByName: {
        type: String,
    },
    approvedBy: {
        type: String,
    },
    approvedByName: {
        type: String,
    },
    approvedAt: {
        type: Date,
    },
    notes: {
        type: String,
    },
}, {
    timestamps: true,
});
exports.PurchaseOrder = mongoose_1.default.model('PurchaseOrder', PurchaseOrderSchema);
//# sourceMappingURL=purchaseOrder.model.js.map