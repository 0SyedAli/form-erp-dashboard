import mongoose from 'mongoose';
import { CreateCollectionInput, CollectionQuery } from './collection.schema.js';
export interface UserContext {
    accountId: string;
    loginId: string;
    role: 'SUPER_ADMIN' | 'BRANCH';
    branchId?: string;
}
export declare class CollectionService {
    /**
     * 1. CREATE PAYMENT COLLECTION & ALLOCATE TO INVOICES
     * Runs in an atomic multi-document transaction:
     * - Validates customer & outstanding balances
     * - Allocates collection (manually or oldest-first)
     * - Updates invoice payment statuses
     * - Reduces customer outstanding balance
     * - Posts credit to customer ledger
     * - Generates durable collection receipt
     */
    static createCollection(input: CreateCollectionInput, userContext: UserContext): Promise<{
        collection: mongoose.Document<unknown, {}, import("../../models/paymentCollection.model.js").IPaymentCollection, {}, {}> & import("../../models/paymentCollection.model.js").IPaymentCollection & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        };
        message: string;
        isReplay: boolean;
        id?: undefined;
        collectionNumber?: undefined;
        receiptNumber?: undefined;
        amount?: undefined;
        totalCollected?: undefined;
        unallocatedAdvance?: undefined;
        unallocatedAmount?: undefined;
        appliedAmount?: undefined;
        newCustomerOutstanding?: undefined;
    } | {
        collection: {
            id: string;
            amount: number;
            unallocatedAdvance: number;
            collectionNumber: string;
            branchId: mongoose.Types.ObjectId;
            customerId: mongoose.Types.ObjectId;
            customerName: string;
            totalCollected: number;
            paymentMethod: "CASH" | "CARD" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE";
            reference?: string;
            allocations: import("../../models/paymentCollection.model.js").ICollectionAllocation[];
            unallocatedAmount: number;
            notes?: string;
            collectedBy: string;
            receiptNumber: string;
            collectionDate: Date;
            idempotencyKey?: string;
            createdAt: Date;
            updatedAt: Date;
            _id: mongoose.Types.ObjectId;
            $locals: Record<string, unknown>;
            $op: "save" | "validate" | "remove" | null;
            $where: Record<string, unknown>;
            baseModelName?: string;
            collection: mongoose.Collection;
            db: mongoose.Connection;
            errors?: mongoose.Error.ValidationError;
            isNew: boolean;
            schema: mongoose.Schema;
            __v: number;
        };
        id: string;
        collectionNumber: string;
        receiptNumber: string;
        amount: number;
        totalCollected: number;
        unallocatedAdvance: number;
        unallocatedAmount: number;
        appliedAmount: number;
        newCustomerOutstanding: number;
        message: string;
        isReplay: boolean;
    }>;
    /**
     * 2. LIST COLLECTIONS WITH FILTERS
     */
    static getCollections(query: CollectionQuery, userContext: UserContext): Promise<{
        collections: any[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    /**
     * 3. GET COLLECTION BY ID
     */
    static getCollectionById(id: string, userContext: UserContext): Promise<any>;
    /**
     * 4. GET COLLECTION RECEIPT VIEW
     */
    static getCollectionReceipt(id: string, userContext: UserContext): Promise<{
        receiptNumber: any;
        collectionNumber: any;
        date: any;
        branch: {
            name: any;
            shopNumber: any;
            address: any;
            phone: any;
        };
        customer: {
            name: any;
            phone: any;
            outstandingRemaining: any;
        };
        amountCollected: any;
        paymentMethod: any;
        reference: any;
        allocations: any;
        unallocatedAdvance: any;
        collectedBy: any;
        notes: any;
    }>;
    /**
     * 5. GET OUTSTANDING RECEIVABLES ACROSS CUSTOMERS
     */
    static getOutstandingCustomers(userContext: UserContext): Promise<{
        totalOutstanding: number;
        customerCount: number;
        customers: {
            id: any;
            name: any;
            phone: any;
            customerType: any;
            creditLimit: any;
            outstandingBalance: any;
            availableCredit: number;
        }[];
    }>;
    /**
     * 6. GET OVERDUE CUSTOMERS & INVOICES
     */
    static getOverdueCustomers(userContext: UserContext): Promise<{
        totalOverdue: number;
        overdueCount: number;
        invoices: (mongoose.FlattenMaps<import("../../models/salesInvoice.model.js").ISalesInvoice> & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
    }>;
}
