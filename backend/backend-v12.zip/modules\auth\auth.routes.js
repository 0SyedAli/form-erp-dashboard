"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRoutes = void 0;
const express_1 = require("express");
const auth_controller_js_1 = require("./auth.controller.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const auth_schema_js_1 = require("./auth.schema.js");
const rateLimiter_middleware_js_1 = require("../../middleware/rateLimiter.middleware.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
exports.authRoutes = (0, express_1.Router)();
exports.authRoutes.post('/login', rateLimiter_middleware_js_1.authRateLimiter, (0, validateRequest_middleware_js_1.validateRequest)(auth_schema_js_1.loginSchema), auth_controller_js_1.AuthController.login);
exports.authRoutes.post('/logout', auth_middleware_js_1.authenticate, auth_controller_js_1.AuthController.logout);
exports.authRoutes.get('/me', auth_middleware_js_1.authenticate, auth_controller_js_1.AuthController.me);
exports.authRoutes.post('/change-password', auth_middleware_js_1.authenticate, (0, validateRequest_middleware_js_1.validateRequest)(auth_schema_js_1.changePasswordSchema), auth_controller_js_1.AuthController.changePassword);
//# sourceMappingURL=auth.routes.js.map