import { z } from 'zod';
export declare const createBranchSchema: z.ZodObject<{
    body: z.ZodObject<{
        loginId: z.ZodString;
        email: z.ZodString;
        password: z.ZodString;
        shopNumber: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        code: z.ZodOptional<z.ZodString>;
        type: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        city: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        address: z.ZodOptional<z.ZodString>;
        phone: z.ZodOptional<z.ZodString>;
        targetMonthlySales: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        settings: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
    }, "strip", z.ZodTypeAny, {
        type: string;
        loginId: string;
        password: string;
        email: string;
        shopNumber: string;
        city: string;
        targetMonthlySales: number;
        code?: string | undefined;
        name?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        settings?: Record<string, boolean> | undefined;
    }, {
        loginId: string;
        password: string;
        email: string;
        shopNumber: string;
        code?: string | undefined;
        type?: string | undefined;
        name?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        targetMonthlySales?: number | undefined;
        settings?: Record<string, boolean> | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        type: string;
        loginId: string;
        password: string;
        email: string;
        shopNumber: string;
        city: string;
        targetMonthlySales: number;
        code?: string | undefined;
        name?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        settings?: Record<string, boolean> | undefined;
    };
}, {
    body: {
        loginId: string;
        password: string;
        email: string;
        shopNumber: string;
        code?: string | undefined;
        type?: string | undefined;
        name?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        targetMonthlySales?: number | undefined;
        settings?: Record<string, boolean> | undefined;
    };
}>;
export declare const createBranchAccountSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        loginId: z.ZodString;
        name: z.ZodString;
        password: z.ZodString;
        email: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        loginId: string;
        password: string;
        name: string;
        email?: string | undefined;
    }, {
        loginId: string;
        password: string;
        name: string;
        email?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        loginId: string;
        password: string;
        name: string;
        email?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        loginId: string;
        password: string;
        name: string;
        email?: string | undefined;
    };
}>;
export declare const updateBranchAccountSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        loginId: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
        email: z.ZodOptional<z.ZodString>;
        isActive: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        loginId?: string | undefined;
        name?: string | undefined;
        email?: string | undefined;
        isActive?: boolean | undefined;
    }, {
        loginId?: string | undefined;
        name?: string | undefined;
        email?: string | undefined;
        isActive?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        loginId?: string | undefined;
        name?: string | undefined;
        email?: string | undefined;
        isActive?: boolean | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        loginId?: string | undefined;
        name?: string | undefined;
        email?: string | undefined;
        isActive?: boolean | undefined;
    };
}>;
export declare const resetPasswordSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodEffects<z.ZodObject<{
        newPassword: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        password?: string | undefined;
        newPassword?: string | undefined;
    }, {
        password?: string | undefined;
        newPassword?: string | undefined;
    }>, {
        password?: string | undefined;
        newPassword?: string | undefined;
    }, {
        password?: string | undefined;
        newPassword?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        password?: string | undefined;
        newPassword?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        password?: string | undefined;
        newPassword?: string | undefined;
    };
}>;
export declare const updatePermissionsSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        permissions: z.ZodRecord<z.ZodString, z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        permissions: Record<string, boolean>;
    }, {
        permissions: Record<string, boolean>;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        permissions: Record<string, boolean>;
    };
}, {
    params: {
        id: string;
    };
    body: {
        permissions: Record<string, boolean>;
    };
}>;
export declare const branchParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export declare const updateBranchDetailsSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        code: z.ZodOptional<z.ZodString>;
        shopNumber: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodString>;
        city: z.ZodOptional<z.ZodString>;
        address: z.ZodOptional<z.ZodString>;
        phone: z.ZodOptional<z.ZodString>;
        targetMonthlySales: z.ZodOptional<z.ZodNumber>;
        isActive: z.ZodOptional<z.ZodBoolean>;
        settings: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodBoolean>>;
    }, "strip", z.ZodTypeAny, {
        code?: string | undefined;
        type?: string | undefined;
        name?: string | undefined;
        isActive?: boolean | undefined;
        shopNumber?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        targetMonthlySales?: number | undefined;
        settings?: Record<string, boolean> | undefined;
    }, {
        code?: string | undefined;
        type?: string | undefined;
        name?: string | undefined;
        isActive?: boolean | undefined;
        shopNumber?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        targetMonthlySales?: number | undefined;
        settings?: Record<string, boolean> | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        code?: string | undefined;
        type?: string | undefined;
        name?: string | undefined;
        isActive?: boolean | undefined;
        shopNumber?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        targetMonthlySales?: number | undefined;
        settings?: Record<string, boolean> | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        code?: string | undefined;
        type?: string | undefined;
        name?: string | undefined;
        isActive?: boolean | undefined;
        shopNumber?: string | undefined;
        city?: string | undefined;
        address?: string | undefined;
        phone?: string | undefined;
        targetMonthlySales?: number | undefined;
        settings?: Record<string, boolean> | undefined;
    };
}>;
export type CreateBranchInput = z.infer<typeof createBranchSchema>['body'];
export type CreateBranchAccountInput = z.infer<typeof createBranchAccountSchema>['body'];
export type UpdateBranchAccountInput = z.infer<typeof updateBranchAccountSchema>['body'];
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>['body'];
export type UpdatePermissionsInput = z.infer<typeof updatePermissionsSchema>['body'];
export type UpdateBranchDetailsInput = z.infer<typeof updateBranchDetailsSchema>['body'];
