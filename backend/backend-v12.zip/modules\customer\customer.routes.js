"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.customerRoutes = void 0;
const express_1 = require("express");
const customer_controller_js_1 = require("./customer.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const customer_schema_js_1 = require("./customer.schema.js");
exports.customerRoutes = (0, express_1.Router)();
// List customers (POS cashiers and customer managers)
exports.customerRoutes.get('/', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.customerQuerySchema), customer_controller_js_1.CustomerController.getCustomers);
// Create customer
exports.customerRoutes.post('/', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.createCustomerSchema), customer_controller_js_1.CustomerController.createCustomer);
// Get customer profile
exports.customerRoutes.get('/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.customerParamSchema), customer_controller_js_1.CustomerController.getCustomerById);
// Update customer
exports.customerRoutes.patch('/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.updateCustomerSchema), customer_controller_js_1.CustomerController.updateCustomer);
// Customer Account Ledger
exports.customerRoutes.get('/:id/ledger', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.customerParamSchema), customer_controller_js_1.CustomerController.getCustomerLedger);
// Customer Outstanding Invoices
exports.customerRoutes.get('/:id/outstanding', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos', 'collections']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.customerParamSchema), customer_controller_js_1.CustomerController.getCustomerOutstanding);
// Customer Purchase Invoices
exports.customerRoutes.get('/:id/invoices', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['customers', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(customer_schema_js_1.customerParamSchema), customer_controller_js_1.CustomerController.getCustomerInvoices);
//# sourceMappingURL=customer.routes.js.map