import mongoose, { Document } from 'mongoose';
import { SaleType } from '../constants/index.js';
export interface IPriceItem {
    variantId: mongoose.Types.ObjectId;
    price: number;
}
export interface IPriceList extends Document {
    name: string;
    type: SaleType;
    prices: IPriceItem[];
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PriceList: mongoose.Model<IPriceList, {}, {}, {}, mongoose.Document<unknown, {}, IPriceList, {}, {}> & IPriceList & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
