import { Request, Response } from 'express';
export declare class PosController {
    private static getUserContext;
    private static handleError;
    static getBootstrap(req: Request, res: Response): Promise<void>;
    static getOutOfStock(req: Request, res: Response): Promise<void>;
    static getCatalogue(req: Request, res: Response): Promise<void>;
    static getAvailability(req: Request, res: Response): Promise<void>;
    static checkout(req: Request, res: Response): Promise<void>;
    static getHeldSales(req: Request, res: Response): Promise<void>;
    static createHeldSale(req: Request, res: Response): Promise<void>;
    static resumeHeldSale(req: Request, res: Response): Promise<void>;
    static deleteHeldSale(req: Request, res: Response): Promise<void>;
}
