"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InventoryController = void 0;
const inventory_service_js_1 = require("./inventory.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class InventoryController {
    static getUserContext(req) {
        return {
            accountId: req.account?._id?.toString() || '',
            loginId: req.account?.loginId || '',
            role: req.account?.role || 'BRANCH',
            branchId: req.account?.branchId?._id?.toString() || req.account?.branchId?.toString(),
        };
    }
    static handleError(res, error, defaultMessage, defaultStatus = 500) {
        const err = error;
        const msg = err.message || defaultMessage;
        const status = err.statusCode || defaultStatus;
        const code = err.code || (status === 404 ? 'NOT_FOUND' : status === 403 ? 'FORBIDDEN' : status === 409 ? 'CONFLICT' : 'INTERNAL_ERROR');
        (0, apiResponse_js_1.sendError)(res, msg, status, code, err.details);
    }
    // ==========================================
    // STOCK BALANCES
    // ==========================================
    static async getStockBalances(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getStockBalances({
                branchId: req.query.branchId,
                stockLocationId: req.query.stockLocationId,
                sku: req.query.sku,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit
                    ? parseInt(req.query.limit, 10)
                    : req.query.all === 'true' || req.query.all === '1'
                        ? 5000
                        : 100,
            }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.balances, 'Stock balances retrieved successfully.', 200, data.pagination);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch stock balances.');
        }
    }
    static async getStockBySku(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const sku = Array.isArray(req.params.sku) ? req.params.sku[0] : req.params.sku;
            const data = await inventory_service_js_1.InventoryService.getStockBySku(sku, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch stock for SKU.', 404);
        }
    }
    static async getStockLocations(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const branchId = req.query.branchId;
            const data = await inventory_service_js_1.InventoryService.getStockLocations(branchId, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch stock locations.');
        }
    }
    static async updateMinimumStock(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const skuId = Array.isArray(req.params.skuId) ? req.params.skuId[0] : req.params.skuId;
            const data = await inventory_service_js_1.InventoryService.updateMinimumStock(skuId, req.body.reorderLevel, req.body.stockLocationId, req.body.branchId, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Minimum stock level updated successfully.');
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to update minimum stock.');
        }
    }
    // ==========================================
    // OPENING STOCK
    // ==========================================
    static async postOpeningStock(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.postOpeningStock(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Opening stock recorded successfully.', 201);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to post opening stock.');
        }
    }
    // ==========================================
    // STOCK RECEIVING
    // ==========================================
    static async createStockReceipt(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.createStockReceipt(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Goods received and stock updated successfully.', 201);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to process goods receipt.');
        }
    }
    static async getStockReceipts(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getStockReceipts({
                branchId: req.query.branchId,
                supplierId: req.query.supplierId,
                dateFrom: req.query.dateFrom,
                dateTo: req.query.dateTo,
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit
                    ? parseInt(req.query.limit, 10)
                    : req.query.all === 'true' || req.query.all === '1'
                        ? 5000
                        : 100,
            }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.receipts, 'Stock receipts retrieved.', 200, data.pagination);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch receipts.');
        }
    }
    static async getStockReceiptById(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.getStockReceiptById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch receipt.', 404);
        }
    }
    // ==========================================
    // STOCK ADJUSTMENTS
    // ==========================================
    static async createAdjustments(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.createAdjustments(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock adjustments applied and reconciled successfully.', 201);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to apply stock adjustments.');
        }
    }
    static async getAdjustments(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getAdjustments({
                branchId: req.query.branchId,
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit
                    ? parseInt(req.query.limit, 10)
                    : req.query.all === 'true' || req.query.all === '1'
                        ? 5000
                        : 100,
            }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.adjustments, 'Stock adjustments retrieved.', 200, data.pagination);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch adjustments.');
        }
    }
    // ==========================================
    // STOCK TRANSFERS
    // ==========================================
    static async getTransfers(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getTransfers({
                fromBranchId: req.query.fromBranchId,
                toBranchId: req.query.toBranchId,
                status: req.query.status,
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit
                    ? parseInt(req.query.limit, 10)
                    : req.query.all === 'true' || req.query.all === '1'
                        ? 5000
                        : 100,
            }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.transfers, 'Stock transfers retrieved.', 200, data.pagination);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch transfers.');
        }
    }
    static async createTransfer(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.createTransfer(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock transfer initiated successfully.', 201);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to initiate transfer.');
        }
    }
    static async getTransferById(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.getTransferById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch transfer.', 404);
        }
    }
    static async approveTransfer(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.approveTransfer(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock transfer approved and source stock reserved.');
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to approve transfer.');
        }
    }
    static async dispatchTransfer(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.dispatchTransfer(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock transfer dispatched and in transit.');
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to dispatch transfer.');
        }
    }
    static async receiveTransfer(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.receiveTransfer(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock transfer received and destination stock incremented.');
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to receive transfer.');
        }
    }
    static async cancelTransfer(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.cancelTransfer(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Stock transfer cancelled successfully.');
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to cancel transfer.');
        }
    }
    // ==========================================
    // STOCK MOVEMENTS & HISTORY
    // ==========================================
    static async getStockMovements(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getStockMovements({
                branchId: req.query.branchId,
                stockLocationId: req.query.stockLocationId,
                sku: req.query.sku,
                movementType: req.query.movementType,
                dateFrom: req.query.dateFrom,
                dateTo: req.query.dateTo,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit
                    ? parseInt(req.query.limit, 10)
                    : req.query.all === 'true' || req.query.all === '1'
                        ? 5000
                        : 100,
            }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.movements, 'Stock movements retrieved.', 200, data.pagination);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch movements.');
        }
    }
    static async getStockMovementById(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await inventory_service_js_1.InventoryService.getStockMovementById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch movement.', 404);
        }
    }
    // ==========================================
    // STOCK ALERTS
    // ==========================================
    static async getStockAlerts(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getStockAlerts({
                branchId: req.query.branchId,
                status: req.query.status,
                brandId: req.query.brandId,
                categoryId: req.query.categoryId,
                search: req.query.search,
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit ? parseInt(req.query.limit, 10) : 50,
            }, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, { alerts: data.alerts, metrics: data.metrics }, 'Stock alerts retrieved.', 200, data.pagination);
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch stock alerts.');
        }
    }
    // ==========================================
    // INVENTORY SUMMARY
    // ==========================================
    static async getInventorySummary(req, res) {
        try {
            const userContext = InventoryController.getUserContext(req);
            const data = await inventory_service_js_1.InventoryService.getInventorySummary(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Inventory summary retrieved.');
        }
        catch (error) {
            InventoryController.handleError(res, error, 'Failed to fetch inventory summary.');
        }
    }
}
exports.InventoryController = InventoryController;
//# sourceMappingURL=inventory.controller.js.map