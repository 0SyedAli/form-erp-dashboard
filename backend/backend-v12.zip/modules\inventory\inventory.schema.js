"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.skuParamSchema = exports.idParamSchema = exports.alertsQuerySchema = exports.movementsQuerySchema = exports.transferActionSchema = exports.createTransferSchema = exports.createAdjustmentSchema = exports.createStockReceiptSchema = exports.openingStockSchema = exports.updateMinimumStockSchema = exports.stockQuerySchema = void 0;
const zod_1 = require("zod");
const index_js_1 = require("../../constants/index.js");
exports.stockQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        sku: zod_1.z.string().optional(),
        search: zod_1.z.string().optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('20'),
    }),
});
exports.updateMinimumStockSchema = zod_1.z.object({
    params: zod_1.z.object({
        skuId: zod_1.z.string().min(1, 'SKU or Variant ID is required'),
    }),
    body: zod_1.z.object({
        reorderLevel: zod_1.z.number().int().min(0, 'Minimum stock must be non-negative'),
        stockLocationId: zod_1.z.string().optional(),
        branchId: zod_1.z.string().optional(),
    }),
});
exports.openingStockSchema = zod_1.z.object({
    body: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().min(1, 'Stock location is required'),
        sku: zod_1.z.string().min(1, 'SKU is required'),
        quantity: zod_1.z.number().int().min(0, 'Quantity cannot be negative'),
        minimumStock: zod_1.z.number().int().min(0).optional(),
        notes: zod_1.z.string().optional(),
    }),
});
exports.createStockReceiptSchema = zod_1.z.object({
    body: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        receiptNumber: zod_1.z.string().optional(),
        supplierId: zod_1.z.string().optional(),
        supplierReference: zod_1.z.string().optional(),
        receivedDate: zod_1.z.string().optional(),
        items: zod_1.z
            .array(zod_1.z.object({
            sku: zod_1.z.string().min(1, 'SKU is required'),
            quantityOrdered: zod_1.z.number().int().min(1).optional(),
            quantityReceived: zod_1.z.number().int().min(1, 'Quantity received must be at least 1'),
            unitCost: zod_1.z.number().min(0).optional(),
        }))
            .min(1, 'Receipt must contain at least one line item'),
        idempotencyKey: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
    }),
});
exports.createAdjustmentSchema = zod_1.z.object({
    body: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        items: zod_1.z
            .array(zod_1.z.object({
            sku: zod_1.z.string().min(1, 'SKU is required'),
            newPhysicalQuantity: zod_1.z.number().int().min(0, 'Physical quantity cannot be negative'),
            adjustmentType: zod_1.z
                .enum(['PHYSICAL_COUNT', 'ADMINISTRATIVE', 'DAMAGE_WRITE_OFF'])
                .optional()
                .default('PHYSICAL_COUNT'),
            reason: zod_1.z.string().min(1, 'Adjustment reason is required'),
        }))
            .min(1, 'Adjustment must contain at least one item'),
        idempotencyKey: zod_1.z.string().optional(),
    }),
});
exports.createTransferSchema = zod_1.z.object({
    body: zod_1.z.object({
        fromBranchId: zod_1.z.string().optional(),
        toBranchId: zod_1.z.string().min(1, 'Destination branch ID is required'),
        fromStockLocationId: zod_1.z.string().min(1, 'Source stock location ID is required'),
        toStockLocationId: zod_1.z.string().min(1, 'Destination stock location ID is required'),
        items: zod_1.z
            .array(zod_1.z.object({
            sku: zod_1.z.string().min(1, 'SKU is required'),
            quantity: zod_1.z.number().int().min(1, 'Quantity must be at least 1'),
        }))
            .min(1, 'Transfer must contain at least one item'),
        notes: zod_1.z.string().optional(),
    }),
});
exports.transferActionSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Transfer ID is required'),
    }),
    body: zod_1.z
        .object({
        notes: zod_1.z.string().optional(),
    })
        .optional(),
});
exports.movementsQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        stockLocationId: zod_1.z.string().optional(),
        sku: zod_1.z.string().optional(),
        movementType: zod_1.z.enum(Object.values(index_js_1.STOCK_MOVEMENT_TYPES)).optional(),
        dateFrom: zod_1.z.string().optional(),
        dateTo: zod_1.z.string().optional(),
        search: zod_1.z.string().optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('20'),
    }),
});
exports.alertsQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        status: zod_1.z.enum(['ALL', 'OUT_OF_STOCK', 'LOW_STOCK']).optional().default('ALL'),
        brandId: zod_1.z.string().optional(),
        categoryId: zod_1.z.string().optional(),
        search: zod_1.z.string().optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('50'),
    }),
});
exports.idParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'ID is required'),
    }),
});
exports.skuParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        sku: zod_1.z.string().min(1, 'SKU is required'),
    }),
});
//# sourceMappingURL=inventory.schema.js.map