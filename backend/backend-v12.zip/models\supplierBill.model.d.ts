import mongoose, { Document } from 'mongoose';
export interface ISupplierBillItem {
    sku: string;
    variantId?: mongoose.Types.ObjectId;
    productName: string;
    quantity: number;
    unitCost: number;
    discount?: number;
    tax?: number;
    total: number;
}
export type SupplierBillStatus = 'DRAFT' | 'POSTED' | 'CANCELLED';
export type SupplierBillPaymentStatus = 'UNPAID' | 'PARTIALLY_PAID' | 'PAID';
export interface ISupplierBill extends Document {
    billNumber: string;
    supplierInvoiceNumber: string;
    supplierId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    purchaseOrderId?: mongoose.Types.ObjectId;
    grnIds: mongoose.Types.ObjectId[];
    billDate: Date;
    dueDate: Date;
    items: ISupplierBillItem[];
    subtotal: number;
    discountAmount: number;
    taxAmount: number;
    totalAmount: number;
    paidAmount: number;
    balanceDue: number;
    status: SupplierBillStatus;
    paymentStatus: SupplierBillPaymentStatus;
    createdBy: string;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const SupplierBill: mongoose.Model<ISupplierBill, {}, {}, {}, mongoose.Document<unknown, {}, ISupplierBill, {}, {}> & ISupplierBill & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
