import mongoose, { Document } from 'mongoose';
export interface IReceiptItem {
    sku: string;
    variantId?: mongoose.Types.ObjectId;
    productName?: string;
    sizeLabel?: string;
    thicknessLabel?: string;
    quantityOrdered: number;
    quantityReceived: number;
    damagedQuantity?: number;
    unitCost: number;
    lineTotal: number;
}
export interface IStockReceipt extends Document {
    receiptNumber: string;
    purchaseOrderId?: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    supplierId?: mongoose.Types.ObjectId;
    supplierReference?: string;
    stockLocationId: mongoose.Types.ObjectId;
    items: IReceiptItem[];
    totalQuantity: number;
    totalCost: number;
    receivedBy: string;
    receivedDate: Date;
    status: 'COMPLETED' | 'PARTIAL' | 'CANCELLED';
    notes?: string;
    createdAt: Date;
}
export declare const StockReceipt: mongoose.Model<IStockReceipt, {}, {}, {}, mongoose.Document<unknown, {}, IStockReceipt, {}, {}> & IStockReceipt & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
