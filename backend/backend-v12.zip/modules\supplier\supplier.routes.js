"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplierRoutes = void 0;
const express_1 = require("express");
const supplier_controller_js_1 = require("./supplier.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const supplier_schema_js_1 = require("./supplier.schema.js");
exports.supplierRoutes = (0, express_1.Router)();
// All supplier endpoints require authentication and 'suppliers' permission
exports.supplierRoutes.use(auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('suppliers'));
exports.supplierRoutes.get('/', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.supplierQuerySchema), supplier_controller_js_1.SupplierController.getSuppliers);
exports.supplierRoutes.post('/', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.createSupplierSchema), supplier_controller_js_1.SupplierController.createSupplier);
exports.supplierRoutes.get('/:id', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.supplierParamSchema), supplier_controller_js_1.SupplierController.getSupplierById);
exports.supplierRoutes.patch('/:id', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.updateSupplierSchema), supplier_controller_js_1.SupplierController.updateSupplier);
exports.supplierRoutes.patch('/:id/status', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.updateSupplierStatusSchema), supplier_controller_js_1.SupplierController.updateStatus);
exports.supplierRoutes.get('/:id/ledger', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.supplierParamSchema), supplier_controller_js_1.SupplierController.getSupplierLedger);
exports.supplierRoutes.get('/:id/outstanding', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.supplierParamSchema), supplier_controller_js_1.SupplierController.getSupplierOutstanding);
exports.supplierRoutes.get('/:id/bills', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.supplierParamSchema), supplier_controller_js_1.SupplierController.getSupplierBills);
exports.supplierRoutes.get('/:id/payments', (0, validateRequest_middleware_js_1.validateRequest)(supplier_schema_js_1.supplierParamSchema), supplier_controller_js_1.SupplierController.getSupplierPayments);
//# sourceMappingURL=supplier.routes.js.map