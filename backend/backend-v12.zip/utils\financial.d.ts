/**
 * Molty Foam ERP — Decimal-Safe Financial Utilities & Pricing Engine
 *
 * Floating-point representation in JavaScript (IEEE 754) introduces rounding inaccuracies:
 * e.g., 0.1 + 0.2 === 0.30000000000000004.
 *
 * To ensure 100% financial audit integrity, all monetary calculations inside the
 * backend are computed using safe integer arithmetic (Paisa: 1 PKR = 100 Paisa),
 * and rounded explicitly before persistence and invoice ledger entry posting.
 */
export declare const PAISA_FACTOR = 100;
/**
 * Converts a Pakistani Rupee amount into Integer Paisa.
 */
export declare function toPaisa(rupees: number): number;
/**
 * Converts Integer Paisa back to exact Pakistani Rupees.
 */
export declare function toRupees(paisa: number): number;
/**
 * Rounds any Rupee currency amount to 2 decimal places cleanly.
 */
export declare function roundCurrency(rupees: number): number;
/**
 * Pricing Engine Calculations (Integer Paisa Standard)
 */
export declare function calculatePurchasePrice(listPricePaisa: number, discountPercent: number): number;
export declare function calculateRetailPrice(listPricePaisa: number, markupPercent: number): number;
export declare function calculateWholesalePrice(listPricePaisa: number, discountPercent: number): number;
export declare function calculateDistributorPrice(listPricePaisa: number, discountPercent: number): number;
export declare function calculateDiscountPercent(listPricePaisa: number, pricePaisa: number): number;
export declare function calculateMarkupPercent(listPricePaisa: number, pricePaisa: number): number;
/**
 * Validates that a user-submitted price matches its submitted percentage within rounding tolerance.
 * Tolerance is 100 Paisa (1 PKR) or 1%.
 */
export declare function validatePriceReconciliation(listPricePaisa: number, submittedPricePaisa: number, submittedPercent: number, type: 'PURCHASE' | 'RETAIL' | 'WHOLESALE' | 'DISTRIBUTOR'): boolean;
/**
 * Calculates line total safely: Quantity * Unit Price
 */
export declare function calculateLineTotal(quantity: number, unitPriceRupees: number): number;
export interface InvoiceCalculatedTotals {
    subtotal: number;
    discount: number;
    tax: number;
    total: number;
    paidAmount: number;
    balanceDue: number;
}
/**
 * Computes subtotal, total, and balance due with integer-safe arithmetic.
 */
export declare function calculateInvoiceTotals(items: Array<{
    quantity: number;
    unitPrice: number;
}>, discountRupees?: number, taxRupees?: number, paidRupees?: number): InvoiceCalculatedTotals;
