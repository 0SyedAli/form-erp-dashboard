import { z } from 'zod';
export declare const createCollectionSchema: z.ZodObject<{
    body: z.ZodObject<{
        customerId: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        amount: z.ZodNumber;
        paymentMethod: z.ZodDefault<z.ZodEnum<["CASH", "CARD", "BANK_TRANSFER", "CHEQUE", "ONLINE"]>>;
        reference: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
        allocations: z.ZodOptional<z.ZodArray<z.ZodObject<{
            invoiceId: z.ZodString;
            allocatedAmount: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            invoiceId: string;
            allocatedAmount: number;
        }, {
            invoiceId: string;
            allocatedAmount: number;
        }>, "many">>;
        idempotencyKey: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        customerId: string;
        amount: number;
        paymentMethod: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD";
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        reference?: string | undefined;
        allocations?: {
            invoiceId: string;
            allocatedAmount: number;
        }[] | undefined;
    }, {
        customerId: string;
        amount: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        paymentMethod?: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD" | undefined;
        reference?: string | undefined;
        allocations?: {
            invoiceId: string;
            allocatedAmount: number;
        }[] | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        customerId: string;
        amount: number;
        paymentMethod: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD";
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        reference?: string | undefined;
        allocations?: {
            invoiceId: string;
            allocatedAmount: number;
        }[] | undefined;
    };
}, {
    body: {
        customerId: string;
        amount: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        paymentMethod?: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD" | undefined;
        reference?: string | undefined;
        allocations?: {
            invoiceId: string;
            allocatedAmount: number;
        }[] | undefined;
    };
}>;
export declare const collectionQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        customerId: z.ZodOptional<z.ZodString>;
        dateFrom: z.ZodOptional<z.ZodString>;
        dateTo: z.ZodOptional<z.ZodString>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        branchId?: string | undefined;
        customerId?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    }, {
        limit?: string | undefined;
        branchId?: string | undefined;
        customerId?: string | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        branchId?: string | undefined;
        customerId?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    };
}, {
    query: {
        limit?: string | undefined;
        branchId?: string | undefined;
        customerId?: string | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    };
}>;
export declare const collectionParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export type CreateCollectionInput = z.infer<typeof createCollectionSchema>['body'];
export type CollectionQuery = z.infer<typeof collectionQuerySchema>['query'];
