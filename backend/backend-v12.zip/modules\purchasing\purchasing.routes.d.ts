export declare const purchasingRoutes: import("express-serve-static-core").Router;
