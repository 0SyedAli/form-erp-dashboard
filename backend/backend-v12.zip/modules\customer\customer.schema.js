"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.customerParamSchema = exports.updateCustomerSchema = exports.createCustomerSchema = exports.customerQuerySchema = void 0;
const zod_1 = require("zod");
const index_js_1 = require("../../constants/index.js");
exports.customerQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        search: zod_1.z.string().optional(),
        branchId: zod_1.z.string().optional(),
        customerType: zod_1.z
            .enum([index_js_1.CUSTOMER_TYPES.WALK_IN, index_js_1.CUSTOMER_TYPES.WHOLESALE, index_js_1.CUSTOMER_TYPES.DISTRIBUTOR])
            .optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'BLOCKED']).optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('50'),
    }),
});
exports.createCustomerSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z.string().min(2, 'Customer name must be at least 2 characters'),
        phone: zod_1.z.string().min(7, 'Valid phone number required'),
        branchId: zod_1.z.string().optional(),
        customerType: zod_1.z
            .enum([index_js_1.CUSTOMER_TYPES.WALK_IN, index_js_1.CUSTOMER_TYPES.WHOLESALE, index_js_1.CUSTOMER_TYPES.DISTRIBUTOR])
            .default(index_js_1.CUSTOMER_TYPES.WALK_IN),
        businessName: zod_1.z.string().optional(),
        email: zod_1.z.string().email().optional().or(zod_1.z.literal('')),
        address: zod_1.z.string().optional(),
        city: zod_1.z.string().optional().default('Karachi'),
        taxNumber: zod_1.z.string().optional(),
        creditEnabled: zod_1.z.boolean().optional().default(false),
        creditLimit: zod_1.z.number().min(0).optional().default(0),
        creditTerms: zod_1.z.string().optional().default('Net 30'),
        defaultDueDays: zod_1.z.number().min(0).optional().default(30),
        notes: zod_1.z.string().optional(),
    }),
});
exports.updateCustomerSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Customer ID is required'),
    }),
    body: zod_1.z.object({
        name: zod_1.z.string().min(2).optional(),
        phone: zod_1.z.string().min(7).optional(),
        branchId: zod_1.z.string().optional(),
        customerType: zod_1.z
            .enum([index_js_1.CUSTOMER_TYPES.WALK_IN, index_js_1.CUSTOMER_TYPES.WHOLESALE, index_js_1.CUSTOMER_TYPES.DISTRIBUTOR])
            .optional(),
        businessName: zod_1.z.string().optional(),
        email: zod_1.z.string().email().optional().or(zod_1.z.literal('')),
        address: zod_1.z.string().optional(),
        city: zod_1.z.string().optional(),
        taxNumber: zod_1.z.string().optional(),
        creditEnabled: zod_1.z.boolean().optional(),
        creditLimit: zod_1.z.number().min(0).optional(),
        creditTerms: zod_1.z.string().optional(),
        defaultDueDays: zod_1.z.number().min(0).optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE', 'BLOCKED']).optional(),
        notes: zod_1.z.string().optional(),
    }),
});
exports.customerParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Customer ID is required'),
    }),
    query: zod_1.z
        .object({
        branchId: zod_1.z.string().optional(),
    })
        .optional(),
});
//# sourceMappingURL=customer.schema.js.map