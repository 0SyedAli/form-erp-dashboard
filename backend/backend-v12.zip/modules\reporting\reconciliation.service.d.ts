export interface DiscrepancyReportItem {
    category: 'SALES' | 'COLLECTIONS' | 'RECEIVABLES' | 'INVENTORY' | 'PURCHASES' | 'PAYABLES';
    recordReference: string;
    expectedValue: number;
    actualValue: number;
    difference: number;
    severity: 'OK' | 'WARNING' | 'CRITICAL';
    message: string;
}
export interface ReconciliationResult {
    generatedAt: string;
    summary: {
        totalChecks: number;
        passedChecks: number;
        warningsCount: number;
        criticalCount: number;
        overallStatus: 'RECONCILED' | 'ATTENTION_REQUIRED' | 'CRITICAL_DISCREPANCY';
    };
    checks: DiscrepancyReportItem[];
}
export declare class ReconciliationService {
    /**
     * Runs complete cross-module audit across Sales, Collections, Receivables,
     * Inventory, Purchases, and Accounts Payable against real MongoDB documents.
     */
    static runFullAudit(): Promise<ReconciliationResult>;
}
