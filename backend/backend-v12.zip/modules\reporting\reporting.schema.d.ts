import { z } from 'zod';
export declare const dateRangePresetEnum: z.ZodEnum<["today", "yesterday", "last7days", "thisMonth", "lastMonth", "custom", "all"]>;
export declare const reportQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        preset: z.ZodDefault<z.ZodOptional<z.ZodEnum<["today", "yesterday", "last7days", "thisMonth", "lastMonth", "custom", "all"]>>>;
        startDate: z.ZodOptional<z.ZodString>;
        endDate: z.ZodOptional<z.ZodString>;
        branchId: z.ZodOptional<z.ZodString>;
        supplierId: z.ZodOptional<z.ZodString>;
        customerId: z.ZodOptional<z.ZodString>;
        sku: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        page: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        preset: "custom" | "all" | "today" | "yesterday" | "last7days" | "thisMonth" | "lastMonth";
        branchId?: string | undefined;
        sku?: string | undefined;
        supplierId?: string | undefined;
        customerId?: string | undefined;
        startDate?: string | undefined;
        endDate?: string | undefined;
    }, {
        limit?: number | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        supplierId?: string | undefined;
        customerId?: string | undefined;
        page?: number | undefined;
        preset?: "custom" | "all" | "today" | "yesterday" | "last7days" | "thisMonth" | "lastMonth" | undefined;
        startDate?: string | undefined;
        endDate?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        preset: "custom" | "all" | "today" | "yesterday" | "last7days" | "thisMonth" | "lastMonth";
        branchId?: string | undefined;
        sku?: string | undefined;
        supplierId?: string | undefined;
        customerId?: string | undefined;
        startDate?: string | undefined;
        endDate?: string | undefined;
    };
}, {
    query: {
        limit?: number | undefined;
        branchId?: string | undefined;
        sku?: string | undefined;
        supplierId?: string | undefined;
        customerId?: string | undefined;
        page?: number | undefined;
        preset?: "custom" | "all" | "today" | "yesterday" | "last7days" | "thisMonth" | "lastMonth" | undefined;
        startDate?: string | undefined;
        endDate?: string | undefined;
    };
}>;
export type ReportQueryParams = z.infer<typeof reportQuerySchema>['query'];
