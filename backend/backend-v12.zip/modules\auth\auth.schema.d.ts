import { z } from 'zod';
export declare const loginSchema: z.ZodObject<{
    body: z.ZodObject<{
        loginId: z.ZodString;
        password: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        loginId: string;
        password: string;
    }, {
        loginId: string;
        password: string;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        loginId: string;
        password: string;
    };
}, {
    body: {
        loginId: string;
        password: string;
    };
}>;
export type LoginInput = z.infer<typeof loginSchema>['body'];
export declare const changePasswordSchema: z.ZodObject<{
    body: z.ZodObject<{
        currentPassword: z.ZodString;
        newPassword: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        currentPassword: string;
        newPassword: string;
    }, {
        currentPassword: string;
        newPassword: string;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        currentPassword: string;
        newPassword: string;
    };
}, {
    body: {
        currentPassword: string;
        newPassword: string;
    };
}>;
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>['body'];
