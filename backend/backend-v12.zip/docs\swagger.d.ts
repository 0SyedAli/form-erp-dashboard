export declare const openApiSpec: {
    openapi: string;
    info: {
        title: string;
        version: string;
        description: string;
        contact: {
            name: string;
        };
    };
    servers: {
        url: string;
        description: string;
    }[];
    components: {
        securitySchemes: {
            cookieAuth: {
                type: string;
                in: string;
                name: string;
                description: string;
            };
            bearerAuth: {
                type: string;
                scheme: string;
                description: string;
            };
        };
        schemas: {
            ApiResponse: {
                type: string;
                properties: {
                    success: {
                        type: string;
                        example: boolean;
                    };
                    data: {
                        type: string;
                    };
                    message: {
                        type: string;
                    };
                };
            };
            ApiError: {
                type: string;
                properties: {
                    success: {
                        type: string;
                        example: boolean;
                    };
                    error: {
                        type: string;
                        properties: {
                            code: {
                                type: string;
                                example: string;
                            };
                            message: {
                                type: string;
                                example: string;
                            };
                            details: {
                                type: string;
                                items: {
                                    type: string;
                                };
                            };
                        };
                    };
                };
            };
            LoginRequest: {
                type: string;
                required: string[];
                properties: {
                    loginId: {
                        type: string;
                        example: string;
                    };
                    password: {
                        type: string;
                        example: string;
                    };
                };
            };
            HealthResponse: {
                type: string;
                properties: {
                    status: {
                        type: string;
                        example: string;
                    };
                    service: {
                        type: string;
                        example: string;
                    };
                    version: {
                        type: string;
                        example: string;
                    };
                    timestamp: {
                        type: string;
                        format: string;
                    };
                    uptimeSeconds: {
                        type: string;
                        example: number;
                    };
                    database: {
                        type: string;
                        properties: {
                            connected: {
                                type: string;
                                example: boolean;
                            };
                            readyState: {
                                type: string;
                                example: number;
                            };
                            isReplicaSet: {
                                type: string;
                                example: boolean;
                            };
                        };
                    };
                };
            };
        };
    };
    paths: {
        '/health': {
            get: {
                summary: string;
                description: string;
                responses: {
                    '200': {
                        description: string;
                        content: {
                            'application/json': {
                                schema: {
                                    $ref: string;
                                };
                            };
                        };
                    };
                };
            };
        };
        '/auth/login': {
            post: {
                summary: string;
                description: string;
                requestBody: {
                    required: boolean;
                    content: {
                        'application/json': {
                            schema: {
                                $ref: string;
                            };
                        };
                    };
                };
                responses: {
                    '200': {
                        description: string;
                        content: {
                            'application/json': {
                                schema: {
                                    $ref: string;
                                };
                            };
                        };
                    };
                    '401': {
                        description: string;
                        content: {
                            'application/json': {
                                schema: {
                                    $ref: string;
                                };
                            };
                        };
                    };
                };
            };
        };
        '/auth/me': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                        content: {
                            'application/json': {
                                schema: {
                                    $ref: string;
                                };
                            };
                        };
                    };
                    '401': {
                        description: string;
                    };
                };
            };
        };
        '/auth/logout': {
            post: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/brands': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/categories': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/sizes': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/thicknesses': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/products': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/skus': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/skus/{id}/prices': {
            get: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            patch: {
                summary: string;
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/stock': {
            get: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/opening-stock': {
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/receipts': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/adjustments': {
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/transfers': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/transfers/{id}/approve': {
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/transfers/{id}/dispatch': {
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/transfers/{id}/receive': {
            post: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/movements': {
            get: {
                summary: string;
                tags: string[];
                description: string;
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/alerts': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/inventory/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/pos/catalogue': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/pos/products/{skuId}/availability': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/pos/checkout': {
            post: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                    '400': {
                        description: string;
                    };
                };
            };
        };
        '/pos/held-sales': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/sales/invoices': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/sales/invoices/{id}': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/sales/invoices/{id}/receipt': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/sales/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/customers': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            post: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
        };
        '/customers/{id}': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
            patch: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/customers/{id}/ledger': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/customers/{id}/outstanding': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/collections': {
            post: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '201': {
                        description: string;
                    };
                };
            };
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/collections/outstanding': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/collections/overdue': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/dashboard/admin': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/dashboard/branch': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/sales/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/receivables/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/receivables/aging': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/inventory/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/inventory/valuation': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/purchases/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/payables/summary': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
        '/reports/reconciliation': {
            get: {
                summary: string;
                tags: string[];
                security: ({
                    cookieAuth: never[];
                    bearerAuth?: undefined;
                } | {
                    bearerAuth: never[];
                    cookieAuth?: undefined;
                })[];
                responses: {
                    '200': {
                        description: string;
                    };
                };
            };
        };
    };
};
