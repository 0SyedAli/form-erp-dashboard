"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireBranchPermission = requireBranchPermission;
exports.requireAnyBranchPermission = requireAnyBranchPermission;
const index_js_1 = require("../constants/index.js");
const apiResponse_js_1 = require("../utils/apiResponse.js");
function requireBranchPermission(permissionKey) {
    return (req, res, next) => {
        if (!req.account) {
            (0, apiResponse_js_1.sendError)(res, 'Authentication required to evaluate permissions.', 401, 'UNAUTHORIZED');
            return;
        }
        // Super Admin has full unrestricted access across all modules
        if (req.account.role === index_js_1.ACCOUNT_ROLES.SUPER_ADMIN) {
            return next();
        }
        // Branch account permission check
        const accountPermissions = req.account.permissions;
        const hasPermission = Boolean(accountPermissions && accountPermissions[permissionKey] === true);
        if (!hasPermission) {
            (0, apiResponse_js_1.sendError)(res, `Branch account lacks the required permission: "${String(permissionKey)}". Please contact Super Admin.`, 403, 'INSUFFICIENT_PERMISSIONS', { requiredPermission: permissionKey });
            return;
        }
        next();
    };
}
function requireAnyBranchPermission(permissionKeys) {
    return (req, res, next) => {
        if (!req.account) {
            (0, apiResponse_js_1.sendError)(res, 'Authentication required to evaluate permissions.', 401, 'UNAUTHORIZED');
            return;
        }
        if (req.account.role === index_js_1.ACCOUNT_ROLES.SUPER_ADMIN) {
            return next();
        }
        const accountPermissions = req.account.permissions;
        const hasAny = permissionKeys.some((k) => Boolean(accountPermissions && accountPermissions[k] === true));
        if (!hasAny) {
            (0, apiResponse_js_1.sendError)(res, `Branch account lacks any of the required permissions: [${permissionKeys.join(', ')}]. Please contact Super Admin.`, 403, 'INSUFFICIENT_PERMISSIONS', { requiredPermissions: permissionKeys });
            return;
        }
        next();
    };
}
//# sourceMappingURL=branchPermission.middleware.js.map