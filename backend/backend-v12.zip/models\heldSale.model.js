"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.HeldSale = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const index_js_1 = require("../constants/index.js");
const HeldCartItemSchema = new mongoose_1.Schema({
    sku: { type: String, required: true },
    productId: { type: String },
    productName: { type: String, required: true },
    sizeLabel: { type: String },
    thicknessLabel: { type: String },
    quantity: { type: Number, required: true, min: 1 },
    unitPrice: { type: Number, required: true, min: 0 },
    lineTotal: { type: Number, required: true, min: 0 },
}, { _id: false });
const HeldSaleSchema = new mongoose_1.Schema({
    heldNumber: { type: String, required: true, unique: true, index: true },
    branchId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Branch', required: true, index: true },
    cashierId: { type: String },
    cashierName: { type: String, required: true },
    customerId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Customer' },
    customerName: { type: String, required: true, default: 'Walk-in Customer' },
    customerPhone: { type: String },
    saleType: { type: String, enum: Object.values(index_js_1.SALE_TYPES), default: index_js_1.SALE_TYPES.WALK_IN },
    paymentArrangement: { type: String, enum: Object.values(index_js_1.PAYMENT_ARRANGEMENTS), default: index_js_1.PAYMENT_ARRANGEMENTS.FULL },
    items: { type: [HeldCartItemSchema], required: true },
    subtotal: { type: Number, required: true, min: 0 },
    discountAmount: { type: Number, default: 0, min: 0 },
    taxAmount: { type: Number, default: 0, min: 0 },
    grandTotal: { type: Number, required: true, min: 0 },
    notes: { type: String },
}, { timestamps: true });
HeldSaleSchema.index({ branchId: 1, createdAt: -1 });
exports.HeldSale = mongoose_1.default.model('HeldSale', HeldSaleSchema);
//# sourceMappingURL=heldSale.model.js.map