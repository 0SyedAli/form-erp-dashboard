import { ReportQueryParams } from './reporting.schema.js';
export declare class ReportingService {
    /**
     * 1. Super Admin Consolidated Dashboard Metrics
     */
    static getAdminDashboard(query: ReportQueryParams): Promise<any>;
    /**
     * 2. Branch Dashboard Metrics (Scoped to the authenticated branch)
     */
    static getBranchDashboard(branchId: string, query: ReportQueryParams): Promise<any>;
    /**
     * 3. Detailed Sales Summary & Analytics
     */
    static getSalesSummary(query: ReportQueryParams): Promise<any>;
    /**
     * 4. Sales Trends (Daily/Weekly/Monthly)
     */
    static getSalesTrends(query: ReportQueryParams): Promise<any>;
    /**
     * 5. Sales By Branch
     */
    static getSalesByBranch(query: ReportQueryParams): Promise<any>;
    /**
     * 6. Sales By Pricing Tier (WALK_IN, WHOLESALE, DISTRIBUTOR)
     */
    static getSalesByTier(query: ReportQueryParams): Promise<any>;
    /**
     * 7. Sales By Product (SKU, Brand, Category, Units Sold, Revenue)
     */
    static getSalesByProduct(query: ReportQueryParams): Promise<any>;
    /**
     * 8. Receivables Summary & Aging (Buckets: Not Due, 1-30, 31-60, 61-90, >90)
     */
    static getReceivablesSummary(): Promise<any>;
    static getReceivablesAging(): Promise<any>;
    /**
     * 9. Collections Summary
     */
    static getCollectionsSummary(query: ReportQueryParams): Promise<any>;
    /**
     * 10. Inventory Summary, Low Stock & Movements
     */
    static getInventorySummary(query: ReportQueryParams): Promise<any>;
    static getInventoryLowStock(query: ReportQueryParams): Promise<any>;
    static getInventoryValuation(): Promise<any>;
    static getInventoryMovements(query: ReportQueryParams): Promise<any>;
    /**
     * 11. Purchasing & Supplier Reports
     */
    static getPurchasingSummary(query: ReportQueryParams): Promise<any>;
    static getPurchasingBySupplier(query: ReportQueryParams): Promise<any>;
    static getPurchasingByBranch(query: ReportQueryParams): Promise<any>;
    /**
     * 12. Payables Summary & Aging
     */
    static getPayablesSummary(): Promise<any>;
    static getPayablesAging(): Promise<any>;
}
