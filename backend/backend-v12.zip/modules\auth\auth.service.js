"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const crypto_1 = __importDefault(require("crypto"));
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const index_js_1 = require("../../models/index.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
const env_js_1 = require("../../config/env.js");
class AuthService {
    /**
     * Authenticates user, creates hashed session in MongoDB, and logs audit trail.
     */
    static async login(input, ipAddress, userAgent) {
        const loginIdNormalized = input.loginId.trim().toLowerCase();
        const account = await index_js_1.Account.findOne({
            $or: [{ loginId: loginIdNormalized }, { email: loginIdNormalized }],
        });
        if (!account) {
            // Audit login failure without recording passwords
            await index_js_1.AuditLog.create({
                action: 'AUTH_LOGIN_FAILED',
                entity: 'Account',
                details: { loginId: loginIdNormalized, reason: 'ACCOUNT_NOT_FOUND' },
                ipAddress,
            });
            throw new apiResponse_js_1.AppError('Invalid login ID or password.', 401, 'INVALID_CREDENTIALS');
        }
        if (!account.isActive) {
            await index_js_1.AuditLog.create({
                action: 'AUTH_LOGIN_BLOCKED',
                entity: 'Account',
                entityId: account._id.toString(),
                accountId: account._id,
                branchId: account.branchId,
                details: { loginId: account.loginId, reason: 'ACCOUNT_INACTIVE' },
                ipAddress,
            });
            throw new apiResponse_js_1.AppError('Account is inactive. Please contact Super Admin.', 403, 'ACCOUNT_INACTIVE');
        }
        const isMatch = await bcryptjs_1.default.compare(input.password, account.passwordHash);
        if (!isMatch) {
            await index_js_1.AuditLog.create({
                action: 'AUTH_LOGIN_FAILED',
                entity: 'Account',
                entityId: account._id.toString(),
                accountId: account._id,
                branchId: account.branchId,
                details: { loginId: account.loginId, reason: 'INVALID_PASSWORD' },
                ipAddress,
            });
            throw new apiResponse_js_1.AppError('Invalid login ID or password.', 401, 'INVALID_CREDENTIALS');
        }
        // Generate cryptographically secure opaque session token
        const rawToken = crypto_1.default.randomBytes(32).toString('hex');
        const tokenHash = (0, index_js_1.hashToken)(rawToken);
        const expiresAt = new Date(Date.now() + env_js_1.env.SESSION_TTL_HOURS * 60 * 60 * 1000);
        // Persist only the SHA-256 hash in MongoDB
        await index_js_1.Session.create({
            tokenHash,
            accountId: account._id,
            branchId: account.branchId || null,
            role: account.role,
            expiresAt,
            ipAddress,
            userAgent,
            isValid: true,
        });
        // Update last login
        account.lastLoginAt = new Date();
        await account.save();
        // Audit log
        await index_js_1.AuditLog.create({
            action: 'AUTH_LOGIN_SUCCESS',
            entity: 'Account',
            entityId: account._id.toString(),
            accountId: account._id,
            branchId: account.branchId,
            details: { role: account.role, loginId: account.loginId },
            ipAddress,
        });
        // Fetch branch info if assigned
        let branchInfo = null;
        if (account.branchId) {
            branchInfo = await index_js_1.Branch.findById(account.branchId);
        }
        return {
            rawToken,
            expiresAt,
            account: {
                id: account._id.toString(),
                loginId: account.loginId,
                name: account.name,
                email: account.email,
                role: account.role,
                branchId: account.branchId?.toString(),
                permissions: account.permissions,
                branch: branchInfo
                    ? {
                        id: branchInfo._id.toString(),
                        code: branchInfo.code,
                        name: branchInfo.name,
                        shopNumber: branchInfo.shopNumber,
                        type: branchInfo.type,
                        city: branchInfo.city,
                    }
                    : null,
            },
        };
    }
    /**
     * Invalidates active session.
     */
    static async logout(rawToken, accountId) {
        if (rawToken) {
            const tokenHash = (0, index_js_1.hashToken)(rawToken);
            await index_js_1.Session.updateOne({ tokenHash }, { isValid: false });
        }
        if (accountId) {
            await index_js_1.AuditLog.create({
                action: 'AUTH_LOGOUT',
                entity: 'Account',
                entityId: accountId,
                details: { timestamp: new Date() },
            });
        }
    }
    /**
     * Returns current authenticated account context.
     */
    static async getProfile(accountId) {
        const account = await index_js_1.Account.findById(accountId);
        if (!account || !account.isActive) {
            throw new apiResponse_js_1.AppError('Account not found or inactive.', 404, 'ACCOUNT_NOT_FOUND');
        }
        let branchInfo = null;
        if (account.branchId) {
            branchInfo = await index_js_1.Branch.findById(account.branchId);
        }
        return {
            id: account._id.toString(),
            loginId: account.loginId,
            name: account.name,
            email: account.email,
            role: account.role,
            branchId: account.branchId?.toString(),
            permissions: account.permissions,
            branch: branchInfo
                ? {
                    id: branchInfo._id.toString(),
                    code: branchInfo.code,
                    name: branchInfo.name,
                    shopNumber: branchInfo.shopNumber,
                    type: branchInfo.type,
                    city: branchInfo.city,
                }
                : null,
        };
    }
    /**
     * Changes account password and invalidates all other active sessions.
     */
    static async changePassword(accountId, input, currentRawToken) {
        const account = await index_js_1.Account.findById(accountId);
        if (!account || !account.isActive) {
            throw new apiResponse_js_1.AppError('Account not found or inactive.', 404, 'ACCOUNT_NOT_FOUND');
        }
        const isMatch = await bcryptjs_1.default.compare(input.currentPassword, account.passwordHash);
        if (!isMatch) {
            throw new apiResponse_js_1.AppError('Incorrect current password.', 400, 'INVALID_CURRENT_PASSWORD');
        }
        account.passwordHash = await bcryptjs_1.default.hash(input.newPassword, 10);
        await account.save();
        // Invalidate all other sessions for this account except the current session (or all sessions)
        const currentTokenHash = currentRawToken ? (0, index_js_1.hashToken)(currentRawToken) : null;
        if (currentTokenHash) {
            await index_js_1.Session.updateMany({ accountId: account._id, tokenHash: { $ne: currentTokenHash } }, { isValid: false });
        }
        else {
            await index_js_1.Session.updateMany({ accountId: account._id }, { isValid: false });
        }
        await index_js_1.AuditLog.create({
            action: 'AUTH_PASSWORD_CHANGED',
            entity: 'Account',
            entityId: account._id.toString(),
            accountId: account._id,
            branchId: account.branchId,
            details: { timestamp: new Date() },
        });
        return { success: true, message: 'Password changed successfully.' };
    }
}
exports.AuthService = AuthService;
//# sourceMappingURL=auth.service.js.map