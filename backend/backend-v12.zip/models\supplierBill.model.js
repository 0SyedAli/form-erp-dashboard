"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierBill = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const SupplierBillItemSchema = new mongoose_1.Schema({
    sku: { type: String, required: true },
    variantId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Variant' },
    productName: { type: String, required: true },
    quantity: { type: Number, required: true, min: 1 },
    unitCost: { type: Number, required: true, min: 0 },
    discount: { type: Number, default: 0, min: 0 },
    tax: { type: Number, default: 0, min: 0 },
    total: { type: Number, required: true, min: 0 },
}, { _id: false });
const SupplierBillSchema = new mongoose_1.Schema({
    billNumber: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    supplierInvoiceNumber: {
        type: String,
        required: true,
        trim: true,
        index: true,
    },
    supplierId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Supplier',
        required: true,
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    purchaseOrderId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'PurchaseOrder',
        index: true,
    },
    grnIds: [
        {
            type: mongoose_1.Schema.Types.ObjectId,
            ref: 'StockReceipt',
        },
    ],
    billDate: {
        type: Date,
        default: Date.now,
        index: true,
    },
    dueDate: {
        type: Date,
        required: true,
        index: true,
    },
    items: [SupplierBillItemSchema],
    subtotal: {
        type: Number,
        required: true,
        min: 0,
    },
    discountAmount: {
        type: Number,
        default: 0,
        min: 0,
    },
    taxAmount: {
        type: Number,
        default: 0,
        min: 0,
    },
    totalAmount: {
        type: Number,
        required: true,
        min: 0,
    },
    paidAmount: {
        type: Number,
        default: 0,
        min: 0,
    },
    balanceDue: {
        type: Number,
        required: true,
        min: 0,
    },
    status: {
        type: String,
        enum: ['DRAFT', 'POSTED', 'CANCELLED'],
        default: 'DRAFT',
        index: true,
    },
    paymentStatus: {
        type: String,
        enum: ['UNPAID', 'PARTIALLY_PAID', 'PAID'],
        default: 'UNPAID',
        index: true,
    },
    createdBy: {
        type: String,
        required: true,
    },
    notes: {
        type: String,
    },
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
});
SupplierBillSchema.virtual('amountDue').get(function () {
    return this.balanceDue;
});
// Prevent duplicate supplier invoice numbers for the same supplier
SupplierBillSchema.index({ supplierId: 1, supplierInvoiceNumber: 1 }, { unique: true, partialFilterExpression: { status: { $ne: 'CANCELLED' } } });
exports.SupplierBill = mongoose_1.default.model('SupplierBill', SupplierBillSchema);
//# sourceMappingURL=supplierBill.model.js.map