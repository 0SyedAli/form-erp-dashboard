"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reportQuerySchema = exports.dateRangePresetEnum = void 0;
const zod_1 = require("zod");
exports.dateRangePresetEnum = zod_1.z.enum([
    'today',
    'yesterday',
    'last7days',
    'thisMonth',
    'lastMonth',
    'custom',
    'all',
]);
exports.reportQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        preset: exports.dateRangePresetEnum.optional().default('thisMonth'),
        startDate: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'startDate must be in YYYY-MM-DD format').optional(),
        endDate: zod_1.z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'endDate must be in YYYY-MM-DD format').optional(),
        branchId: zod_1.z.string().optional(),
        supplierId: zod_1.z.string().optional(),
        customerId: zod_1.z.string().optional(),
        sku: zod_1.z.string().optional(),
        limit: zod_1.z.coerce.number().min(1).max(100).optional().default(20),
        page: zod_1.z.coerce.number().min(1).optional().default(1),
    }),
});
//# sourceMappingURL=reporting.schema.js.map