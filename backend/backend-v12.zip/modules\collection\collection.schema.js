"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.collectionParamSchema = exports.collectionQuerySchema = exports.createCollectionSchema = void 0;
const zod_1 = require("zod");
exports.createCollectionSchema = zod_1.z.object({
    body: zod_1.z.object({
        customerId: zod_1.z.string().min(1, 'Customer ID is required'),
        branchId: zod_1.z.string().optional(),
        amount: zod_1.z.number().min(1, 'Collection amount must be at least 1'),
        paymentMethod: zod_1.z.enum(['CASH', 'CARD', 'BANK_TRANSFER', 'CHEQUE', 'ONLINE']).default('CASH'),
        reference: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
        allocations: zod_1.z
            .array(zod_1.z.object({
            invoiceId: zod_1.z.string().min(1),
            allocatedAmount: zod_1.z.number().min(1),
        }))
            .optional(), // If omitted, oldest-first auto-allocation is applied
        idempotencyKey: zod_1.z.string().optional(),
    }),
});
exports.collectionQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        branchId: zod_1.z.string().optional(),
        customerId: zod_1.z.string().optional(),
        dateFrom: zod_1.z.string().optional(),
        dateTo: zod_1.z.string().optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('20'),
    }),
});
exports.collectionParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Collection ID is required'),
    }),
});
//# sourceMappingURL=collection.schema.js.map