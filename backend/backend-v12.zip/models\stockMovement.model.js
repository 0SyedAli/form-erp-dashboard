"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockMovement = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const index_js_1 = require("../constants/index.js");
const StockMovementSchema = new mongoose_1.Schema({
    movementNumber: {
        type: String,
        required: true,
        unique: true,
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    stockLocationId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'StockLocation',
        required: true,
        index: true,
    },
    sku: {
        type: String,
        required: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    movementType: {
        type: String,
        enum: Object.values(index_js_1.STOCK_MOVEMENT_TYPES),
        required: true,
        index: true,
    },
    quantityDifference: {
        type: Number,
        required: true,
    },
    previousBalance: {
        type: Number,
        required: true,
    },
    newBalance: {
        type: Number,
        required: true,
    },
    referenceType: {
        type: String,
        trim: true,
    },
    referenceId: {
        type: String,
        trim: true,
        index: true,
    },
    reason: {
        type: String,
        trim: true,
    },
    performedBy: {
        type: String,
        required: true,
    },
    timestamp: {
        type: Date,
        default: Date.now,
        index: true,
    },
}, {
    timestamps: false, // Immutable audit document
});
exports.StockMovement = mongoose_1.default.model('StockMovement', StockMovementSchema);
//# sourceMappingURL=stockMovement.model.js.map