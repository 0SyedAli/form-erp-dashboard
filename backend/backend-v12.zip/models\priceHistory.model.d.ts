import mongoose, { Document } from 'mongoose';
export type PriceTier = 'LIST' | 'PURCHASE' | 'RETAIL' | 'WHOLESALE' | 'DISTRIBUTOR';
export interface IPriceHistory extends Document {
    variantId: mongoose.Types.ObjectId;
    sku: string;
    tier: PriceTier;
    previousPrice: number;
    newPrice: number;
    previousPercent?: number;
    newPercent?: number;
    changedByAccountId?: mongoose.Types.ObjectId;
    reason?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PriceHistory: mongoose.Model<IPriceHistory, {}, {}, {}, mongoose.Document<unknown, {}, IPriceHistory, {}, {}> & IPriceHistory & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
