"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SESSION_COOKIE_NAME = void 0;
exports.authenticate = authenticate;
exports.requireSuperAdmin = requireSuperAdmin;
exports.requireBranchAccount = requireBranchAccount;
exports.enforceBranchBoundary = enforceBranchBoundary;
const env_js_1 = require("../config/env.js");
const index_js_1 = require("../models/index.js");
const index_js_2 = require("../constants/index.js");
const apiResponse_js_1 = require("../utils/apiResponse.js");
exports.SESSION_COOKIE_NAME = 'molty_session_id';
/**
 * Authenticates the caller via Session Cookie or Authorization Header.
 * Finds session by SHA-256 hash of the opaque session token.
 */
async function authenticate(req, res, next) {
    try {
        // Check cookie first (normal or signed), fallback to Authorization: Bearer <token>
        let rawToken = req.cookies?.[exports.SESSION_COOKIE_NAME] || req.signedCookies?.[exports.SESSION_COOKIE_NAME];
        if (!rawToken && req.headers.authorization?.startsWith('Bearer ')) {
            rawToken = req.headers.authorization.split(' ')[1];
        }
        if (!rawToken) {
            (0, apiResponse_js_1.sendError)(res, 'Authentication required. No active session found.', 401, 'UNAUTHORIZED');
            return;
        }
        const tokenHash = (0, index_js_1.hashToken)(rawToken);
        const session = await index_js_1.Session.findOne({
            tokenHash,
            isValid: true,
            expiresAt: { $gt: new Date() },
        });
        const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https' || env_js_1.env.COOKIE_SECURE;
        if (!session) {
            res.clearCookie(exports.SESSION_COOKIE_NAME, {
                httpOnly: true,
                secure: isHttps,
                sameSite: isHttps ? 'none' : 'lax',
                domain: env_js_1.env.COOKIE_DOMAIN && env_js_1.env.COOKIE_DOMAIN !== 'localhost' ? env_js_1.env.COOKIE_DOMAIN : undefined,
                path: '/',
            });
            (0, apiResponse_js_1.sendError)(res, 'Session is invalid or has expired. Please log in again.', 401, 'SESSION_EXPIRED');
            return;
        }
        const account = await index_js_1.Account.findById(session.accountId);
        if (!account || !account.isActive) {
            res.clearCookie(exports.SESSION_COOKIE_NAME, {
                httpOnly: true,
                secure: isHttps,
                sameSite: isHttps ? 'none' : 'lax',
                domain: env_js_1.env.COOKIE_DOMAIN && env_js_1.env.COOKIE_DOMAIN !== 'localhost' ? env_js_1.env.COOKIE_DOMAIN : undefined,
                path: '/',
            });
            (0, apiResponse_js_1.sendError)(res, 'Session is invalid or account deactivated. Please log in again.', 401, 'SESSION_EXPIRED');
            return;
        }
        req.sessionRecord = session;
        req.account = account;
        next();
    }
    catch (error) {
        next(error);
    }
}
/**
 * Role Guard: Requires Super Admin account.
 */
function requireSuperAdmin(req, res, next) {
    if (!req.account) {
        (0, apiResponse_js_1.sendError)(res, 'Authentication required.', 401, 'UNAUTHORIZED');
        return;
    }
    if (req.account.role !== index_js_2.ACCOUNT_ROLES.SUPER_ADMIN) {
        (0, apiResponse_js_1.sendError)(res, 'Access denied. Super Admin privileges required.', 403, 'FORBIDDEN_NOT_ADMIN');
        return;
    }
    next();
}
/**
 * Role Guard: Requires Branch account.
 */
function requireBranchAccount(req, res, next) {
    if (!req.account) {
        (0, apiResponse_js_1.sendError)(res, 'Authentication required.', 401, 'UNAUTHORIZED');
        return;
    }
    if (req.account.role !== index_js_2.ACCOUNT_ROLES.BRANCH && req.account.role !== index_js_2.ACCOUNT_ROLES.SUPER_ADMIN) {
        (0, apiResponse_js_1.sendError)(res, 'Access denied. Branch operator account required.', 403, 'FORBIDDEN_NOT_BRANCH');
        return;
    }
    next();
}
/**
 * Security Rule: Enforces that a Branch Account can only access its own assigned branch data.
 * Even if a branch user supplies a different `branchId` in body or query params, this middleware
 * strictly overrides or rejects cross-branch tampering.
 */
function enforceBranchBoundary(req, res, next) {
    if (!req.account) {
        (0, apiResponse_js_1.sendError)(res, 'Authentication required.', 401, 'UNAUTHORIZED');
        return;
    }
    // Super Admin can access any branch
    if (req.account.role === index_js_2.ACCOUNT_ROLES.SUPER_ADMIN) {
        return next();
    }
    const assignedBranchId = req.account.branchId?.toString();
    if (!assignedBranchId) {
        (0, apiResponse_js_1.sendError)(res, 'Branch account has no assigned branch.', 403, 'UNASSIGNED_BRANCH_ACCOUNT');
        return;
    }
    // Check branchId parameter in route params
    if (req.params.branchId && req.params.branchId !== assignedBranchId) {
        (0, apiResponse_js_1.sendError)(res, 'Cross-branch access denied. You are restricted to your assigned branch.', 403, 'CROSS_BRANCH_ACCESS_DENIED');
        return;
    }
    // Check branchId in query params
    if (req.query.branchId && req.query.branchId !== assignedBranchId) {
        (0, apiResponse_js_1.sendError)(res, 'Cross-branch access denied. You are restricted to your assigned branch.', 403, 'CROSS_BRANCH_ACCESS_DENIED');
        return;
    }
    // Check branchId in JSON body if provided
    if (req.body && req.body.branchId && req.body.branchId !== assignedBranchId) {
        (0, apiResponse_js_1.sendError)(res, 'Cross-branch access denied. You cannot modify records for another branch.', 403, 'CROSS_BRANCH_ACCESS_DENIED');
        return;
    }
    // Auto-inject assigned branchId to guarantee scope safety
    if (req.body && typeof req.body === 'object') {
        req.body.branchId = assignedBranchId;
    }
    next();
}
//# sourceMappingURL=auth.middleware.js.map