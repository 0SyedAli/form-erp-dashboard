import mongoose, { Document } from 'mongoose';
import { AccountRole, BranchPermissions } from '../constants/index.js';
export interface IAccount extends Document {
    loginId: string;
    name: string;
    email?: string;
    passwordHash: string;
    role: AccountRole;
    branchId?: mongoose.Types.ObjectId;
    permissions: BranchPermissions;
    isActive: boolean;
    lastLoginAt?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Account: mongoose.Model<IAccount, {}, {}, {}, mongoose.Document<unknown, {}, IAccount, {}, {}> & IAccount & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
