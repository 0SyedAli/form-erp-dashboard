import { Request, Response } from 'express';
export declare class SalesController {
    private static getUserContext;
    private static handleError;
    static getInvoices(req: Request, res: Response): Promise<void>;
    static getInvoiceById(req: Request, res: Response): Promise<void>;
    static getInvoiceReceipt(req: Request, res: Response): Promise<void>;
    static getSalesSummary(req: Request, res: Response): Promise<void>;
    static deleteInvoice(req: Request, res: Response): Promise<void>;
}
