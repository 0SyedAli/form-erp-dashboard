"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const app_js_1 = require("./app.js");
const env_js_1 = require("./config/env.js");
const database_js_1 = require("./config/database.js");
const logger_js_1 = require("./utils/logger.js");
async function bootstrap() {
    const app = (0, app_js_1.createApp)();
    // Establish MongoDB connection
    try {
        await (0, database_js_1.connectDatabase)();
    }
    catch (error) {
        logger_js_1.logger.warn({ error }, 'MongoDB initial connection failed. Backend is running in resilient mode without active database session.');
    }
    const server = app.listen(env_js_1.env.PORT, () => {
        logger_js_1.logger.info(`=======================================================`);
        logger_js_1.logger.info(` Molty Foam ERP Backend API Server Started `);
        logger_js_1.logger.info(` Environment : ${env_js_1.env.NODE_ENV}`);
        logger_js_1.logger.info(` Port        : ${env_js_1.env.PORT}`);
        logger_js_1.logger.info(` API Base    : http://localhost:${env_js_1.env.PORT}/api/v1`);
        logger_js_1.logger.info(` Health Check: http://localhost:${env_js_1.env.PORT}/api/v1/health`);
        logger_js_1.logger.info(` Swagger Docs: http://localhost:${env_js_1.env.PORT}/api/v1/docs`);
        logger_js_1.logger.info(`=======================================================`);
    });
    // Graceful shutdown handling
    const shutdown = async (signal) => {
        logger_js_1.logger.info({ signal }, 'Graceful shutdown signal received. Closing HTTP server and database connections...');
        server.close(async () => {
            logger_js_1.logger.info('HTTP server closed.');
            await (0, database_js_1.disconnectDatabase)();
            process.exit(0);
        });
        // Force close after 10s timeout
        setTimeout(() => {
            logger_js_1.logger.error('Forced shutdown due to timeout.');
            process.exit(1);
        }, 10000);
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
}
bootstrap().catch((err) => {
    logger_js_1.logger.fatal({ err }, 'Fatal error during backend server bootstrap');
    process.exit(1);
});
//# sourceMappingURL=server.js.map