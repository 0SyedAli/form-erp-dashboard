import mongoose, { Document } from 'mongoose';
export interface ISize extends Document {
    length: number;
    width: number;
    unit: string;
    displayLabel: string;
    status: 'ACTIVE' | 'INACTIVE';
    createdAt: Date;
    updatedAt: Date;
}
export declare const Size: mongoose.Model<ISize, {}, {}, {}, mongoose.Document<unknown, {}, ISize, {}, {}> & ISize & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
