"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthController = void 0;
const database_js_1 = require("../../config/database.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class HealthController {
    static async getHealth(_req, res) {
        const dbStatus = (0, database_js_1.getDatabaseStatus)();
        const data = {
            status: 'healthy',
            service: 'molty-foam-erp-backend',
            version: '1.0.0',
            timestamp: new Date().toISOString(),
            uptimeSeconds: Math.floor(process.uptime()),
            environment: process.env.NODE_ENV || 'development',
            database: dbStatus,
            memoryUsageMb: {
                rss: Math.round(process.memoryUsage().rss / 1024 / 1024),
                heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
                heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
            },
        };
        (0, apiResponse_js_1.sendSuccess)(res, data, 'Molty Foam ERP Backend service is operational');
    }
}
exports.HealthController = HealthController;
//# sourceMappingURL=health.controller.js.map