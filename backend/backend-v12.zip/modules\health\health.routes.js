"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.healthRoutes = void 0;
const express_1 = require("express");
const health_controller_js_1 = require("./health.controller.js");
exports.healthRoutes = (0, express_1.Router)();
exports.healthRoutes.get('/health', health_controller_js_1.HealthController.getHealth);
//# sourceMappingURL=health.routes.js.map