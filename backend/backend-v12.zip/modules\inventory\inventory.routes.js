"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoryRoutes = void 0;
const express_1 = require("express");
const inventory_controller_js_1 = require("./inventory.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const inventory_schema_js_1 = require("./inventory.schema.js");
exports.inventoryRoutes = (0, express_1.Router)();
// ==========================================
// STOCK BALANCES & LOCATIONS
// ==========================================
exports.inventoryRoutes.get('/stock', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.stockQuerySchema), inventory_controller_js_1.InventoryController.getStockBalances);
exports.inventoryRoutes.get('/stock/:sku', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireAnyBranchPermission)(['viewStock', 'pos']), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.skuParamSchema), inventory_controller_js_1.InventoryController.getStockBySku);
exports.inventoryRoutes.get('/locations', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), inventory_controller_js_1.InventoryController.getStockLocations);
exports.inventoryRoutes.patch('/stock/:skuId/minimum', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('manageStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.updateMinimumStockSchema), inventory_controller_js_1.InventoryController.updateMinimumStock);
// ==========================================
// OPENING STOCK
// ==========================================
exports.inventoryRoutes.post('/opening-stock', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('manageStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.openingStockSchema), inventory_controller_js_1.InventoryController.postOpeningStock);
// ==========================================
// STOCK RECEIVING (GOODS RECEIVING)
// ==========================================
exports.inventoryRoutes.get('/receipts', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), inventory_controller_js_1.InventoryController.getStockReceipts);
exports.inventoryRoutes.post('/receipts', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('manageStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.createStockReceiptSchema), inventory_controller_js_1.InventoryController.createStockReceipt);
exports.inventoryRoutes.get('/receipts/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.getStockReceiptById);
// ==========================================
// STOCK ADJUSTMENTS (MANAGE STOCK)
// ==========================================
exports.inventoryRoutes.post('/adjustments', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('manageStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.createAdjustmentSchema), inventory_controller_js_1.InventoryController.createAdjustments);
exports.inventoryRoutes.get('/adjustments', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), inventory_controller_js_1.InventoryController.getAdjustments);
// ==========================================
// STOCK TRANSFERS (BRANCH-TO-BRANCH)
// ==========================================
exports.inventoryRoutes.get('/transfers', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('stockTransfers'), inventory_controller_js_1.InventoryController.getTransfers);
exports.inventoryRoutes.post('/transfers', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('stockTransfers'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.createTransferSchema), inventory_controller_js_1.InventoryController.createTransfer);
exports.inventoryRoutes.get('/transfers/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('stockTransfers'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.getTransferById);
exports.inventoryRoutes.post('/transfers/:id/approve', auth_middleware_js_1.authenticate, auth_middleware_js_1.requireSuperAdmin, (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.approveTransfer);
exports.inventoryRoutes.post('/transfers/:id/dispatch', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('stockTransfers'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.dispatchTransfer);
exports.inventoryRoutes.post('/transfers/:id/receive', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('stockTransfers'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.receiveTransfer);
exports.inventoryRoutes.post('/transfers/:id/cancel', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('stockTransfers'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.cancelTransfer);
// ==========================================
// STOCK MOVEMENTS (HISTORY & AUDIT)
// ==========================================
exports.inventoryRoutes.get('/movements', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.movementsQuerySchema), inventory_controller_js_1.InventoryController.getStockMovements);
exports.inventoryRoutes.get('/movements/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.idParamSchema), inventory_controller_js_1.InventoryController.getStockMovementById);
// ==========================================
// STOCK ALERTS
// ==========================================
exports.inventoryRoutes.get('/alerts', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), (0, validateRequest_middleware_js_1.validateRequest)(inventory_schema_js_1.alertsQuerySchema), inventory_controller_js_1.InventoryController.getStockAlerts);
// ==========================================
// INVENTORY SUMMARY
// ==========================================
exports.inventoryRoutes.get('/summary', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewStock'), inventory_controller_js_1.InventoryController.getInventorySummary);
//# sourceMappingURL=inventory.routes.js.map