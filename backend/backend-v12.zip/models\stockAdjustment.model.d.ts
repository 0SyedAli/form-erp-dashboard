import mongoose, { Document } from 'mongoose';
export interface IStockAdjustment extends Document {
    adjustmentNumber: string;
    branchId: mongoose.Types.ObjectId;
    stockLocationId: mongoose.Types.ObjectId;
    sku: string;
    adjustmentType: 'PHYSICAL_COUNT' | 'ADMINISTRATIVE' | 'DAMAGE_WRITE_OFF';
    quantityDifference: number;
    reason: string;
    authorizedBy: string;
    timestamp: Date;
}
export declare const StockAdjustment: mongoose.Model<IStockAdjustment, {}, {}, {}, mongoose.Document<unknown, {}, IStockAdjustment, {}, {}> & IStockAdjustment & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
