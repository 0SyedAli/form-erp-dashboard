"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supplierParamSchema = exports.supplierQuerySchema = exports.updateSupplierStatusSchema = exports.updateSupplierSchema = exports.createSupplierSchema = void 0;
const zod_1 = require("zod");
exports.createSupplierSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z.string().min(2, 'Supplier name must be at least 2 characters'),
        contactPerson: zod_1.z.string().optional(),
        phone: zod_1.z.string().min(7, 'Valid phone number is required'),
        whatsapp: zod_1.z.string().optional(),
        email: zod_1.z.string().email('Invalid email address').optional().or(zod_1.z.literal('')),
        address: zod_1.z.string().optional(),
        city: zod_1.z.string().optional().default('Karachi'),
        ntn: zod_1.z.string().optional(),
        suppliedBrands: zod_1.z.array(zod_1.z.string()).optional().default([]),
        creditEnabled: zod_1.z.boolean().optional().default(true),
        defaultCreditDays: zod_1.z.number().min(0).optional().default(30),
        paymentTerms: zod_1.z.string().optional().default('Net 30 Days'),
        creditLimit: zod_1.z.number().min(0).optional().default(1000000),
        openingPayable: zod_1.z.number().min(0).optional().default(0),
        bankName: zod_1.z.string().optional(),
        bankAccountNumber: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
    }),
});
exports.updateSupplierSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Supplier ID is required'),
    }),
    body: zod_1.z.object({
        name: zod_1.z.string().min(2).optional(),
        contactPerson: zod_1.z.string().optional(),
        phone: zod_1.z.string().min(7).optional(),
        whatsapp: zod_1.z.string().optional(),
        email: zod_1.z.string().email().optional().or(zod_1.z.literal('')),
        address: zod_1.z.string().optional(),
        city: zod_1.z.string().optional(),
        ntn: zod_1.z.string().optional(),
        suppliedBrands: zod_1.z.array(zod_1.z.string()).optional(),
        creditEnabled: zod_1.z.boolean().optional(),
        defaultCreditDays: zod_1.z.number().min(0).optional(),
        paymentTerms: zod_1.z.string().optional(),
        creditLimit: zod_1.z.number().min(0).optional(),
        bankName: zod_1.z.string().optional(),
        bankAccountNumber: zod_1.z.string().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE']).optional(),
        notes: zod_1.z.string().optional(),
    }),
});
exports.updateSupplierStatusSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Supplier ID is required'),
    }),
    body: zod_1.z.object({
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE']),
    }),
});
exports.supplierQuerySchema = zod_1.z.object({
    query: zod_1.z.object({
        search: zod_1.z.string().optional(),
        city: zod_1.z.string().optional(),
        status: zod_1.z.enum(['ACTIVE', 'INACTIVE']).optional(),
        page: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('1'),
        limit: zod_1.z.string().regex(/^\d+$/).transform(Number).optional().default('50'),
    }),
});
exports.supplierParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Supplier ID is required'),
    }),
});
//# sourceMappingURL=supplier.schema.js.map