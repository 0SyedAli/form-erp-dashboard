import mongoose, { Document } from 'mongoose';
export interface ICustomerLedgerEntry extends Document {
    customerId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    entryType: 'INVOICE' | 'PAYMENT' | 'ADJUSTMENT' | 'OPENING_BALANCE' | 'REVERSAL';
    referenceInvoiceId?: string;
    referencePaymentId?: string;
    debit: number;
    credit: number;
    runningBalance: number;
    narration: string;
    performedBy: string;
    timestamp: Date;
}
export declare const CustomerLedgerEntry: mongoose.Model<ICustomerLedgerEntry, {}, {}, {}, mongoose.Document<unknown, {}, ICustomerLedgerEntry, {}, {}> & ICustomerLedgerEntry & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
