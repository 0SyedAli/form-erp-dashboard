export declare const supplierRoutes: import("express-serve-static-core").Router;
