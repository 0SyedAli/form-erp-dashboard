"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PurchasingController = void 0;
const purchasing_service_js_1 = require("./purchasing.service.js");
const index_js_1 = require("../../models/index.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class PurchasingController {
    static getUserContext(req) {
        return {
            id: req.account?._id?.toString() || '',
            loginId: req.account?.loginId || '',
            role: (req.account?.role || 'BRANCH'),
            branchId: req.account?.branchId?._id?.toString() || req.account?.branchId?.toString(),
            branchName: req.account?.branchId?.name,
            permissions: req.account?.permissions,
        };
    }
    static getParam(req, key) {
        const val = req.params[key];
        return Array.isArray(val) ? val[0] : val || '';
    }
    static handleError(res, error, defaultMessage, defaultStatus = 500) {
        const err = error;
        const isWriteConflict = err.code === 112 ||
            err.codeName === 'WriteConflict' ||
            (err.errorLabels && err.errorLabels.includes('TransientTransactionError'));
        if (isWriteConflict) {
            (0, apiResponse_js_1.sendError)(res, 'Concurrent database conflict. Please retry the operation.', 409, 'WRITE_CONFLICT');
            return;
        }
        const msg = err.message || defaultMessage;
        const status = err.statusCode || defaultStatus;
        const code = err.code ||
            (status === 404
                ? 'NOT_FOUND'
                : status === 403
                    ? 'FORBIDDEN'
                    : status === 409
                        ? 'CONFLICT'
                        : status === 400
                            ? 'BAD_REQUEST'
                            : 'INTERNAL_ERROR');
        (0, apiResponse_js_1.sendError)(res, msg, status, code, err.details);
    }
    // --- Purchase Orders ---
    static async createPurchaseOrder(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.createPurchaseOrder(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase order created successfully in DRAFT status.', 201);
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to create purchase order.');
        }
    }
    static async getPurchaseOrders(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.getPurchaseOrders(req.query, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase orders retrieved successfully.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to retrieve purchase orders.');
        }
    }
    static async getPurchaseOrderById(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const id = PurchasingController.getParam(req, 'id');
            const data = await purchasing_service_js_1.PurchasingService.getPurchaseOrderById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase order details retrieved.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to retrieve purchase order details.');
        }
    }
    static async updatePurchaseOrder(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const id = PurchasingController.getParam(req, 'id');
            const data = await purchasing_service_js_1.PurchasingService.updatePurchaseOrder(id, req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase order updated successfully.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to update purchase order.');
        }
    }
    static async submitPurchaseOrder(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const id = PurchasingController.getParam(req, 'id');
            const data = await purchasing_service_js_1.PurchasingService.submitPurchaseOrder(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase order submitted for approval.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to submit purchase order.');
        }
    }
    static async approvePurchaseOrder(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const id = PurchasingController.getParam(req, 'id');
            const data = await purchasing_service_js_1.PurchasingService.approvePurchaseOrder(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase order approved successfully.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to approve purchase order.');
        }
    }
    static async cancelPurchaseOrder(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const id = PurchasingController.getParam(req, 'id');
            const reason = req.body.reason || 'Cancelled by user';
            const data = await purchasing_service_js_1.PurchasingService.cancelPurchaseOrder(id, reason, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase order cancelled successfully.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to cancel purchase order.');
        }
    }
    // --- Goods Receiving / GRN ---
    static async receivePurchaseOrder(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const id = PurchasingController.getParam(req, 'id');
            const data = await purchasing_service_js_1.PurchasingService.receivePurchaseOrder(id, req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Goods received and inventory balances updated.', 201);
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to receive goods against purchase order.');
        }
    }
    // --- Supplier Bills ---
    static async createSupplierBill(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.createSupplierBill(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier bill created and liability posted to ledger.', 201);
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to create supplier bill.');
        }
    }
    static async getSupplierBills(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.getSupplierBills(req.query, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier bills retrieved.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to retrieve supplier bills.');
        }
    }
    // --- Supplier Payments ---
    static async createSupplierPayment(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.createSupplierPayment(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Supplier payment recorded and ledger updated.', 201);
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to record supplier payment.');
        }
    }
    static async getSupplierPayments(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const filter = {};
            if (userContext.role === 'BRANCH') {
                filter.branchId = userContext.branchId;
            }
            else if (req.query.branchId) {
                filter.branchId = req.query.branchId;
            }
            if (req.query.supplierId) {
                filter.supplierId = req.query.supplierId;
            }
            const page = Math.max(1, Number(req.query.page) || 1);
            const limit = Math.max(1, Math.min(100, Number(req.query.limit) || 20));
            const skip = (page - 1) * limit;
            const [payments, total] = await Promise.all([
                index_js_1.SupplierPayment.find(filter)
                    .populate('supplierId', 'code name phone')
                    .populate('branchId', 'code name')
                    .sort({ paymentDate: -1, createdAt: -1 })
                    .skip(skip)
                    .limit(limit)
                    .lean(),
                index_js_1.SupplierPayment.countDocuments(filter),
            ]);
            (0, apiResponse_js_1.sendSuccess)(res, {
                payments,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            }, 'Supplier payments retrieved.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to retrieve supplier payments.');
        }
    }
    // --- Purchase Returns ---
    static async createPurchaseReturn(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.createPurchaseReturn(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchase return completed, inventory deducted, and debit note generated.', 201);
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to process purchase return.');
        }
    }
    static async getPurchaseReturns(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const filter = {};
            if (userContext.role === 'BRANCH') {
                filter.branchId = userContext.branchId;
            }
            else if (req.query.branchId) {
                filter.branchId = req.query.branchId;
            }
            if (req.query.supplierId) {
                filter.supplierId = req.query.supplierId;
            }
            const page = Math.max(1, Number(req.query.page) || 1);
            const limit = Math.max(1, Math.min(100, Number(req.query.limit) || 20));
            const skip = (page - 1) * limit;
            const [returns, total] = await Promise.all([
                index_js_1.PurchaseReturn.find(filter)
                    .populate('supplierId', 'code name phone')
                    .populate('branchId', 'code name')
                    .populate('stockLocationId', 'code name')
                    .sort({ returnDate: -1, createdAt: -1 })
                    .skip(skip)
                    .limit(limit)
                    .lean(),
                index_js_1.PurchaseReturn.countDocuments(filter),
            ]);
            (0, apiResponse_js_1.sendSuccess)(res, {
                returns,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            }, 'Purchase returns retrieved.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to retrieve purchase returns.');
        }
    }
    // --- Summary Metrics ---
    static async getPurchasingSummary(req, res) {
        try {
            const userContext = PurchasingController.getUserContext(req);
            const data = await purchasing_service_js_1.PurchasingService.getPurchasingSummary(userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Purchasing summary metrics retrieved.');
        }
        catch (error) {
            PurchasingController.handleError(res, error, 'Failed to retrieve purchasing summary.');
        }
    }
}
exports.PurchasingController = PurchasingController;
//# sourceMappingURL=purchasing.controller.js.map