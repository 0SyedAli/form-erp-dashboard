import mongoose from 'mongoose';
import { BranchPermissions } from '../../constants/index.js';
import { CreateBranchInput, CreateBranchAccountInput, UpdateBranchAccountInput, ResetPasswordInput, UpdatePermissionsInput, UpdateBranchDetailsInput } from './branch-account.schema.js';
export declare class BranchAccountService {
    /**
     * Helper to locate branch by Mongo ObjectId or branch code/loginId.
     */
    private static findBranch;
    /**
     * Helper to sanitize account payload (strips passwordHash).
     */
    private static sanitizeAccount;
    /**
     * Retrieves branch account status.
     */
    static getBranchAccount(branchIdentifier: string): Promise<{
        hasAccount: boolean;
        branch: {
            id: string;
            code: string;
            name: string;
            shopNumber: string;
        };
        account: null;
    } | {
        hasAccount: boolean;
        branch: {
            id: string;
            code: string;
            name: string;
            shopNumber: string;
        };
        account: {
            id: string;
            loginId: string;
            name: string;
            email: string | null;
            role: import("../../constants/index.js").AccountRole;
            branchId: string | null;
            branch: {
                id: any;
                code: any;
                name: any;
                shopNumber: any;
                city: any;
            };
            permissions: {
                pos: boolean;
                viewOwnSales: boolean;
                viewProducts: boolean;
                addEditProducts: boolean;
                viewStock: boolean;
                manageStock: boolean;
                stockTransfers: boolean;
                customers: boolean;
                customerCredit: boolean;
                collections: boolean;
                purchases: boolean;
                suppliers: boolean;
                reports: boolean;
                returns: boolean;
                discountsOverrides: boolean;
            };
            isActive: boolean;
            lastLoginAt: Date | null;
            createdAt: Date;
            updatedAt: Date;
        };
    }>;
    /**
     * Creates a login account for a branch.
     */
    static createBranchAccount(branchIdentifier: string, input: CreateBranchAccountInput, adminAccountId?: string): Promise<{
        id: string;
        loginId: string;
        name: string;
        email: string | null;
        role: import("../../constants/index.js").AccountRole;
        branchId: string | null;
        branch: {
            id: any;
            code: any;
            name: any;
            shopNumber: any;
            city: any;
        };
        permissions: {
            pos: boolean;
            viewOwnSales: boolean;
            viewProducts: boolean;
            addEditProducts: boolean;
            viewStock: boolean;
            manageStock: boolean;
            stockTransfers: boolean;
            customers: boolean;
            customerCredit: boolean;
            collections: boolean;
            purchases: boolean;
            suppliers: boolean;
            reports: boolean;
            returns: boolean;
            discountsOverrides: boolean;
        };
        isActive: boolean;
        lastLoginAt: Date | null;
        createdAt: Date;
        updatedAt: Date;
    }>;
    /**
     * Updates branch account details (name, email, loginId).
     */
    static updateBranchAccount(branchIdentifier: string, input: UpdateBranchAccountInput, adminAccountId?: string): Promise<{
        id: string;
        loginId: string;
        name: string;
        email: string | null;
        role: import("../../constants/index.js").AccountRole;
        branchId: string | null;
        branch: {
            id: any;
            code: any;
            name: any;
            shopNumber: any;
            city: any;
        };
        permissions: {
            pos: boolean;
            viewOwnSales: boolean;
            viewProducts: boolean;
            addEditProducts: boolean;
            viewStock: boolean;
            manageStock: boolean;
            stockTransfers: boolean;
            customers: boolean;
            customerCredit: boolean;
            collections: boolean;
            purchases: boolean;
            suppliers: boolean;
            reports: boolean;
            returns: boolean;
            discountsOverrides: boolean;
        };
        isActive: boolean;
        lastLoginAt: Date | null;
        createdAt: Date;
        updatedAt: Date;
    }>;
    /**
     * Admin resets branch password. Invalidates all active sessions for this account immediately.
     */
    static resetPassword(branchIdentifier: string, input: ResetPasswordInput, adminAccountId?: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Toggles branch permissions. Takes effect on the very next request.
     */
    static updatePermissions(branchIdentifier: string, input: UpdatePermissionsInput, adminAccountId?: string): Promise<{
        id: string;
        loginId: string;
        name: string;
        email: string | null;
        role: import("../../constants/index.js").AccountRole;
        branchId: string | null;
        branch: {
            id: any;
            code: any;
            name: any;
            shopNumber: any;
            city: any;
        };
        permissions: {
            pos: boolean;
            viewOwnSales: boolean;
            viewProducts: boolean;
            addEditProducts: boolean;
            viewStock: boolean;
            manageStock: boolean;
            stockTransfers: boolean;
            customers: boolean;
            customerCredit: boolean;
            collections: boolean;
            purchases: boolean;
            suppliers: boolean;
            reports: boolean;
            returns: boolean;
            discountsOverrides: boolean;
        };
        isActive: boolean;
        lastLoginAt: Date | null;
        createdAt: Date;
        updatedAt: Date;
    }>;
    /**
     * Deactivates branch account. Invalidates all active sessions immediately.
     */
    static deactivateAccount(branchIdentifier: string, adminAccountId?: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Creates a brand new Branch, default StockLocation, and Branch Account atomically.
     */
    static createBranch(input: CreateBranchInput, adminAccountId?: string): Promise<{
        id: string;
        _id: string;
        account: {
            id: string;
            loginId: string;
            role: import("../../constants/index.js").AccountRole;
        };
        code: string;
        name: string;
        shopNumber: string;
        type: string;
        city: string;
        address: string;
        phone: string;
        loginId: string;
        targetMonthlySales: number;
        permissions: BranchPermissions;
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
        $locals: Record<string, unknown>;
        $op: "save" | "validate" | "remove" | null;
        $where: Record<string, unknown>;
        baseModelName?: string;
        collection: mongoose.Collection;
        db: mongoose.Connection;
        errors?: mongoose.Error.ValidationError;
        isNew: boolean;
        schema: mongoose.Schema;
        __v: number;
    }>;
    static updateBranch(branchIdentifier: string, input: UpdateBranchDetailsInput): Promise<{
        id: string;
        _id: string;
        code: string;
        name: string;
        shopNumber: string;
        type: string;
        city: string;
        address: string;
        phone: string;
        loginId: string;
        targetMonthlySales: number;
        permissions: {
            pos: boolean;
            viewOwnSales: boolean;
            viewProducts: boolean;
            addEditProducts: boolean;
            viewStock: boolean;
            manageStock: boolean;
            stockTransfers: boolean;
            customers: boolean;
            customerCredit: boolean;
            collections: boolean;
            purchases: boolean;
            suppliers: boolean;
            reports: boolean;
            returns: boolean;
            discountsOverrides: boolean;
        };
        settings: {
            pos: boolean;
            viewOwnSales: boolean;
            viewProducts: boolean;
            addEditProducts: boolean;
            viewStock: boolean;
            manageStock: boolean;
            stockTransfers: boolean;
            customers: boolean;
            customerCredit: boolean;
            collections: boolean;
            purchases: boolean;
            suppliers: boolean;
            reports: boolean;
            returns: boolean;
            discountsOverrides: boolean;
        };
        isActive: boolean;
        createdAt: Date;
        updatedAt: Date;
    }>;
}
