import mongoose, { Document } from 'mongoose';
export interface IPurchaseReturnItem {
    sku: string;
    variantId?: mongoose.Types.ObjectId;
    productName: string;
    quantity: number;
    unitCost: number;
    totalCost: number;
    reason?: string;
}
export interface IPurchaseReturn extends Document {
    returnNumber: string;
    debitNoteNumber: string;
    supplierId: mongoose.Types.ObjectId;
    branchId: mongoose.Types.ObjectId;
    stockLocationId: mongoose.Types.ObjectId;
    purchaseOrderId?: mongoose.Types.ObjectId;
    billId?: mongoose.Types.ObjectId;
    receiptId?: mongoose.Types.ObjectId;
    items: IPurchaseReturnItem[];
    totalAmount: number;
    returnDate: Date;
    reason: string;
    status: 'COMPLETED' | 'CANCELLED';
    processedBy: string;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const PurchaseReturn: mongoose.Model<IPurchaseReturn, {}, {}, {}, mongoose.Document<unknown, {}, IPurchaseReturn, {}, {}> & IPurchaseReturn & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
