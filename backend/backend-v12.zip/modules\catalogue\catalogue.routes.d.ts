export declare const catalogueRoutes: import("express-serve-static-core").Router;
