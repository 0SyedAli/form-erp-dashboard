import { Request, Response } from 'express';
export declare class InventoryController {
    private static getUserContext;
    private static handleError;
    static getStockBalances(req: Request, res: Response): Promise<void>;
    static getStockBySku(req: Request, res: Response): Promise<void>;
    static getStockLocations(req: Request, res: Response): Promise<void>;
    static updateMinimumStock(req: Request, res: Response): Promise<void>;
    static postOpeningStock(req: Request, res: Response): Promise<void>;
    static createStockReceipt(req: Request, res: Response): Promise<void>;
    static getStockReceipts(req: Request, res: Response): Promise<void>;
    static getStockReceiptById(req: Request, res: Response): Promise<void>;
    static createAdjustments(req: Request, res: Response): Promise<void>;
    static getAdjustments(req: Request, res: Response): Promise<void>;
    static getTransfers(req: Request, res: Response): Promise<void>;
    static createTransfer(req: Request, res: Response): Promise<void>;
    static getTransferById(req: Request, res: Response): Promise<void>;
    static approveTransfer(req: Request, res: Response): Promise<void>;
    static dispatchTransfer(req: Request, res: Response): Promise<void>;
    static receiveTransfer(req: Request, res: Response): Promise<void>;
    static cancelTransfer(req: Request, res: Response): Promise<void>;
    static getStockMovements(req: Request, res: Response): Promise<void>;
    static getStockMovementById(req: Request, res: Response): Promise<void>;
    static getStockAlerts(req: Request, res: Response): Promise<void>;
    static getInventorySummary(req: Request, res: Response): Promise<void>;
}
