export declare const ACCOUNT_ROLES: {
    readonly SUPER_ADMIN: "SUPER_ADMIN";
    readonly BRANCH: "BRANCH";
};
export type AccountRole = (typeof ACCOUNT_ROLES)[keyof typeof ACCOUNT_ROLES];
export declare const BRANCH_CODES: {
    readonly MAIN: "SHOP-12-14";
    readonly DISPLAY: "SHOP-18";
    readonly WHOLESALE: "SHOP-24-A";
    readonly ORTHO: "SHOP-06";
    readonly EXPRESS: "SHOP-31";
};
export declare const STANDARD_BRANCH_PERMISSIONS: {
    pos: boolean;
    viewOwnSales: boolean;
    viewProducts: boolean;
    addEditProducts: boolean;
    viewStock: boolean;
    manageStock: boolean;
    stockTransfers: boolean;
    customers: boolean;
    customerCredit: boolean;
    collections: boolean;
    purchases: boolean;
    suppliers: boolean;
    reports: boolean;
    returns: boolean;
    discountsOverrides: boolean;
};
export type BranchPermissions = typeof STANDARD_BRANCH_PERMISSIONS;
export declare const SALE_TYPES: {
    readonly WALK_IN: "WALK_IN";
    readonly WHOLESALE: "WHOLESALE";
    readonly DISTRIBUTOR: "DISTRIBUTOR";
};
export type SaleType = (typeof SALE_TYPES)[keyof typeof SALE_TYPES];
export declare const PAYMENT_STATUSES: {
    readonly PAID: "PAID";
    readonly PARTIAL: "PARTIAL";
    readonly UNPAID: "UNPAID";
};
export type PaymentStatus = (typeof PAYMENT_STATUSES)[keyof typeof PAYMENT_STATUSES];
export declare const PAYMENT_ARRANGEMENTS: {
    readonly FULL: "FULL";
    readonly PARTIAL: "PARTIAL";
    readonly CREDIT: "CREDIT";
    readonly CASH: "CASH";
    readonly SPLIT: "SPLIT";
};
export type PaymentArrangement = (typeof PAYMENT_ARRANGEMENTS)[keyof typeof PAYMENT_ARRANGEMENTS];
export declare const INVOICE_STATUSES: {
    readonly DRAFT: "DRAFT";
    readonly CONFIRMED: "CONFIRMED";
    readonly VOID: "VOID";
    readonly REFUNDED: "REFUNDED";
};
export type InvoiceStatus = (typeof INVOICE_STATUSES)[keyof typeof INVOICE_STATUSES];
export declare const STOCK_LOCATION_TYPES: {
    readonly SALES_FLOOR: "SALES_FLOOR";
    readonly WAREHOUSE: "WAREHOUSE";
    readonly BACK_ROOM: "BACK_ROOM";
    readonly RETURNS_DAMAGED: "RETURNS_DAMAGED";
};
export type StockLocationType = (typeof STOCK_LOCATION_TYPES)[keyof typeof STOCK_LOCATION_TYPES];
export declare const STOCK_MOVEMENT_TYPES: {
    readonly OPENING_BALANCE: "OPENING_BALANCE";
    readonly PURCHASE_RECEIPT: "PURCHASE_RECEIPT";
    readonly SALE_DEDUCTION: "SALE_DEDUCTION";
    readonly INTER_BRANCH_SALE: "INTER_BRANCH_SALE";
    readonly TRANSFER_IN: "TRANSFER_IN";
    readonly TRANSFER_OUT: "TRANSFER_OUT";
    readonly PHYSICAL_COUNT: "PHYSICAL_COUNT";
    readonly ADMINISTRATIVE_ADJUSTMENT: "ADMINISTRATIVE_ADJUSTMENT";
    readonly MANUAL_ADJUSTMENT: "MANUAL_ADJUSTMENT";
    readonly RETURN_RESTOCK: "RETURN_RESTOCK";
    readonly PURCHASE_RETURN: "PURCHASE_RETURN";
};
export type StockMovementType = (typeof STOCK_MOVEMENT_TYPES)[keyof typeof STOCK_MOVEMENT_TYPES];
export declare const CUSTOMER_TYPES: {
    readonly WALK_IN: "WALK_IN";
    readonly WHOLESALE: "WHOLESALE";
    readonly DISTRIBUTOR: "DISTRIBUTOR";
    readonly RETAIL: "RETAIL";
};
export type CustomerType = (typeof CUSTOMER_TYPES)[keyof typeof CUSTOMER_TYPES];
