import mongoose from 'mongoose';
export interface DatabaseStatus {
    connected: boolean;
    readyState: number;
    host?: string;
    name?: string;
    isReplicaSet: boolean;
}
export declare function connectDatabase(uri?: string): Promise<typeof mongoose>;
export declare function disconnectDatabase(): Promise<void>;
export declare function getDatabaseStatus(): DatabaseStatus;
