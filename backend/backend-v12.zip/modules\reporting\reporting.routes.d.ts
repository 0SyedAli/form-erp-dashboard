export declare const reportingRoutes: import("express-serve-static-core").Router;
