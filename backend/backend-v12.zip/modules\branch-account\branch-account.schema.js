"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateBranchDetailsSchema = exports.branchParamSchema = exports.updatePermissionsSchema = exports.resetPasswordSchema = exports.updateBranchAccountSchema = exports.createBranchAccountSchema = exports.createBranchSchema = void 0;
const zod_1 = require("zod");
exports.createBranchSchema = zod_1.z.object({
    body: zod_1.z.object({
        loginId: zod_1.z
            .string({ required_error: 'Username / Login ID is required' })
            .trim()
            .min(3, 'Username must be at least 3 characters')
            .toLowerCase(),
        email: zod_1.z
            .string({ required_error: 'Email is required' })
            .trim()
            .email('Please enter a valid email address'),
        password: zod_1.z
            .string({ required_error: 'Password is required' })
            .min(6, 'Password must be at least 6 characters'),
        shopNumber: zod_1.z
            .string({ required_error: 'Shop number is required' })
            .trim()
            .min(1, 'Shop number is required'),
        name: zod_1.z.string().trim().optional(),
        code: zod_1.z.string().trim().optional(),
        type: zod_1.z.string().optional().default('RETAIL_STORE'),
        city: zod_1.z.string().optional().default('Karachi'),
        address: zod_1.z.string().trim().optional(),
        phone: zod_1.z.string().trim().optional(),
        targetMonthlySales: zod_1.z.number().optional().default(0),
        settings: zod_1.z.record(zod_1.z.boolean()).optional(),
    }),
});
exports.createBranchAccountSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string({ required_error: 'Branch ID or Code is required' }),
    }),
    body: zod_1.z.object({
        loginId: zod_1.z
            .string({ required_error: 'Login ID is required' })
            .trim()
            .min(3, 'Login ID must be at least 3 characters')
            .toLowerCase(),
        name: zod_1.z.string({ required_error: 'Account name is required' }).trim().min(2),
        password: zod_1.z
            .string({ required_error: 'Password is required' })
            .min(6, 'Password must be at least 6 characters'),
        email: zod_1.z.string().email().optional(),
    }),
});
exports.updateBranchAccountSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string({ required_error: 'Branch ID or Code is required' }),
    }),
    body: zod_1.z.object({
        loginId: zod_1.z.string().trim().min(3).toLowerCase().optional(),
        name: zod_1.z.string().trim().min(2).optional(),
        email: zod_1.z.string().email().optional(),
        isActive: zod_1.z.boolean().optional(),
    }),
});
exports.resetPasswordSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string({ required_error: 'Branch ID or Code is required' }),
    }),
    body: zod_1.z
        .object({
        newPassword: zod_1.z.string().min(6, 'Password must be at least 6 characters').optional(),
        password: zod_1.z.string().min(6, 'Password must be at least 6 characters').optional(),
    })
        .refine((data) => Boolean(data.newPassword || data.password), {
        message: 'New password is required (at least 6 characters)',
    }),
});
exports.updatePermissionsSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string({ required_error: 'Branch ID or Code is required' }),
    }),
    body: zod_1.z.object({
        permissions: zod_1.z.record(zod_1.z.boolean()),
    }),
});
exports.branchParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string({ required_error: 'Branch ID or Code is required' }),
    }),
});
exports.updateBranchDetailsSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string({ required_error: 'Branch ID or Code is required' }),
    }),
    body: zod_1.z.object({
        name: zod_1.z.string().trim().min(2).optional(),
        code: zod_1.z.string().trim().min(2).optional(),
        shopNumber: zod_1.z.string().trim().min(1).optional(),
        type: zod_1.z.string().optional(),
        city: zod_1.z.string().trim().optional(),
        address: zod_1.z.string().trim().optional(),
        phone: zod_1.z.string().trim().optional(),
        targetMonthlySales: zod_1.z.number().optional(),
        isActive: zod_1.z.boolean().optional(),
        settings: zod_1.z.record(zod_1.z.boolean()).optional(),
    }),
});
//# sourceMappingURL=branch-account.schema.js.map