import mongoose, { Document } from 'mongoose';
import { AccountRole } from '../constants/index.js';
/**
 * SHA-256 hash helper for opaque session tokens.
 * Only hashed tokens are stored in the database.
 */
export declare function hashToken(token: string): string;
export interface ISession extends Document {
    tokenHash: string;
    accountId: mongoose.Types.ObjectId;
    branchId?: mongoose.Types.ObjectId;
    role: AccountRole;
    expiresAt: Date;
    ipAddress?: string;
    userAgent?: string;
    isValid: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Session: mongoose.Model<ISession, {}, {}, {}, mongoose.Document<unknown, {}, ISession, {}, {}> & ISession & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
