import mongoose, { Document } from 'mongoose';
export interface ISupplier extends Document {
    code: string;
    name: string;
    contactPerson?: string;
    phone: string;
    whatsapp?: string;
    email?: string;
    address?: string;
    city: string;
    ntn?: string;
    suppliedBrands: string[];
    creditEnabled: boolean;
    defaultCreditDays: number;
    paymentTerms: string;
    creditLimit: number;
    openingPayable: number;
    currentOutstanding: number;
    balancePayable: number;
    unallocatedAdvances: number;
    supplierCreditBalance: number;
    bankName?: string;
    bankAccountNumber?: string;
    status: 'ACTIVE' | 'INACTIVE';
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Supplier: mongoose.Model<ISupplier, {}, {}, {}, mongoose.Document<unknown, {}, ISupplier, {}, {}> & ISupplier & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
