export declare const salesRoutes: import("express-serve-static-core").Router;
