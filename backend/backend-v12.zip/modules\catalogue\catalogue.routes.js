"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.catalogueRoutes = void 0;
const express_1 = require("express");
const catalogue_controller_js_1 = require("./catalogue.controller.js");
const branch_account_controller_js_1 = require("../branch-account/branch-account.controller.js");
const branch_account_schema_js_1 = require("../branch-account/branch-account.schema.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const catalogue_schema_js_1 = require("./catalogue.schema.js");
exports.catalogueRoutes = (0, express_1.Router)();
// ==========================================
// BRANDS
// ==========================================
exports.catalogueRoutes.get('/brands', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), catalogue_controller_js_1.CatalogueController.getBrands);
exports.catalogueRoutes.get('/brands/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getBrandById);
exports.catalogueRoutes.post('/brands', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.brandSchema), catalogue_controller_js_1.CatalogueController.createBrand);
exports.catalogueRoutes.patch('/brands/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updateBrandSchema), catalogue_controller_js_1.CatalogueController.updateBrand);
exports.catalogueRoutes.patch('/brands/:id/status', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.statusToggleSchema), catalogue_controller_js_1.CatalogueController.toggleBrandStatus);
exports.catalogueRoutes.delete('/brands/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.deleteBrand);
// ==========================================
// CATEGORIES
// ==========================================
exports.catalogueRoutes.get('/categories', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), catalogue_controller_js_1.CatalogueController.getCategories);
exports.catalogueRoutes.get('/categories/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getCategoryById);
exports.catalogueRoutes.post('/categories', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.categorySchema), catalogue_controller_js_1.CatalogueController.createCategory);
exports.catalogueRoutes.patch('/categories/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updateCategorySchema), catalogue_controller_js_1.CatalogueController.updateCategory);
exports.catalogueRoutes.patch('/categories/:id/status', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.statusToggleSchema), catalogue_controller_js_1.CatalogueController.toggleCategoryStatus);
exports.catalogueRoutes.delete('/categories/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.deleteCategory);
// ==========================================
// PRODUCT LINES (SUB-CATEGORIES)
// ==========================================
exports.catalogueRoutes.get('/product-lines', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), catalogue_controller_js_1.CatalogueController.getProductLines);
exports.catalogueRoutes.get('/product-lines/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getProductLineById);
exports.catalogueRoutes.post('/product-lines', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.productLineSchema), catalogue_controller_js_1.CatalogueController.createProductLine);
exports.catalogueRoutes.patch('/product-lines/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updateProductLineSchema), catalogue_controller_js_1.CatalogueController.updateProductLine);
exports.catalogueRoutes.patch('/product-lines/:id/status', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.statusToggleSchema), catalogue_controller_js_1.CatalogueController.toggleProductLineStatus);
exports.catalogueRoutes.delete('/product-lines/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.deleteProductLine);
// ==========================================
// SIZES
// ==========================================
exports.catalogueRoutes.get('/sizes', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), catalogue_controller_js_1.CatalogueController.getSizes);
exports.catalogueRoutes.post('/sizes', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.sizeSchema), catalogue_controller_js_1.CatalogueController.createSize);
exports.catalogueRoutes.patch('/sizes/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updateSizeSchema), catalogue_controller_js_1.CatalogueController.updateSize);
exports.catalogueRoutes.patch('/sizes/:id/status', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.statusToggleSchema), catalogue_controller_js_1.CatalogueController.toggleSizeStatus);
exports.catalogueRoutes.delete('/sizes/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.deleteSize);
// ==========================================
// THICKNESSES
// ==========================================
exports.catalogueRoutes.get('/thicknesses', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), catalogue_controller_js_1.CatalogueController.getThicknesses);
exports.catalogueRoutes.post('/thicknesses', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.thicknessSchema), catalogue_controller_js_1.CatalogueController.createThickness);
exports.catalogueRoutes.patch('/thicknesses/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updateThicknessSchema), catalogue_controller_js_1.CatalogueController.updateThickness);
exports.catalogueRoutes.patch('/thicknesses/:id/status', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.statusToggleSchema), catalogue_controller_js_1.CatalogueController.toggleThicknessStatus);
exports.catalogueRoutes.delete('/thicknesses/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.deleteThickness);
// ==========================================
// PRODUCTS & VARIANTS
// ==========================================
exports.catalogueRoutes.get('/products', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.paginationQuerySchema), catalogue_controller_js_1.CatalogueController.getProducts);
exports.catalogueRoutes.get('/products/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getProductById);
// Simplified Product Creation Endpoint
exports.catalogueRoutes.post('/products', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.createProductWithVariantSchema), catalogue_controller_js_1.CatalogueController.createProductWithVariant);
exports.catalogueRoutes.post('/products/import-excel', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), catalogue_controller_js_1.CatalogueController.importExcel);
exports.catalogueRoutes.get('/products/:id/skus', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getSkus);
// ==========================================
// SKUs & PRICING
// ==========================================
exports.catalogueRoutes.get('/skus', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), catalogue_controller_js_1.CatalogueController.getSkus);
exports.catalogueRoutes.get('/skus/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getSkuById);
exports.catalogueRoutes.patch('/skus/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updateSkuSchema), catalogue_controller_js_1.CatalogueController.updateSku);
exports.catalogueRoutes.patch('/skus/:id/status', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.statusToggleSchema), catalogue_controller_js_1.CatalogueController.toggleSkuStatus);
exports.catalogueRoutes.get('/skus/:id/prices', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('viewProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.idParamSchema), catalogue_controller_js_1.CatalogueController.getSkuPriceHistory);
exports.catalogueRoutes.patch('/skus/:id/prices', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('addEditProducts'), (0, validateRequest_middleware_js_1.validateRequest)(catalogue_schema_js_1.updatePricesSchema), catalogue_controller_js_1.CatalogueController.updateSkuPrices);
// ==========================================
// BRANCHES (read-only for all authenticated accounts)
// ==========================================
exports.catalogueRoutes.get('/branches', auth_middleware_js_1.authenticate, catalogue_controller_js_1.CatalogueController.getBranches);
exports.catalogueRoutes.post('/branches', auth_middleware_js_1.authenticate, auth_middleware_js_1.requireSuperAdmin, (0, validateRequest_middleware_js_1.validateRequest)(branch_account_schema_js_1.createBranchSchema), branch_account_controller_js_1.BranchAccountController.createBranch);
//# sourceMappingURL=catalogue.routes.js.map