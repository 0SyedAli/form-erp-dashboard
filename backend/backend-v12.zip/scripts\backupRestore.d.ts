export declare function runBackupAndRestoreTest(): Promise<{
    backupDir: string;
    collectionsBackedUp: number;
    totalDocumentsBackedUp: number;
    verificationPassed: boolean;
}>;
