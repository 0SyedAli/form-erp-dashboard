export declare const customerRoutes: import("express-serve-static-core").Router;
