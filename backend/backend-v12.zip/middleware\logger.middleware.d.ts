export declare const httpLogger: any;
