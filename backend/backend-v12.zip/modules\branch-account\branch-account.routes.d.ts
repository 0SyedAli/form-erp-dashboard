export declare const branchAccountRoutes: import("express-serve-static-core").Router;
