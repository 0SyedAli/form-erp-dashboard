"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
const zod_1 = require("zod");
const currentDir = typeof __dirname !== 'undefined' ? __dirname : path_1.default.resolve(process.cwd(), 'src/config');
const backendDir = path_1.default.resolve(currentDir, '../..');
// Load environment variables from backend/.env or cwd/.env
dotenv_1.default.config({ path: path_1.default.resolve(backendDir, '.env') });
dotenv_1.default.config({ path: path_1.default.resolve(process.cwd(), '.env') });
const envSchema = zod_1.z.object({
    PORT: zod_1.z.coerce.number().default(5001),
    NODE_ENV: zod_1.z.enum(['development', 'production', 'test']).default('development'),
    MONGODB_URI: zod_1.z
        .string()
        .default('mongodb://127.0.0.1:27018/moltyformerp?replicaSet=rs0'),
    FRONTEND_URL: zod_1.z.string().default('http://localhost:3000'),
    CORS_ORIGINS: zod_1.z
        .string()
        .default('http://localhost:3000,http://127.0.0.1:3000')
        .transform((val) => val.split(',').map((s) => s.trim())),
    SESSION_SECRET: zod_1.z.string().min(16).default('molty-foam-erp-super-secret-key-change-in-production-2026'),
    SESSION_TTL_HOURS: zod_1.z.coerce.number().default(24),
    COOKIE_DOMAIN: zod_1.z.string().default('localhost'),
    COOKIE_SECURE: zod_1.z
        .string()
        .default('false')
        .transform((val) => val === 'true'),
    RATE_LIMIT_WINDOW_MS: zod_1.z.coerce.number().default(15 * 60 * 1000),
    RATE_LIMIT_MAX_REQUESTS: zod_1.z.coerce.number().default(500),
    AUTH_RATE_LIMIT_MAX_REQUESTS: zod_1.z.coerce.number().default(20),
    LOG_LEVEL: zod_1.z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
    SEED_ADMIN_PASSWORD: zod_1.z.string().optional(),
    SEED_BRANCH_PASSWORD: zod_1.z.string().optional(),
});
const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
    console.error('Invalid environment variables configuration:');
    console.error(JSON.stringify(parsed.error.format(), null, 2));
    process.exit(1);
}
exports.env = parsed.data;
//# sourceMappingURL=env.js.map