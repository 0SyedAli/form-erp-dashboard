import { z } from 'zod';
export declare const checkoutItemSchema: z.ZodObject<{
    sku: z.ZodString;
    quantity: z.ZodNumber;
    unitPrice: z.ZodOptional<z.ZodNumber>;
    discount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
}, "strip", z.ZodTypeAny, {
    sku: string;
    quantity: number;
    discount: number;
    unitPrice?: number | undefined;
}, {
    sku: string;
    quantity: number;
    unitPrice?: number | undefined;
    discount?: number | undefined;
}>;
export declare const checkoutSchema: z.ZodObject<{
    body: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        sourceBranchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        customerId: z.ZodOptional<z.ZodString>;
        customerName: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        customerPhone: z.ZodOptional<z.ZodString>;
        customerType: z.ZodOptional<z.ZodString>;
        saleType: z.ZodEnum<["WALK_IN", "WHOLESALE", "DISTRIBUTOR"]>;
        paymentArrangement: z.ZodEnum<["FULL", "PARTIAL", "CREDIT"]>;
        paymentMethod: z.ZodDefault<z.ZodEnum<["CASH", "CARD", "BANK_TRANSFER", "CHEQUE", "ONLINE", "CREDIT_30D"]>>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantity: z.ZodNumber;
            unitPrice: z.ZodOptional<z.ZodNumber>;
            discount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            quantity: number;
            discount: number;
            unitPrice?: number | undefined;
        }, {
            sku: string;
            quantity: number;
            unitPrice?: number | undefined;
            discount?: number | undefined;
        }>, "many">;
        discountAmount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        amountReceived: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        cashReceived: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        dueDate: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodDate]>>;
        creditOverride: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
        creditApprovedBy: z.ZodOptional<z.ZodString>;
        overrideReason: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
        idempotencyKey: z.ZodOptional<z.ZodString>;
        editingInvoiceId: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        items: {
            sku: string;
            quantity: number;
            discount: number;
            unitPrice?: number | undefined;
        }[];
        customerName: string;
        saleType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        paymentArrangement: "PARTIAL" | "FULL" | "CREDIT";
        cashReceived: number;
        creditOverride: boolean;
        discountAmount: number;
        paymentMethod: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD" | "CREDIT_30D";
        amountReceived: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        customerType?: string | undefined;
        customerId?: string | undefined;
        sourceBranchId?: string | undefined;
        customerPhone?: string | undefined;
        dueDate?: string | Date | undefined;
        idempotencyKey?: string | undefined;
        creditApprovedBy?: string | undefined;
        overrideReason?: string | undefined;
        editingInvoiceId?: string | undefined;
    }, {
        items: {
            sku: string;
            quantity: number;
            unitPrice?: number | undefined;
            discount?: number | undefined;
        }[];
        saleType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        paymentArrangement: "PARTIAL" | "FULL" | "CREDIT";
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        customerType?: string | undefined;
        customerId?: string | undefined;
        sourceBranchId?: string | undefined;
        customerName?: string | undefined;
        customerPhone?: string | undefined;
        cashReceived?: number | undefined;
        dueDate?: string | Date | undefined;
        idempotencyKey?: string | undefined;
        creditOverride?: boolean | undefined;
        creditApprovedBy?: string | undefined;
        overrideReason?: string | undefined;
        discountAmount?: number | undefined;
        paymentMethod?: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD" | "CREDIT_30D" | undefined;
        amountReceived?: number | undefined;
        editingInvoiceId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        items: {
            sku: string;
            quantity: number;
            discount: number;
            unitPrice?: number | undefined;
        }[];
        customerName: string;
        saleType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        paymentArrangement: "PARTIAL" | "FULL" | "CREDIT";
        cashReceived: number;
        creditOverride: boolean;
        discountAmount: number;
        paymentMethod: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD" | "CREDIT_30D";
        amountReceived: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        customerType?: string | undefined;
        customerId?: string | undefined;
        sourceBranchId?: string | undefined;
        customerPhone?: string | undefined;
        dueDate?: string | Date | undefined;
        idempotencyKey?: string | undefined;
        creditApprovedBy?: string | undefined;
        overrideReason?: string | undefined;
        editingInvoiceId?: string | undefined;
    };
}, {
    body: {
        items: {
            sku: string;
            quantity: number;
            unitPrice?: number | undefined;
            discount?: number | undefined;
        }[];
        saleType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        paymentArrangement: "PARTIAL" | "FULL" | "CREDIT";
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        customerType?: string | undefined;
        customerId?: string | undefined;
        sourceBranchId?: string | undefined;
        customerName?: string | undefined;
        customerPhone?: string | undefined;
        cashReceived?: number | undefined;
        dueDate?: string | Date | undefined;
        idempotencyKey?: string | undefined;
        creditOverride?: boolean | undefined;
        creditApprovedBy?: string | undefined;
        overrideReason?: string | undefined;
        discountAmount?: number | undefined;
        paymentMethod?: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "CARD" | "CREDIT_30D" | undefined;
        amountReceived?: number | undefined;
        editingInvoiceId?: string | undefined;
    };
}>;
export declare const heldSaleSchema: z.ZodObject<{
    body: z.ZodObject<{
        customerId: z.ZodOptional<z.ZodString>;
        customerName: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        customerPhone: z.ZodOptional<z.ZodString>;
        saleType: z.ZodDefault<z.ZodOptional<z.ZodEnum<["WALK_IN", "WHOLESALE", "DISTRIBUTOR"]>>>;
        paymentArrangement: z.ZodDefault<z.ZodOptional<z.ZodEnum<["FULL", "PARTIAL", "CREDIT"]>>>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            productId: z.ZodOptional<z.ZodString>;
            productName: z.ZodString;
            sizeLabel: z.ZodOptional<z.ZodString>;
            thicknessLabel: z.ZodOptional<z.ZodString>;
            quantity: z.ZodNumber;
            unitPrice: z.ZodNumber;
            lineTotal: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            productName: string;
            lineTotal: number;
            quantity: number;
            unitPrice: number;
            productId?: string | undefined;
            sizeLabel?: string | undefined;
            thicknessLabel?: string | undefined;
        }, {
            sku: string;
            productName: string;
            lineTotal: number;
            quantity: number;
            unitPrice: number;
            productId?: string | undefined;
            sizeLabel?: string | undefined;
            thicknessLabel?: string | undefined;
        }>, "many">;
        subtotal: z.ZodNumber;
        discountAmount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        taxAmount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        grandTotal: z.ZodNumber;
        notes: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        items: {
            sku: string;
            productName: string;
            lineTotal: number;
            quantity: number;
            unitPrice: number;
            productId?: string | undefined;
            sizeLabel?: string | undefined;
            thicknessLabel?: string | undefined;
        }[];
        customerName: string;
        saleType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        subtotal: number;
        paymentArrangement: "PARTIAL" | "FULL" | "CREDIT";
        discountAmount: number;
        taxAmount: number;
        grandTotal: number;
        notes?: string | undefined;
        customerId?: string | undefined;
        customerPhone?: string | undefined;
    }, {
        items: {
            sku: string;
            productName: string;
            lineTotal: number;
            quantity: number;
            unitPrice: number;
            productId?: string | undefined;
            sizeLabel?: string | undefined;
            thicknessLabel?: string | undefined;
        }[];
        subtotal: number;
        grandTotal: number;
        notes?: string | undefined;
        customerId?: string | undefined;
        customerName?: string | undefined;
        customerPhone?: string | undefined;
        saleType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        paymentArrangement?: "PARTIAL" | "FULL" | "CREDIT" | undefined;
        discountAmount?: number | undefined;
        taxAmount?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        items: {
            sku: string;
            productName: string;
            lineTotal: number;
            quantity: number;
            unitPrice: number;
            productId?: string | undefined;
            sizeLabel?: string | undefined;
            thicknessLabel?: string | undefined;
        }[];
        customerName: string;
        saleType: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR";
        subtotal: number;
        paymentArrangement: "PARTIAL" | "FULL" | "CREDIT";
        discountAmount: number;
        taxAmount: number;
        grandTotal: number;
        notes?: string | undefined;
        customerId?: string | undefined;
        customerPhone?: string | undefined;
    };
}, {
    body: {
        items: {
            sku: string;
            productName: string;
            lineTotal: number;
            quantity: number;
            unitPrice: number;
            productId?: string | undefined;
            sizeLabel?: string | undefined;
            thicknessLabel?: string | undefined;
        }[];
        subtotal: number;
        grandTotal: number;
        notes?: string | undefined;
        customerId?: string | undefined;
        customerName?: string | undefined;
        customerPhone?: string | undefined;
        saleType?: "WALK_IN" | "WHOLESALE" | "DISTRIBUTOR" | undefined;
        paymentArrangement?: "PARTIAL" | "FULL" | "CREDIT" | undefined;
        discountAmount?: number | undefined;
        taxAmount?: number | undefined;
    };
}>;
export declare const heldSaleParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export declare const availabilityParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        skuId: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        skuId: string;
    }, {
        skuId: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        skuId: string;
    };
}, {
    params: {
        skuId: string;
    };
}>;
export type CheckoutInput = z.infer<typeof checkoutSchema>['body'];
export type HeldSaleInput = z.infer<typeof heldSaleSchema>['body'];
