import mongoose from 'mongoose';
import { IBrand, ICategory, IProductLine, ISize, IThickness, IVariant } from '../../models/index.js';
import { BrandInput, CategoryInput, ProductLineInput, SizeInput, ThicknessInput, CreateProductWithVariantInput, UpdatePricesInput, UpdateSkuInput } from './catalogue.schema.js';
export declare function generateSmartProductLineAbbr(plNameOrCode?: string): string;
export declare function generateSkuCode(brandCode: string, categoryCode: string, sizeDisplayLabel: string, thicknessValue?: number | null, productLineCodeOrName?: string): string;
export declare function invalidateMasterMetadataCache(): void;
export declare class CatalogueService {
    static getBrands(query?: {
        search?: string;
        status?: string;
        branchId?: string;
    }): Promise<any[]>;
    static getBrandById(id: string): Promise<IBrand>;
    static createBrand(input: BrandInput): Promise<IBrand>;
    static updateBrand(id: string, input: Partial<BrandInput>): Promise<IBrand>;
    static toggleBrandStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<IBrand>;
    static deleteBrand(id: string): Promise<{
        deleted: boolean;
        message: string;
    }>;
    static getCategories(query?: {
        brandId?: string;
        search?: string;
        status?: string;
        branchId?: string;
    }): Promise<any[]>;
    static getCategoryById(id: string): Promise<ICategory>;
    static createCategory(input: CategoryInput): Promise<ICategory>;
    static updateCategory(id: string, input: Partial<CategoryInput>): Promise<ICategory>;
    static toggleCategoryStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<ICategory>;
    static deleteCategory(id: string): Promise<{
        deleted: boolean;
        message: string;
    }>;
    static getProductLines(query?: {
        brandId?: string;
        categoryId?: string;
        search?: string;
        status?: string;
        branchId?: string;
    }): Promise<any[]>;
    static getProductLineById(id: string): Promise<IProductLine>;
    static createProductLine(input: ProductLineInput): Promise<IProductLine>;
    static updateProductLine(id: string, input: Partial<ProductLineInput>): Promise<IProductLine>;
    static toggleProductLineStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<IProductLine>;
    static deleteProductLine(id: string): Promise<{
        deleted: boolean;
        message: string;
    }>;
    static getSizes(query: {
        status?: string;
    }): Promise<any[]>;
    static createSize(input: SizeInput): Promise<ISize>;
    static getSizeById(id: string): Promise<ISize>;
    static updateSize(id: string, input: Partial<SizeInput>): Promise<ISize>;
    static toggleSizeStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<ISize>;
    static deleteSize(id: string): Promise<{
        deleted: boolean;
        message: string;
    }>;
    static getThicknesses(query: {
        status?: string;
    }): Promise<any[]>;
    static getThicknessById(id: string): Promise<IThickness>;
    static createThickness(input: ThicknessInput): Promise<IThickness>;
    static updateThickness(id: string, input: Partial<ThicknessInput>): Promise<IThickness>;
    static toggleThicknessStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<IThickness>;
    static deleteThickness(id: string): Promise<{
        deleted: boolean;
        message: string;
    }>;
    static getProducts(query: {
        page?: number;
        limit?: number;
        search?: string;
        brandId?: string;
        categoryId?: string;
        productLineId?: string;
        status?: string;
        branchId?: string;
    }): Promise<{
        items: {
            id: any;
            name: any;
            code: any;
            brandId: any;
            categoryId: any;
            productLineId: any;
            productLine: any;
            imageUrl: any;
            branchId: any;
            branch: any;
            brand: any;
            category: any;
            status: any;
            variants: any[];
            createdAt: any;
        }[];
        pagination: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    static getProductById(id: string): Promise<{
        id: string;
        name: string;
        brand: mongoose.Types.ObjectId;
        category: mongoose.Types.ObjectId;
        productLine: mongoose.Types.ObjectId | undefined;
        status: "ACTIVE" | "INACTIVE";
        variants: {
            id: string;
            sku: string;
            size: mongoose.Types.ObjectId;
            thickness: mongoose.Types.ObjectId | undefined;
            listPrice: number;
            purchasePrice: number;
            purchaseDiscountPercent: number | undefined;
            retailPrice: number;
            retailMarkupPercent: number | undefined;
            wholesalePrice: number;
            wholesaleDiscountPercent: number | undefined;
            distributorPrice: number;
            distributorDiscountPercent: number | undefined;
            posDisplayName: string;
            notes: string;
            status: "ACTIVE" | "INACTIVE";
        }[];
        createdAt: Date;
    }>;
    private static resolvePrimaryBranchAndLocation;
    /**
     * Main Simplified Product Creation Workflow:
     * Brand -> Category -> Size -> Thickness -> Pricing -> Opening Stock
     */
    static createProductWithVariant(input: CreateProductWithVariantInput, accountId?: string, callerBranchId?: string): Promise<{
        product: {
            id: string;
            name: string;
            brand: {
                id: any;
                name: any;
                code: any;
            };
            category: {
                id: any;
                name: any;
                code: any;
            };
        };
        variant: {
            id: any;
            sku: any;
            size: {
                id: any;
                label: any;
            };
            thickness: {
                id: any;
                label: any;
            };
            listPrice: number;
            purchasePrice: number;
            purchaseDiscountPercent: any;
            retailPrice: number;
            retailMarkupPercent: any;
            wholesalePrice: number;
            wholesaleDiscountPercent: any;
            distributorPrice: number;
            distributorDiscountPercent: any;
            initialStockCommitted: boolean;
            onHand: number;
            minimumStock: number;
        };
    }>;
    static getSkus(query: {
        search?: string;
        productId?: string;
        brandId?: string;
        categoryId?: string;
        productLineId?: string;
        status?: string;
        stockStatus?: string;
        branchId?: string;
        page?: number;
        limit?: number;
        all?: boolean;
    }, isSuperAdmin?: boolean): Promise<{
        items: any[];
        pagination: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
        counts: {
            total: number;
            active: number;
            inactive: number;
        };
    }>;
    static getSkuById(id: string, isSuperAdmin?: boolean): Promise<any>;
    static updateSku(id: string, input: UpdateSkuInput, accountId?: string): Promise<{
        id: string;
        sku: string;
        listPrice: number;
        purchasePrice: number;
        purchaseDiscountPercent: number | undefined;
        retailPrice: number;
        retailMarkupPercent: number | undefined;
        wholesalePrice: number;
        wholesaleDiscountPercent: number | undefined;
        distributorPrice: number;
        distributorDiscountPercent: number | undefined;
        stock: number;
        minimumStock: number;
        changesRecorded: number;
    }>;
    static updateSkuPrices(id: string, input: UpdatePricesInput, accountId?: string): Promise<{
        id: string;
        sku: string;
        listPrice: number;
        purchasePrice: number;
        purchaseDiscountPercent: number | undefined;
        retailPrice: number;
        retailMarkupPercent: number | undefined;
        wholesalePrice: number;
        wholesaleDiscountPercent: number | undefined;
        distributorPrice: number;
        distributorDiscountPercent: number | undefined;
        stock: number;
        minimumStock: number;
        changesRecorded: number;
    }>;
    static getSkuPriceHistory(id: string): Promise<{
        id: string;
        sku: string;
        tier: import("../../models/priceHistory.model.js").PriceTier;
        previousPrice: number;
        newPrice: number;
        previousPercent: number | undefined;
        newPercent: number | undefined;
        changedBy: mongoose.Types.ObjectId | undefined;
        reason: string | undefined;
        createdAt: Date;
    }[]>;
    static toggleSkuStatus(id: string, status: 'ACTIVE' | 'INACTIVE'): Promise<IVariant>;
    static getBranches(): Promise<Array<Record<string, any>>>;
    static importCatalogueFromRows(rows: any[], callerBranchId?: string, options?: {
        updateDuplicates?: boolean;
    }): Promise<{
        totalRows: number;
        successCount: number;
        duplicateCount: number;
        updatedCount: number;
        duplicates: Array<{
            itemNo: string;
            posDisplayName: string;
            brand: string;
            category: string;
            productLine: string;
            size: string;
            height: number;
            reason: string;
        }>;
        created: Array<any>;
        updated: Array<any>;
    }>;
}
