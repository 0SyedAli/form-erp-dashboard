export declare function runSeed(customUri?: string): Promise<void>;
