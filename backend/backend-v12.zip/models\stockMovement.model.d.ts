import mongoose, { Document } from 'mongoose';
import { StockMovementType } from '../constants/index.js';
export interface IStockMovement extends Document {
    movementNumber: string;
    branchId: mongoose.Types.ObjectId;
    stockLocationId: mongoose.Types.ObjectId;
    sku: string;
    movementType: StockMovementType;
    quantityDifference: number;
    previousBalance: number;
    newBalance: number;
    referenceType?: string;
    referenceId?: string;
    reason?: string;
    performedBy: string;
    timestamp: Date;
}
export declare const StockMovement: mongoose.Model<IStockMovement, {}, {}, {}, mongoose.Document<unknown, {}, IStockMovement, {}, {}> & IStockMovement & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
