import mongoose, { Document } from 'mongoose';
import { SaleType, PaymentArrangement } from '../constants/index.js';
export interface IHeldCartItem {
    sku: string;
    productId?: string;
    productName: string;
    sizeLabel?: string;
    thicknessLabel?: string;
    quantity: number;
    unitPrice: number;
    lineTotal: number;
}
export interface IHeldSale extends Document {
    heldNumber: string;
    branchId: mongoose.Types.ObjectId;
    cashierId?: string;
    cashierName: string;
    customerId?: mongoose.Types.ObjectId;
    customerName: string;
    customerPhone?: string;
    saleType: SaleType;
    paymentArrangement: PaymentArrangement;
    items: IHeldCartItem[];
    subtotal: number;
    discountAmount: number;
    taxAmount: number;
    grandTotal: number;
    notes?: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const HeldSale: mongoose.Model<IHeldSale, {}, {}, {}, mongoose.Document<unknown, {}, IHeldSale, {}, {}> & IHeldSale & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
