"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runSeed = runSeed;
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const database_js_1 = require("../config/database.js");
const index_js_1 = require("../models/index.js");
const index_js_2 = require("../constants/index.js");
const logger_js_1 = require("../utils/logger.js");
const cleanAndSeedCatalogue_js_1 = require("./cleanAndSeedCatalogue.js");
/**
 * All five branches belong to the same local commercial market cluster in Karachi.
 * Distant city allocations (Lahore, Islamabad, Rawalpindi, Faisalabad) are removed.
 */
const SEED_BRANCHES = [
    {
        code: 'SHOP-12',
        name: 'Main Branch',
        shopNumber: 'Shop #12–14',
        type: 'RETAIL_STORE',
        city: 'Karachi',
        address: 'Shop #12–14, Karachi',
        phone: '0300-1111111',
        loginId: 'mainbranch',
        targetMonthlySales: 4500000,
    },
    {
        code: 'SHOP-18',
        name: 'Display Center',
        shopNumber: 'Shop #18',
        type: 'SHOWROOM',
        city: 'Karachi',
        address: 'Shop #18, Karachi',
        phone: '0300-2222222',
        loginId: 'displaycenter',
        targetMonthlySales: 3500000,
    },
    {
        code: 'SHOP-24A',
        name: 'Wholesale Depot',
        shopNumber: 'Shop #24-A',
        type: 'WHOLESALE_DEPOT',
        city: 'Karachi',
        address: 'Shop #24-A, Karachi',
        phone: '0300-3333333',
        loginId: 'wholesaledepot',
        targetMonthlySales: 2500000,
    },
    {
        code: 'SHOP-06',
        name: 'Ortho Bedding Studio',
        shopNumber: 'Shop #06',
        type: 'STUDIO',
        city: 'Karachi',
        address: 'Shop #06, Karachi',
        phone: '0300-4444444',
        loginId: 'orthostudio',
        targetMonthlySales: 2000000,
    },
    {
        code: 'SHOP-31',
        name: 'Express Counter',
        shopNumber: 'Shop #31',
        type: 'EXPRESS_COUNTER',
        city: 'Karachi',
        address: 'Shop #31, Karachi',
        phone: '0300-5555555',
        loginId: 'expresscounter',
        targetMonthlySales: 1500000,
    },
];
async function runSeed(customUri) {
    logger_js_1.logger.info('Starting idempotent MongoDB seed and correction process...');
    await (0, database_js_1.connectDatabase)(customUri);
    try {
        const adminPassword = process.env.SEED_ADMIN_PASSWORD;
        const branchPassword = process.env.SEED_BRANCH_PASSWORD;
        // 1. Seed Super Admin Account
        const existingAdmin = await index_js_1.Account.findOne({ role: index_js_2.ACCOUNT_ROLES.SUPER_ADMIN });
        if (!existingAdmin) {
            if (!adminPassword) {
                throw new Error('CRITICAL CONFIG ERROR: SEED_ADMIN_PASSWORD environment variable is required to provision the initial Super Admin account. Halting.');
            }
            const adminPasswordHash = await bcryptjs_1.default.hash(adminPassword, 10);
            const adminAccount = await index_js_1.Account.create({
                loginId: 'admin',
                name: 'Super Administrator',
                email: 'admin@moltyfoam.store',
                passwordHash: adminPasswordHash,
                role: index_js_2.ACCOUNT_ROLES.SUPER_ADMIN,
                permissions: {
                    pos: true,
                    viewOwnSales: true,
                    viewProducts: true,
                    addEditProducts: true,
                    viewStock: true,
                    manageStock: true,
                    stockTransfers: true,
                    customers: true,
                    customerCredit: true,
                    purchases: true,
                    suppliers: true,
                    reports: true,
                    returns: true,
                    discountsOverrides: true,
                },
                isActive: true,
            });
            logger_js_1.logger.info({ id: adminAccount._id, loginId: adminAccount.loginId }, 'Created Super Admin account');
        }
        else {
            logger_js_1.logger.info({ loginId: existingAdmin.loginId }, 'Super Admin account already exists. Preserving credentials.');
        }
        // 2. Seed Branches and Branch Accounts with Location Correction Migration
        for (const item of SEED_BRANCHES) {
            let branch = await index_js_1.Branch.findOne({ code: item.code });
            if (!branch) {
                branch = await index_js_1.Branch.create({
                    code: item.code,
                    name: item.name,
                    shopNumber: item.shopNumber,
                    type: item.type,
                    city: item.city,
                    address: item.address,
                    phone: item.phone,
                    loginId: item.loginId,
                    targetMonthlySales: item.targetMonthlySales,
                    permissions: { ...index_js_2.STANDARD_BRANCH_PERMISSIONS },
                    isActive: true,
                });
                logger_js_1.logger.info({ code: branch.code, name: branch.name }, 'Created Branch record in Karachi cluster');
            }
            else {
                // Safe correction migration: check if previously seeded with distant city or unverified market artifacts
                const isDistantCity = ['Lahore', 'Rawalpindi', 'Islamabad', 'Faisalabad'].some((distant) => (branch?.city || '').includes(distant) || (branch?.address || '').includes(distant));
                const hasUnverifiedMarketAddress = (branch?.address || '').includes('Central Mattress Market');
                const hasOutdatedName = branch?.name !== item.name;
                if (isDistantCity || hasUnverifiedMarketAddress || hasOutdatedName) {
                    logger_js_1.logger.info({ code: branch.code, previousAddress: branch.address, newAddress: item.address }, 'Migrating branch address/name to verified local cluster shop specification');
                    branch.name = item.name;
                    branch.shopNumber = item.shopNumber;
                    branch.city = item.city;
                    branch.address = item.address;
                    await branch.save();
                }
                else {
                    logger_js_1.logger.info({ code: branch.code }, 'Branch record verified in local cluster.');
                }
            }
            // Check branch account
            const existingBranchAccount = await index_js_1.Account.findOne({ branchId: branch._id });
            if (!existingBranchAccount) {
                if (!branchPassword) {
                    throw new Error(`CRITICAL CONFIG ERROR: SEED_BRANCH_PASSWORD environment variable is required to provision account for branch '${item.name}'. Halting.`);
                }
                const branchPasswordHash = await bcryptjs_1.default.hash(branchPassword, 10);
                const branchAccount = await index_js_1.Account.create({
                    loginId: item.loginId,
                    name: item.name,
                    email: `${item.loginId}@moltyfoam.store`,
                    passwordHash: branchPasswordHash,
                    role: index_js_2.ACCOUNT_ROLES.BRANCH,
                    branchId: branch._id,
                    permissions: { ...index_js_2.STANDARD_BRANCH_PERMISSIONS },
                    isActive: true,
                });
                logger_js_1.logger.info({ loginId: branchAccount.loginId, branch: branch.name }, 'Created Branch Account');
            }
            else {
                logger_js_1.logger.info({ loginId: existingBranchAccount.loginId }, 'Branch Account already exists. Preserving credentials.');
            }
            // Ensure default Stock Locations exist for each branch
            const defaultLocations = [
                { code: 'LOC-FLOOR', name: 'Sales Floor', type: 'SALES_FLOOR' },
                { code: 'LOC-BACKROOM', name: 'Store Backroom', type: 'BACK_ROOM' },
            ];
            for (const loc of defaultLocations) {
                const existingLoc = await index_js_1.StockLocation.findOne({ branchId: branch._id, code: loc.code });
                if (!existingLoc) {
                    await index_js_1.StockLocation.create({
                        branchId: branch._id,
                        code: loc.code,
                        name: `${branch.name} - ${loc.name}`,
                        type: loc.type,
                        isActive: true,
                    });
                }
            }
        }
        // 3. Clean and seed standard Molty Foam catalogue master data
        await (0, cleanAndSeedCatalogue_js_1.cleanAndSeedCatalogue)();
        logger_js_1.logger.info('MongoDB seed and location migration completed successfully.');
    }
    catch (error) {
        logger_js_1.logger.error({ error }, 'Error during MongoDB seeding process');
        throw error;
    }
    finally {
        await (0, database_js_1.disconnectDatabase)();
    }
}
// Allow direct CLI invocation
if (process.argv[1]?.endsWith('seed.ts') || process.argv[1]?.endsWith('seed.js')) {
    runSeed().catch((err) => {
        console.error('Fatal seed error:', err);
        process.exit(1);
    });
}
//# sourceMappingURL=seed.js.map