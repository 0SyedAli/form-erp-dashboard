"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockTransfer = exports.TRANSFER_STATUSES = void 0;
const mongoose_1 = __importStar(require("mongoose"));
exports.TRANSFER_STATUSES = {
    DRAFT: 'DRAFT',
    PENDING_APPROVAL: 'PENDING_APPROVAL',
    APPROVED: 'APPROVED',
    DISPATCHED: 'DISPATCHED',
    RECEIVED: 'RECEIVED',
    CANCELLED: 'CANCELLED',
};
const TransferItemSchema = new mongoose_1.Schema({
    sku: { type: String, required: true },
    variantId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Variant' },
    quantity: { type: Number, required: true, min: 1 },
}, { _id: false });
const StockTransferSchema = new mongoose_1.Schema({
    transferNumber: {
        type: String,
        required: true,
        unique: true,
        index: true,
    },
    fromBranchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    toBranchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    fromStockLocationId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'StockLocation',
        required: true,
    },
    toStockLocationId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'StockLocation',
        required: true,
    },
    items: [TransferItemSchema],
    status: {
        type: String,
        enum: Object.values(exports.TRANSFER_STATUSES),
        default: exports.TRANSFER_STATUSES.PENDING_APPROVAL,
        index: true,
    },
    initiatedBy: {
        type: String,
        required: true,
    },
    approvedBy: {
        type: String,
    },
    approvedAt: {
        type: Date,
    },
    receivedBy: {
        type: String,
    },
    dispatchedAt: {
        type: Date,
    },
    receivedAt: {
        type: Date,
    },
    notes: {
        type: String,
    },
}, {
    timestamps: true,
});
exports.StockTransfer = mongoose_1.default.model('StockTransfer', StockTransferSchema);
//# sourceMappingURL=stockTransfer.model.js.map