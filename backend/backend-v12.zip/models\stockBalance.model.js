"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StockBalance = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const StockBalanceSchema = new mongoose_1.Schema({
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    stockLocationId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'StockLocation',
        required: true,
        index: true,
    },
    sku: {
        type: String,
        required: true,
        trim: true,
        uppercase: true,
        index: true,
    },
    variantId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Variant',
        index: true,
    },
    onHand: {
        type: Number,
        required: true,
        default: 0,
        min: [0, 'Stock balance cannot be negative under standard ERP rules'],
    },
    reserved: {
        type: Number,
        default: 0,
        min: 0,
    },
    reorderLevel: {
        type: Number,
        min: 0,
    },
}, {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
});
StockBalanceSchema.virtual('available').get(function () {
    return Math.max(0, (this.onHand || 0) - (this.reserved || 0));
});
// Compound unique index ensuring one balance record per SKU per location per branch
StockBalanceSchema.index({ branchId: 1, stockLocationId: 1, sku: 1 }, { unique: true });
exports.StockBalance = mongoose_1.default.model('StockBalance', StockBalanceSchema);
//# sourceMappingURL=stockBalance.model.js.map