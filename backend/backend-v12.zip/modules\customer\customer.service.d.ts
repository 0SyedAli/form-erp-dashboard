import mongoose from 'mongoose';
import { CustomerQuery, CreateCustomerInput, UpdateCustomerInput } from './customer.schema.js';
export interface UserContext {
    accountId: string;
    loginId: string;
    role: 'SUPER_ADMIN' | 'BRANCH';
    branchId?: string;
    permissions?: Record<string, boolean>;
}
export declare class CustomerService {
    /**
     * 1. LIST CUSTOMERS WITH SEARCH & FILTERS
     */
    static getCustomers(query: CustomerQuery, _userContext: UserContext): Promise<{
        customers: any[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    /**
     * 2. GET CUSTOMER BY ID
     */
    static getCustomerById(id: string, userContext: UserContext): Promise<any>;
    /**
     * 3. CREATE CUSTOMER
     */
    static createCustomer(input: CreateCustomerInput, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/customer.model.js").ICustomer, {}, {}> & import("../../models/customer.model.js").ICustomer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    /**
     * 4. UPDATE CUSTOMER
     */
    static updateCustomer(id: string, input: UpdateCustomerInput, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/customer.model.js").ICustomer, {}, {}> & import("../../models/customer.model.js").ICustomer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    /**
     * 5. GET CUSTOMER FINANCIAL LEDGER
     * Deterministic running balance journal statement with strict branch-isolation
     */
    static getCustomerLedger(customerId: string, userContext: UserContext, branchFilter?: string): Promise<any>;
    /**
     * 6. GET CUSTOMER OUTSTANDING INVOICES (FOR RECOVERY / COLLECTIONS)
     * Strictly filtered by branch so a branch only recovers its own receivables
     */
    static getCustomerOutstanding(customerId: string, userContext: UserContext, branchFilter?: string): Promise<{
        customer: {
            id: string;
            name: string;
            phone: string;
            outstandingBalance: number;
            creditLimit: number;
        };
        invoices: {
            id: any;
            invoiceNumber: any;
            invoiceDate: any;
            totalAmount: any;
            paidAmount: any;
            balanceDue: any;
            branchId: any;
            branchName: any;
        }[];
        totalOutstanding: number;
    }>;
    /**
     * 7. GET ALL CUSTOMER PURCHASE INVOICES
     */
    static getCustomerInvoices(customerId: string, userContext: UserContext, branchFilter?: string): Promise<(mongoose.FlattenMaps<import("../../models/salesInvoice.model.js").ISalesInvoice> & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    })[]>;
}
