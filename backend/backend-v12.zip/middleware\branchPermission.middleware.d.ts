import { Request, Response, NextFunction } from 'express';
import { BranchPermissions } from '../constants/index.js';
export declare function requireBranchPermission(permissionKey: keyof BranchPermissions): (req: Request, res: Response, next: NextFunction) => void;
export declare function requireAnyBranchPermission(permissionKeys: (keyof BranchPermissions)[]): (req: Request, res: Response, next: NextFunction) => void;
