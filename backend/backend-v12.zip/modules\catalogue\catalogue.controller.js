"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CatalogueController = void 0;
const catalogue_service_js_1 = require("./catalogue.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class CatalogueController {
    // BRANDS
    static async getBrands(req, res) {
        try {
            const branchId = req.query.branchId ||
                (req.account?.role !== 'SUPER_ADMIN' ? req.account?.branchId?._id?.toString() || req.account?.branchId?.toString() : undefined);
            const data = await catalogue_service_js_1.CatalogueService.getBrands({
                search: req.query.search,
                status: req.query.status,
                branchId,
            });
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch brands.', error.statusCode || 500);
        }
    }
    static async getBrandById(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.getBrandById(id);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Brand not found.', error.statusCode || 404);
        }
    }
    static async createBrand(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.createBrand(req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Brand created successfully.', 201);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to create brand.', error.statusCode || 500, error.code);
        }
    }
    static async updateBrand(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.updateBrand(id, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Brand updated successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update brand.', error.statusCode || 500, error.code);
        }
    }
    static async toggleBrandStatus(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.toggleBrandStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `Brand marked as ${req.body.status}.`);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to toggle brand status.', error.statusCode || 500);
        }
    }
    static async deleteBrand(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.deleteBrand(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, data.message);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to delete brand.', error.statusCode || 500);
        }
    }
    // CATEGORIES
    static async getCategories(req, res) {
        try {
            const branchId = req.query.branchId ||
                (req.account?.role !== 'SUPER_ADMIN' ? req.account?.branchId?._id?.toString() || req.account?.branchId?.toString() : undefined);
            const data = await catalogue_service_js_1.CatalogueService.getCategories({
                brandId: req.query.brandId,
                search: req.query.search,
                status: req.query.status,
                branchId,
            });
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch categories.', error.statusCode || 500);
        }
    }
    static async getCategoryById(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.getCategoryById(id);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Category not found.', error.statusCode || 404);
        }
    }
    static async createCategory(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.createCategory(req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Category created successfully.', 201);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to create category.', error.statusCode || 500, error.code);
        }
    }
    static async updateCategory(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.updateCategory(id, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Category updated successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update category.', error.statusCode || 500, error.code);
        }
    }
    static async toggleCategoryStatus(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.toggleCategoryStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `Category marked as ${req.body.status}.`);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to toggle category status.', error.statusCode || 500);
        }
    }
    static async deleteCategory(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.deleteCategory(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, data.message);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to delete category.', error.statusCode || 500);
        }
    }
    // PRODUCT LINES (SUB-CATEGORIES)
    static async getProductLines(req, res) {
        try {
            const branchId = req.query.branchId ||
                (req.account?.role !== 'SUPER_ADMIN' ? req.account?.branchId?._id?.toString() || req.account?.branchId?.toString() : undefined);
            const data = await catalogue_service_js_1.CatalogueService.getProductLines({
                brandId: req.query.brandId,
                categoryId: req.query.categoryId,
                search: req.query.search,
                status: req.query.status,
                branchId,
            });
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch product lines.', error.statusCode || 500);
        }
    }
    static async getProductLineById(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.getProductLineById(id);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Product line not found.', error.statusCode || 404);
        }
    }
    static async createProductLine(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.createProductLine(req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Product line created successfully.', 201);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to create product line.', error.statusCode || 500, error.code);
        }
    }
    static async updateProductLine(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.updateProductLine(id, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Product line updated successfully.');
        }
        catch (error) {
            if (error.code === 11000) {
                (0, apiResponse_js_1.sendError)(res, 'A product line with this name or code already exists for this brand and category.', 409, 'DUPLICATE_PRODUCT_LINE');
                return;
            }
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update product line.', error.statusCode || 500, error.code);
        }
    }
    static async toggleProductLineStatus(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.toggleProductLineStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `Product line marked as ${req.body.status}.`);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to toggle product line status.', error.statusCode || 500);
        }
    }
    static async deleteProductLine(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.deleteProductLine(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, data.message);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to delete product line.', error.statusCode || 500);
        }
    }
    // SIZES
    static async getSizes(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.getSizes({
                status: req.query.status,
            });
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch sizes.', error.statusCode || 500);
        }
    }
    static async createSize(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.createSize(req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Size added successfully.', 201);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to add size.', error.statusCode || 500, error.code);
        }
    }
    static async updateSize(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.updateSize(id, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Size updated successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update size.', error.statusCode || 500);
        }
    }
    static async toggleSizeStatus(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.toggleSizeStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `Size marked as ${req.body.status}.`);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to toggle size status.', error.statusCode || 500);
        }
    }
    static async deleteSize(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.deleteSize(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, data.message);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to delete size.', error.statusCode || 500);
        }
    }
    // THICKNESSES
    static async getThicknesses(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.getThicknesses({
                status: req.query.status,
            });
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch thicknesses.', error.statusCode || 500);
        }
    }
    static async createThickness(req, res) {
        try {
            const data = await catalogue_service_js_1.CatalogueService.createThickness(req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Thickness added successfully.', 201);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to add thickness.', error.statusCode || 500, error.code);
        }
    }
    static async updateThickness(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.updateThickness(id, req.body);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Thickness updated successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update thickness.', error.statusCode || 500);
        }
    }
    static async toggleThicknessStatus(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.toggleThicknessStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `Thickness marked as ${req.body.status}.`);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to toggle thickness status.', error.statusCode || 500);
        }
    }
    static async deleteThickness(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.deleteThickness(id);
            (0, apiResponse_js_1.sendSuccess)(res, data, data.message);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to delete thickness.', error.statusCode || 500);
        }
    }
    // PRODUCTS
    static async getProducts(req, res) {
        try {
            const isSuperAdmin = req.account?.role === 'SUPER_ADMIN';
            const effectiveBranchId = isSuperAdmin
                ? req.query.branchId
                : ((req.account?.assignedBranchId || req.account?.branchId)?.toString() || req.query.branchId);
            const data = await catalogue_service_js_1.CatalogueService.getProducts({
                page: req.query.page ? parseInt(req.query.page, 10) : 1,
                limit: req.query.limit ? parseInt(req.query.limit, 10) : 10,
                search: req.query.search,
                brandId: req.query.brandId,
                categoryId: req.query.categoryId,
                productLineId: req.query.productLineId,
                status: req.query.status,
                branchId: effectiveBranchId,
            });
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch products.', error.statusCode || 500);
        }
    }
    static async getProductById(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.getProductById(id);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Product not found.', error.statusCode || 404);
        }
    }
    static async createProductWithVariant(req, res) {
        try {
            const accountId = req.account?._id.toString();
            const branchId = req.account?.branchId?.toString();
            const result = await catalogue_service_js_1.CatalogueService.createProductWithVariant(req.body, accountId, branchId);
            (0, apiResponse_js_1.sendSuccess)(res, result, 'Product and SKU variant created successfully.', 201);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to create product variant.', error.statusCode || 500, error.code);
        }
    }
    // SKUS & PRICING
    static async getSkus(req, res) {
        try {
            const isSuperAdmin = req.account?.role === 'SUPER_ADMIN';
            const canManageProducts = isSuperAdmin || Boolean(req.account?.permissions?.addEditProducts);
            const effectiveBranchId = isSuperAdmin
                ? req.query.branchId
                : ((req.account?.assignedBranchId || req.account?.branchId)?.toString() || req.query.branchId);
            const page = req.query.page ? parseInt(req.query.page, 10) : undefined;
            const limit = req.query.limit ? parseInt(req.query.limit, 10) : undefined;
            const all = req.query.all === 'true' || req.query.all === '1';
            const data = await catalogue_service_js_1.CatalogueService.getSkus({
                search: req.query.search,
                productId: req.query.productId,
                brandId: req.query.brandId,
                categoryId: req.query.categoryId,
                productLineId: req.query.productLineId,
                status: req.query.status || (canManageProducts ? 'ALL' : 'ACTIVE'),
                stockStatus: req.query.stockStatus,
                branchId: effectiveBranchId,
                page,
                limit,
                all,
            }, canManageProducts);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch SKUs.', error.statusCode || 500);
        }
    }
    static async getSkuById(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const isSuperAdmin = req.account?.role === 'SUPER_ADMIN';
            const canViewCost = isSuperAdmin ||
                Boolean(req.account?.permissions?.viewCostPrice) ||
                Boolean(req.account?.permissions?.addEditProducts);
            const data = await catalogue_service_js_1.CatalogueService.getSkuById(id, canViewCost);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'SKU not found.', error.statusCode || 404);
        }
    }
    static async updateSku(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const accountId = req.account?._id.toString();
            const data = await catalogue_service_js_1.CatalogueService.updateSku(id, req.body, accountId);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'SKU updated successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update SKU.', error.statusCode || 500);
        }
    }
    static async updateSkuPrices(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const accountId = req.account?._id.toString();
            const data = await catalogue_service_js_1.CatalogueService.updateSku(id, req.body, accountId);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'SKU updated successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to update SKU prices.', error.statusCode || 500);
        }
    }
    static async getSkuPriceHistory(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.getSkuPriceHistory(id);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to retrieve price history.', error.statusCode || 500);
        }
    }
    static async toggleSkuStatus(req, res) {
        try {
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await catalogue_service_js_1.CatalogueService.toggleSkuStatus(id, req.body.status);
            (0, apiResponse_js_1.sendSuccess)(res, data, `SKU marked as ${req.body.status}.`);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to toggle SKU status.', error.statusCode || 500);
        }
    }
    static async getBranches(_req, res) {
        try {
            const branches = await catalogue_service_js_1.CatalogueService.getBranches();
            (0, apiResponse_js_1.sendSuccess)(res, branches, 'Branches retrieved successfully.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to fetch branches.', error.statusCode || 500);
        }
    }
    static async importExcel(req, res) {
        try {
            const rows = req.body?.rows || req.body;
            const updateDuplicates = !!req.body?.updateDuplicates;
            const branchId = req.body?.branchId || (req.account?.assignedBranchId || req.account?.branchId);
            const result = await catalogue_service_js_1.CatalogueService.importCatalogueFromRows(rows, branchId, { updateDuplicates });
            const msg = updateDuplicates
                ? `Excel sync completed. ${result.updatedCount || 0} existing items updated, ${result.successCount} new items created.`
                : `Excel import completed. ${result.successCount} items created, ${result.duplicateCount} duplicates skipped.`;
            (0, apiResponse_js_1.sendSuccess)(res, result, msg);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to import catalogue from Excel.', error.statusCode || 500);
        }
    }
}
exports.CatalogueController = CatalogueController;
//# sourceMappingURL=catalogue.controller.js.map