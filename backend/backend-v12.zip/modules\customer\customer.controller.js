"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerController = void 0;
const customer_service_js_1 = require("./customer.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class CustomerController {
    static getUserContext(req) {
        return {
            accountId: req.account?._id?.toString() || '',
            loginId: req.account?.loginId || '',
            role: req.account?.role || 'BRANCH',
            branchId: req.account?.branchId?._id?.toString() || req.account?.branchId?.toString(),
            permissions: req.account?.permissions,
        };
    }
    static handleError(res, error, defaultMessage, defaultStatus = 500) {
        const err = error;
        const msg = err.message || defaultMessage;
        const status = err.statusCode || defaultStatus;
        const code = err.code ||
            (status === 404
                ? 'NOT_FOUND'
                : status === 403
                    ? 'FORBIDDEN'
                    : status === 409
                        ? 'CONFLICT'
                        : 'INTERNAL_ERROR');
        (0, apiResponse_js_1.sendError)(res, msg, status, code, err.details);
    }
    static async getCustomers(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const data = await customer_service_js_1.CustomerService.getCustomers(req.query, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data.customers, 'Customers retrieved.', 200, data.pagination);
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to fetch customers.');
        }
    }
    static async getCustomerById(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await customer_service_js_1.CustomerService.getCustomerById(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Customer profile retrieved.');
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to fetch customer profile.');
        }
    }
    static async createCustomer(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const data = await customer_service_js_1.CustomerService.createCustomer(req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Customer created successfully.', 201);
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to create customer.');
        }
    }
    static async updateCustomer(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await customer_service_js_1.CustomerService.updateCustomer(id, req.body, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Customer profile updated.');
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to update customer.');
        }
    }
    static async getCustomerLedger(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const branchIdQuery = typeof req.query.branchId === 'string' ? req.query.branchId : undefined;
            const data = await customer_service_js_1.CustomerService.getCustomerLedger(id, userContext, branchIdQuery);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Customer account ledger retrieved.');
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to fetch customer ledger.');
        }
    }
    static async getCustomerOutstanding(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const branchIdQuery = typeof req.query.branchId === 'string' ? req.query.branchId : undefined;
            const data = await customer_service_js_1.CustomerService.getCustomerOutstanding(id, userContext, branchIdQuery);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Customer outstanding invoices retrieved.');
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to fetch customer outstanding invoices.');
        }
    }
    static async getCustomerInvoices(req, res) {
        try {
            const userContext = CustomerController.getUserContext(req);
            const id = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
            const data = await customer_service_js_1.CustomerService.getCustomerInvoices(id, userContext);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Customer invoices retrieved.');
        }
        catch (error) {
            CustomerController.handleError(res, error, 'Failed to fetch customer invoices.');
        }
    }
}
exports.CustomerController = CustomerController;
//# sourceMappingURL=customer.controller.js.map