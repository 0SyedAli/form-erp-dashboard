import mongoose from 'mongoose';
export interface UserContext {
    accountId: string;
    loginId: string;
    role: string;
    branchId?: string;
}
export declare class InventoryService {
    /**
     * Helper: Generate unique audit/receipt numbers
     */
    private static generateDocNumber;
    static getStockBalances(query: {
        branchId?: string;
        stockLocationId?: string;
        sku?: string;
        search?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        balances: {
            id: string;
            branchId: any;
            branch: mongoose.Types.ObjectId;
            stockLocationId: any;
            stockLocation: mongoose.Types.ObjectId;
            sku: string;
            variantId: any;
            variant: mongoose.Types.ObjectId | undefined;
            onHand: number;
            reserved: number;
            available: number;
            reorderLevel: number;
            updatedAt: Date;
        }[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    static getStockBySku(sku: string, userContext: UserContext): Promise<{
        id: string;
        branchId: any;
        branch: mongoose.Types.ObjectId;
        stockLocationId: any;
        stockLocation: mongoose.Types.ObjectId;
        sku: string;
        onHand: number;
        reserved: number;
        available: number;
        reorderLevel: number;
        updatedAt: Date;
    }[]>;
    static getStockLocations(branchId: string | undefined, userContext: UserContext): Promise<{
        id: string;
        branchId: any;
        branch: mongoose.Types.ObjectId;
        code: string;
        name: string;
        type: import("../../constants/index.js").StockLocationType;
        isActive: boolean;
    }[]>;
    static updateMinimumStock(skuOrId: string, reorderLevel: number, locationId: string | undefined, branchId: string | undefined, userContext: UserContext): Promise<{
        success: boolean;
        modifiedCount: number;
        reorderLevel: number;
    }>;
    static postOpeningStock(input: {
        branchId?: string;
        stockLocationId: string;
        sku: string;
        quantity: number;
        minimumStock?: number;
        notes?: string;
    }, userContext: UserContext): Promise<{
        balance: {
            id: string;
            sku: string;
            onHand: number;
            reorderLevel: number;
        };
        movement: mongoose.Document<unknown, {}, import("../../models/stockMovement.model.js").IStockMovement, {}, {}> & import("../../models/stockMovement.model.js").IStockMovement & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        };
    }>;
    static createStockReceipt(input: {
        branchId?: string;
        stockLocationId: string;
        receiptNumber?: string;
        supplierId?: string;
        supplierReference?: string;
        receivedDate?: string;
        items: Array<{
            sku: string;
            quantityOrdered?: number;
            quantityReceived: number;
            unitCost?: number;
        }>;
        idempotencyKey?: string;
        notes?: string;
    }, userContext: UserContext): Promise<any>;
    static getStockReceipts(query: {
        branchId?: string;
        supplierId?: string;
        dateFrom?: string;
        dateTo?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        receipts: (mongoose.Document<unknown, {}, import("../../models/stockReceipt.model.js").IStockReceipt, {}, {}> & import("../../models/stockReceipt.model.js").IStockReceipt & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    static getStockReceiptById(id: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockReceipt.model.js").IStockReceipt, {}, {}> & import("../../models/stockReceipt.model.js").IStockReceipt & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static createAdjustments(input: {
        branchId?: string;
        stockLocationId: string;
        items: Array<{
            sku: string;
            newPhysicalQuantity: number;
            adjustmentType?: 'PHYSICAL_COUNT' | 'ADMINISTRATIVE' | 'DAMAGE_WRITE_OFF';
            reason: string;
        }>;
        idempotencyKey?: string;
    }, userContext: UserContext): Promise<any>;
    static getAdjustments(query: {
        branchId?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        adjustments: (mongoose.Document<unknown, {}, import("../../models/stockAdjustment.model.js").IStockAdjustment, {}, {}> & import("../../models/stockAdjustment.model.js").IStockAdjustment & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    static createTransfer(input: {
        fromBranchId?: string;
        toBranchId: string;
        fromStockLocationId: string;
        toStockLocationId: string;
        items: Array<{
            sku: string;
            quantity: number;
        }>;
        notes?: string;
    }, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static approveTransfer(transferId: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static dispatchTransfer(transferId: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static receiveTransfer(transferId: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static cancelTransfer(transferId: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static getTransfers(query: {
        fromBranchId?: string;
        toBranchId?: string;
        status?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        transfers: (mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    static getTransferById(id: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockTransfer.model.js").IStockTransfer, {}, {}> & import("../../models/stockTransfer.model.js").IStockTransfer & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static getStockMovements(query: {
        branchId?: string;
        stockLocationId?: string;
        sku?: string;
        movementType?: string;
        dateFrom?: string;
        dateTo?: string;
        search?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        movements: (mongoose.Document<unknown, {}, import("../../models/stockMovement.model.js").IStockMovement, {}, {}> & import("../../models/stockMovement.model.js").IStockMovement & Required<{
            _id: mongoose.Types.ObjectId;
        }> & {
            __v: number;
        })[];
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    static getStockMovementById(id: string, userContext: UserContext): Promise<mongoose.Document<unknown, {}, import("../../models/stockMovement.model.js").IStockMovement, {}, {}> & import("../../models/stockMovement.model.js").IStockMovement & Required<{
        _id: mongoose.Types.ObjectId;
    }> & {
        __v: number;
    }>;
    static getStockAlerts(query: {
        branchId?: string;
        status?: 'ALL' | 'OUT_OF_STOCK' | 'LOW_STOCK' | 'NOT_CONFIGURED';
        brandId?: string;
        categoryId?: string;
        search?: string;
        page?: number;
        limit?: number;
    }, userContext: UserContext): Promise<{
        alerts: any[];
        metrics: {
            totalBalances: number;
            outOfStock: number;
            lowStock: number;
            healthy: number;
        };
        pagination: {
            total: number;
            page: number;
            limit: number;
            totalPages: number;
        };
    }>;
    static getInventorySummary(userContext: UserContext): Promise<{
        totalBalancesCount: number;
        totalOnHandQuantity: number;
        totalReservedQuantity: number;
        totalAvailableQuantity: number;
        lowStockAlertsCount: number;
        outOfStockCount: number;
        inTransitTransfersCount: number;
    }>;
}
