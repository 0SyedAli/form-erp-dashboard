export declare const collectionRoutes: import("express-serve-static-core").Router;
