import { Request, Response } from 'express';
export declare class PurchasingController {
    private static getUserContext;
    private static getParam;
    private static handleError;
    static createPurchaseOrder(req: Request, res: Response): Promise<void>;
    static getPurchaseOrders(req: Request, res: Response): Promise<void>;
    static getPurchaseOrderById(req: Request, res: Response): Promise<void>;
    static updatePurchaseOrder(req: Request, res: Response): Promise<void>;
    static submitPurchaseOrder(req: Request, res: Response): Promise<void>;
    static approvePurchaseOrder(req: Request, res: Response): Promise<void>;
    static cancelPurchaseOrder(req: Request, res: Response): Promise<void>;
    static receivePurchaseOrder(req: Request, res: Response): Promise<void>;
    static createSupplierBill(req: Request, res: Response): Promise<void>;
    static getSupplierBills(req: Request, res: Response): Promise<void>;
    static createSupplierPayment(req: Request, res: Response): Promise<void>;
    static getSupplierPayments(req: Request, res: Response): Promise<void>;
    static createPurchaseReturn(req: Request, res: Response): Promise<void>;
    static getPurchaseReturns(req: Request, res: Response): Promise<void>;
    static getPurchasingSummary(req: Request, res: Response): Promise<void>;
}
