import { ClientSession } from 'mongoose';
export interface TransactionOptions {
    /**
     * When true (default), requires an active MongoDB Replica Set and fails safely if transactions are unavailable.
     * Only non-transactional operations should set strict: false.
     */
    strict?: boolean;
}
/**
 * Executes a callback within a managed MongoDB multi-document ACID transaction.
 * Strictly verifies replica-set capability; fails safely if transactions are unsupported.
 */
export declare function withTransaction<T>(callback: (session: ClientSession | null) => Promise<T>, options?: TransactionOptions): Promise<T>;
export { withTransaction as runTransaction };
