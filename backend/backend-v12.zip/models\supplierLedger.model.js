"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SupplierLedgerEntry = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const SupplierLedgerEntrySchema = new mongoose_1.Schema({
    supplierId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Supplier',
        required: true,
        index: true,
    },
    branchId: {
        type: mongoose_1.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true,
        index: true,
    },
    entryDate: {
        type: Date,
        default: Date.now,
        index: true,
    },
    entryType: {
        type: String,
        enum: ['BILL', 'PAYMENT', 'DEBIT_NOTE', 'ADVANCE', 'OPENING_BALANCE', 'REVERSAL'],
        required: true,
        index: true,
    },
    referenceNumber: {
        type: String,
        required: true,
        trim: true,
        index: true,
    },
    referenceBillId: {
        type: String,
        trim: true,
        index: true,
    },
    referencePaymentId: {
        type: String,
        trim: true,
        index: true,
    },
    debit: {
        type: Number,
        required: true,
        default: 0,
        min: 0,
    },
    credit: {
        type: Number,
        required: true,
        default: 0,
        min: 0,
    },
    runningBalance: {
        type: Number,
        required: true,
    },
    narration: {
        type: String,
        required: true,
    },
    performedBy: {
        type: String,
        required: true,
    },
    timestamp: {
        type: Date,
        default: Date.now,
        index: true,
    },
}, {
    timestamps: false,
});
SupplierLedgerEntrySchema.index({ supplierId: 1, entryDate: -1, timestamp: -1 });
exports.SupplierLedgerEntry = mongoose_1.default.model('SupplierLedgerEntry', SupplierLedgerEntrySchema);
//# sourceMappingURL=supplierLedger.model.js.map