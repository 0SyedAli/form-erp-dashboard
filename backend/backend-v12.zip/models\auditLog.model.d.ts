import mongoose, { Document } from 'mongoose';
export interface IAuditLog extends Document {
    action: string;
    entity: string;
    entityId?: string;
    accountId?: mongoose.Types.ObjectId;
    branchId?: mongoose.Types.ObjectId;
    details?: Record<string, any>;
    ipAddress?: string;
    timestamp: Date;
}
export declare const AuditLog: mongoose.Model<IAuditLog, {}, {}, {}, mongoose.Document<unknown, {}, IAuditLog, {}, {}> & IAuditLog & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
