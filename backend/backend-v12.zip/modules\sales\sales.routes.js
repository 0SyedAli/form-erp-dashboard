"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesRoutes = void 0;
const express_1 = require("express");
const sales_controller_js_1 = require("./sales.controller.js");
const auth_middleware_js_1 = require("../../middleware/auth.middleware.js");
const branchPermission_middleware_js_1 = require("../../middleware/branchPermission.middleware.js");
const validateRequest_middleware_js_1 = require("../../middleware/validateRequest.middleware.js");
const sales_schema_js_1 = require("./sales.schema.js");
exports.salesRoutes = (0, express_1.Router)();
exports.salesRoutes.get('/invoices', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(sales_schema_js_1.salesQuerySchema), sales_controller_js_1.SalesController.getInvoices);
exports.salesRoutes.get('/summary', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), sales_controller_js_1.SalesController.getSalesSummary);
exports.salesRoutes.get('/invoices/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(sales_schema_js_1.invoiceParamSchema), sales_controller_js_1.SalesController.getInvoiceById);
exports.salesRoutes.get('/invoices/:id/receipt', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(sales_schema_js_1.invoiceParamSchema), sales_controller_js_1.SalesController.getInvoiceReceipt);
exports.salesRoutes.delete('/invoices/:id', auth_middleware_js_1.authenticate, (0, branchPermission_middleware_js_1.requireBranchPermission)('pos'), (0, validateRequest_middleware_js_1.validateRequest)(sales_schema_js_1.deleteInvoiceSchema), sales_controller_js_1.SalesController.deleteInvoice);
//# sourceMappingURL=sales.routes.js.map