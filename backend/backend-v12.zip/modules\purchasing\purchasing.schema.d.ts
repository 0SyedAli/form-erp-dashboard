import { z } from 'zod';
export declare const poItemSchema: z.ZodObject<{
    sku: z.ZodString;
    quantity: z.ZodNumber;
    unitCost: z.ZodNumber;
    lineDiscount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
    taxAmount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
}, "strip", z.ZodTypeAny, {
    sku: string;
    unitCost: number;
    quantity: number;
    lineDiscount: number;
    taxAmount: number;
}, {
    sku: string;
    unitCost: number;
    quantity: number;
    lineDiscount?: number | undefined;
    taxAmount?: number | undefined;
}>;
export declare const createPurchaseOrderSchema: z.ZodObject<{
    body: z.ZodObject<{
        supplierId: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        expectedDeliveryDate: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodDate]>>;
        paymentTerms: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        referenceNumber: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantity: z.ZodNumber;
            unitCost: z.ZodNumber;
            lineDiscount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
            taxAmount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount: number;
            taxAmount: number;
        }, {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount?: number | undefined;
            taxAmount?: number | undefined;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount: number;
            taxAmount: number;
        }[];
        paymentTerms: string;
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    }, {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount?: number | undefined;
            taxAmount?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        paymentTerms?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount: number;
            taxAmount: number;
        }[];
        paymentTerms: string;
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    };
}, {
    body: {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount?: number | undefined;
            taxAmount?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        paymentTerms?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    };
}>;
export declare const updatePurchaseOrderSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        supplierId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        expectedDeliveryDate: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodDate]>>;
        paymentTerms: z.ZodOptional<z.ZodString>;
        referenceNumber: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
        items: z.ZodOptional<z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantity: z.ZodNumber;
            unitCost: z.ZodNumber;
            lineDiscount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
            taxAmount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount: number;
            taxAmount: number;
        }, {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount?: number | undefined;
            taxAmount?: number | undefined;
        }>, "many">>;
    }, "strip", z.ZodTypeAny, {
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        supplierId?: string | undefined;
        items?: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount: number;
            taxAmount: number;
        }[] | undefined;
        paymentTerms?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    }, {
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        supplierId?: string | undefined;
        items?: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount?: number | undefined;
            taxAmount?: number | undefined;
        }[] | undefined;
        paymentTerms?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        supplierId?: string | undefined;
        items?: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount: number;
            taxAmount: number;
        }[] | undefined;
        paymentTerms?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        supplierId?: string | undefined;
        items?: {
            sku: string;
            unitCost: number;
            quantity: number;
            lineDiscount?: number | undefined;
            taxAmount?: number | undefined;
        }[] | undefined;
        paymentTerms?: string | undefined;
        expectedDeliveryDate?: string | Date | undefined;
        referenceNumber?: string | undefined;
    };
}>;
export declare const receiveOrderSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
    body: z.ZodObject<{
        deliveryReference: z.ZodString;
        stockLocationId: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantityReceived: z.ZodNumber;
            damagedQuantity: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            quantityReceived: number;
            damagedQuantity: number;
        }, {
            sku: string;
            quantityReceived: number;
            damagedQuantity?: number | undefined;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        items: {
            sku: string;
            quantityReceived: number;
            damagedQuantity: number;
        }[];
        deliveryReference: string;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
    }, {
        items: {
            sku: string;
            quantityReceived: number;
            damagedQuantity?: number | undefined;
        }[];
        deliveryReference: string;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
    body: {
        items: {
            sku: string;
            quantityReceived: number;
            damagedQuantity: number;
        }[];
        deliveryReference: string;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
    };
}, {
    params: {
        id: string;
    };
    body: {
        items: {
            sku: string;
            quantityReceived: number;
            damagedQuantity?: number | undefined;
        }[];
        deliveryReference: string;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
    };
}>;
export declare const createSupplierBillSchema: z.ZodObject<{
    body: z.ZodObject<{
        supplierId: z.ZodString;
        supplierInvoiceNumber: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        purchaseOrderId: z.ZodOptional<z.ZodString>;
        grnIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        billDate: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodDate]>>;
        dueDate: z.ZodUnion<[z.ZodString, z.ZodDate]>;
        notes: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantity: z.ZodNumber;
            unitCost: z.ZodNumber;
            discount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
            tax: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            unitCost: number;
            quantity: number;
            discount: number;
            tax: number;
        }, {
            sku: string;
            unitCost: number;
            quantity: number;
            discount?: number | undefined;
            tax?: number | undefined;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            discount: number;
            tax: number;
        }[];
        dueDate: string | Date;
        supplierInvoiceNumber: string;
        branchId?: string | undefined;
        notes?: string | undefined;
        purchaseOrderId?: string | undefined;
        grnIds?: string[] | undefined;
        billDate?: string | Date | undefined;
    }, {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            discount?: number | undefined;
            tax?: number | undefined;
        }[];
        dueDate: string | Date;
        supplierInvoiceNumber: string;
        branchId?: string | undefined;
        notes?: string | undefined;
        purchaseOrderId?: string | undefined;
        grnIds?: string[] | undefined;
        billDate?: string | Date | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            discount: number;
            tax: number;
        }[];
        dueDate: string | Date;
        supplierInvoiceNumber: string;
        branchId?: string | undefined;
        notes?: string | undefined;
        purchaseOrderId?: string | undefined;
        grnIds?: string[] | undefined;
        billDate?: string | Date | undefined;
    };
}, {
    body: {
        supplierId: string;
        items: {
            sku: string;
            unitCost: number;
            quantity: number;
            discount?: number | undefined;
            tax?: number | undefined;
        }[];
        dueDate: string | Date;
        supplierInvoiceNumber: string;
        branchId?: string | undefined;
        notes?: string | undefined;
        purchaseOrderId?: string | undefined;
        grnIds?: string[] | undefined;
        billDate?: string | Date | undefined;
    };
}>;
export declare const createSupplierPaymentSchema: z.ZodObject<{
    body: z.ZodObject<{
        supplierId: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        amount: z.ZodNumber;
        paymentMethod: z.ZodDefault<z.ZodEnum<["CASH", "BANK_TRANSFER", "CHEQUE", "ONLINE", "PAYPAK_CARD"]>>;
        reference: z.ZodOptional<z.ZodString>;
        notes: z.ZodOptional<z.ZodString>;
        chequeDate: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodDate]>>;
        allocations: z.ZodOptional<z.ZodArray<z.ZodObject<{
            billId: z.ZodString;
            allocatedAmount: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            billId: string;
            allocatedAmount: number;
        }, {
            billId: string;
            allocatedAmount: number;
        }>, "many">>;
        idempotencyKey: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        supplierId: string;
        amount: number;
        paymentMethod: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "PAYPAK_CARD";
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        reference?: string | undefined;
        chequeDate?: string | Date | undefined;
        allocations?: {
            billId: string;
            allocatedAmount: number;
        }[] | undefined;
    }, {
        supplierId: string;
        amount: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        paymentMethod?: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "PAYPAK_CARD" | undefined;
        reference?: string | undefined;
        chequeDate?: string | Date | undefined;
        allocations?: {
            billId: string;
            allocatedAmount: number;
        }[] | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        supplierId: string;
        amount: number;
        paymentMethod: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "PAYPAK_CARD";
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        reference?: string | undefined;
        chequeDate?: string | Date | undefined;
        allocations?: {
            billId: string;
            allocatedAmount: number;
        }[] | undefined;
    };
}, {
    body: {
        supplierId: string;
        amount: number;
        branchId?: string | undefined;
        notes?: string | undefined;
        idempotencyKey?: string | undefined;
        paymentMethod?: "CASH" | "BANK_TRANSFER" | "CHEQUE" | "ONLINE" | "PAYPAK_CARD" | undefined;
        reference?: string | undefined;
        chequeDate?: string | Date | undefined;
        allocations?: {
            billId: string;
            allocatedAmount: number;
        }[] | undefined;
    };
}>;
export declare const createPurchaseReturnSchema: z.ZodObject<{
    body: z.ZodObject<{
        supplierId: z.ZodString;
        branchId: z.ZodOptional<z.ZodString>;
        stockLocationId: z.ZodOptional<z.ZodString>;
        purchaseOrderId: z.ZodOptional<z.ZodString>;
        billId: z.ZodOptional<z.ZodString>;
        receiptId: z.ZodOptional<z.ZodString>;
        reason: z.ZodString;
        notes: z.ZodOptional<z.ZodString>;
        items: z.ZodArray<z.ZodObject<{
            sku: z.ZodString;
            quantity: z.ZodNumber;
            unitCost: z.ZodOptional<z.ZodNumber>;
            reason: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            sku: string;
            quantity: number;
            reason?: string | undefined;
            unitCost?: number | undefined;
        }, {
            sku: string;
            quantity: number;
            reason?: string | undefined;
            unitCost?: number | undefined;
        }>, "many">;
    }, "strip", z.ZodTypeAny, {
        reason: string;
        supplierId: string;
        items: {
            sku: string;
            quantity: number;
            reason?: string | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        purchaseOrderId?: string | undefined;
        billId?: string | undefined;
        receiptId?: string | undefined;
    }, {
        reason: string;
        supplierId: string;
        items: {
            sku: string;
            quantity: number;
            reason?: string | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        purchaseOrderId?: string | undefined;
        billId?: string | undefined;
        receiptId?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    body: {
        reason: string;
        supplierId: string;
        items: {
            sku: string;
            quantity: number;
            reason?: string | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        purchaseOrderId?: string | undefined;
        billId?: string | undefined;
        receiptId?: string | undefined;
    };
}, {
    body: {
        reason: string;
        supplierId: string;
        items: {
            sku: string;
            quantity: number;
            reason?: string | undefined;
            unitCost?: number | undefined;
        }[];
        branchId?: string | undefined;
        notes?: string | undefined;
        stockLocationId?: string | undefined;
        purchaseOrderId?: string | undefined;
        billId?: string | undefined;
        receiptId?: string | undefined;
    };
}>;
export declare const poQuerySchema: z.ZodObject<{
    query: z.ZodObject<{
        branchId: z.ZodOptional<z.ZodString>;
        supplierId: z.ZodOptional<z.ZodString>;
        status: z.ZodOptional<z.ZodString>;
        search: z.ZodOptional<z.ZodString>;
        dateFrom: z.ZodOptional<z.ZodString>;
        dateTo: z.ZodOptional<z.ZodString>;
        page: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
        limit: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, number, string>>>;
    }, "strip", z.ZodTypeAny, {
        limit: number;
        page: number;
        status?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        supplierId?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    }, {
        status?: string | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        supplierId?: string | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    query: {
        limit: number;
        page: number;
        status?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        supplierId?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    };
}, {
    query: {
        status?: string | undefined;
        limit?: string | undefined;
        search?: string | undefined;
        branchId?: string | undefined;
        supplierId?: string | undefined;
        page?: string | undefined;
        dateFrom?: string | undefined;
        dateTo?: string | undefined;
    };
}>;
export declare const idParamSchema: z.ZodObject<{
    params: z.ZodObject<{
        id: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        id: string;
    }, {
        id: string;
    }>;
}, "strip", z.ZodTypeAny, {
    params: {
        id: string;
    };
}, {
    params: {
        id: string;
    };
}>;
export type CreatePOInput = z.infer<typeof createPurchaseOrderSchema>['body'];
export type UpdatePOInput = z.infer<typeof updatePurchaseOrderSchema>['body'];
export type ReceiveOrderInput = z.infer<typeof receiveOrderSchema>['body'];
export type CreateSupplierBillInput = z.infer<typeof createSupplierBillSchema>['body'];
export type CreateSupplierPaymentInput = z.infer<typeof createSupplierPaymentSchema>['body'];
export type CreatePurchaseReturnInput = z.infer<typeof createPurchaseReturnSchema>['body'];
export type POQuery = z.infer<typeof poQuerySchema>['query'];
