"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = errorHandler;
const apiResponse_js_1 = require("../utils/apiResponse.js");
const logger_js_1 = require("../utils/logger.js");
const env_js_1 = require("../config/env.js");
function errorHandler(err, _req, res, _next) {
    logger_js_1.logger.error({ err }, 'Unhandled application error caught in middleware');
    // Operational AppError
    if (err instanceof apiResponse_js_1.AppError) {
        (0, apiResponse_js_1.sendError)(res, err.message, err.statusCode, err.code, err.details);
        return;
    }
    // Mongoose Validation Error
    if (err.name === 'ValidationError') {
        const details = Object.values(err.errors || {}).map((e) => ({
            field: e.path,
            message: e.message,
        }));
        (0, apiResponse_js_1.sendError)(res, 'Database schema validation failed', 400, 'DB_VALIDATION_ERROR', details);
        return;
    }
    // Mongoose CastError (invalid ObjectId, etc.)
    if (err.name === 'CastError') {
        (0, apiResponse_js_1.sendError)(res, `Invalid format for parameter "${err.path}": ${err.value}`, 400, 'INVALID_IDENTIFIER');
        return;
    }
    // MongoDB Duplicate Key Error (E11000)
    if (err.code === 11000) {
        const field = Object.keys(err.keyPattern || {})[0] || 'field';
        (0, apiResponse_js_1.sendError)(res, `Duplicate value violates unique constraint on "${field}".`, 409, 'DUPLICATE_RESOURCE', { field });
        return;
    }
    // Generic 500
    const message = env_js_1.env.NODE_ENV === 'production'
        ? 'An unexpected internal server error occurred.'
        : err.message || 'Internal server error';
    (0, apiResponse_js_1.sendError)(res, message, 500, 'INTERNAL_SERVER_ERROR', env_js_1.env.NODE_ENV === 'development' ? err.stack : undefined);
}
//# sourceMappingURL=errorHandler.middleware.js.map