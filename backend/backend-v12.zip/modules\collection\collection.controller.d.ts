import { Request, Response } from 'express';
export declare class CollectionController {
    private static getUserContext;
    private static handleError;
    static createCollection(req: Request, res: Response): Promise<void>;
    static getCollections(req: Request, res: Response): Promise<void>;
    static getCollectionById(req: Request, res: Response): Promise<void>;
    static getCollectionReceipt(req: Request, res: Response): Promise<void>;
    static getOutstanding(req: Request, res: Response): Promise<void>;
    static getOverdue(req: Request, res: Response): Promise<void>;
}
