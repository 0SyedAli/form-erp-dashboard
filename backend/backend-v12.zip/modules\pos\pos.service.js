"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PosService = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const index_js_1 = require("../../models/index.js");
const index_js_2 = require("../../constants/index.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
const transaction_js_1 = require("../../utils/transaction.js");
const sequence_js_1 = require("../../utils/sequence.js");
const financial_js_1 = require("../../utils/financial.js");
class PosService {
    static posBootstrapCache = null;
    static posOutOfStockCache = null;
    static invalidatePOSCache() {
        this.posBootstrapCache = null;
        this.posOutOfStockCache = null;
    }
    /**
     * 0. UNIFIED POS BOOTSTRAP (STAGE 1: FAST IN-STOCK ONLY)
     * Single-roundtrip, lean, high-performance bootstrap endpoint for POS.
     * Returns branches, brands, all active categories, product lines, sizes, thicknesses,
     * in-stock products, in-stock variants, and stock balances in ultra-light ~15 KB payload.
     */
    static async getPOSBootstrap(branchId, clientVersionHash) {
        const now = Date.now();
        // In-memory cache valid for 5 minutes
        if (this.posBootstrapCache && (now - this.posBootstrapCache.cachedAt < 300000)) {
            if (clientVersionHash && clientVersionHash === this.posBootstrapCache.versionHash) {
                return { notModified: true, versionHash: this.posBootstrapCache.versionHash };
            }
            return { notModified: false, versionHash: this.posBootstrapCache.versionHash, ...this.posBootstrapCache.data };
        }
        const [branches, brands, categories, productLines, sizes, thicknesses, stockBalances,] = await Promise.all([
            index_js_1.Branch.find({ $or: [{ isActive: true }, { status: 'ACTIVE' }, { isActive: { $exists: false } }] })
                .select('name code shopNumber type city address phone permissions isActive status')
                .lean(),
            index_js_1.Brand.find({ status: 'ACTIVE' }).select('name code description logoUrl status hasThickness').lean(),
            index_js_1.Category.find({ status: 'ACTIVE' }).select('brandId name code description status').lean(),
            index_js_1.ProductLine.find({ status: 'ACTIVE' }).select('brandId categoryId name code imageUrl posDisplayName status').lean(),
            index_js_1.Size.find({ status: 'ACTIVE' }).select('displayLabel length width unit status').lean(),
            index_js_1.Thickness.find({ status: 'ACTIVE' }).select('displayLabel value unit status').lean(),
            index_js_1.StockBalance.find({ onHand: { $gt: 0 } }).select('branchId variantId sku onHand available reserved').lean(),
        ]);
        const inStockVariantIds = new Set(stockBalances.map((b) => b.variantId?.toString()).filter(Boolean));
        // Fetch ONLY variants with positive on-hand stock for initial fast load
        const rawVariants = await index_js_1.Variant.find({
            status: 'ACTIVE',
            _id: { $in: Array.from(inStockVariantIds).map((id) => new mongoose_1.default.Types.ObjectId(id)) },
        }).select('_id productId sizeId thicknessId sku posDisplayName retailPrice walkInPrice wholesalePrice distributorPrice status onHand').lean();
        const inStockProductIds = new Set(rawVariants.map((v) => v.productId ? v.productId.toString() : '').filter(Boolean));
        // Fetch ONLY products that have in-stock variants
        const products = await index_js_1.Product.find({
            status: 'ACTIVE',
            _id: { $in: Array.from(inStockProductIds).map((id) => new mongoose_1.default.Types.ObjectId(id)) },
        }).select('name code brandId categoryId productLineId imageUrl posDisplayName branchId status').lean();
        // Format variants with clean rupee amounts
        const variants = rawVariants.map((v) => ({
            id: v._id.toString(),
            productId: v.productId ? v.productId.toString() : '',
            sizeId: v.sizeId ? v.sizeId.toString() : '',
            thicknessId: v.thicknessId ? v.thicknessId.toString() : '',
            sku: v.sku,
            posDisplayName: v.posDisplayName || '',
            retailPrice: (0, financial_js_1.toRupees)(v.retailPrice || 0),
            walkInPrice: (0, financial_js_1.toRupees)(v.walkInPrice || v.retailPrice || 0),
            wholesalePrice: (0, financial_js_1.toRupees)(v.wholesalePrice || 0),
            distributorPrice: (0, financial_js_1.toRupees)(v.distributorPrice || 0),
            stock: v.onHand || 0,
            status: v.status || 'ACTIVE',
        }));
        const formattedBalances = stockBalances.map((b) => ({
            id: b._id.toString(),
            branchId: b.branchId ? b.branchId.toString() : '',
            variantId: b.variantId ? b.variantId.toString() : '',
            sku: b.sku,
            onHand: b.onHand || 0,
            available: b.available !== undefined && b.available !== null ? b.available : (b.onHand || 0),
            reserved: b.reserved || 0,
        }));
        const versionHash = `pos_${variants.length}_${products.length}_${stockBalances.length}_${Math.floor(Date.now() / 60000)}`;
        const data = {
            branches: branches.map((b) => ({
                ...b,
                id: b._id ? b._id.toString() : b.id || '',
                status: b.status || (b.isActive !== false ? 'ACTIVE' : 'INACTIVE'),
            })),
            brands: brands.map((b) => ({ ...b, id: b._id.toString(), status: b.status || 'ACTIVE', hasThickness: b.hasThickness !== false })),
            categories: categories.map((c) => ({
                ...c,
                id: c._id.toString(),
                brandId: c.brandId ? c.brandId.toString() : '',
                status: c.status || 'ACTIVE',
            })),
            productLines: productLines.map((pl) => ({
                ...pl,
                id: pl._id.toString(),
                brandId: pl.brandId ? pl.brandId.toString() : '',
                categoryId: pl.categoryId ? pl.categoryId.toString() : '',
                status: pl.status || 'ACTIVE',
            })),
            sizes: sizes.map((s) => ({ ...s, id: s._id.toString(), status: s.status || 'ACTIVE' })),
            thicknesses: thicknesses.map((t) => ({ ...t, id: t._id.toString(), status: t.status || 'ACTIVE' })),
            products: products.map((p) => {
                const cat = categories.find((c) => c._id.toString() === p.categoryId?.toString());
                return {
                    ...p,
                    id: p._id.toString(),
                    brandId: p.brandId ? p.brandId.toString() : '',
                    categoryId: p.categoryId ? p.categoryId.toString() : '',
                    category: cat ? { id: cat._id.toString(), name: cat.name, code: cat.code } : undefined,
                    productLineId: p.productLineId ? p.productLineId.toString() : '',
                    status: p.status || 'ACTIVE',
                };
            }),
            variants,
            inventoryBalances: formattedBalances,
            serverTime: new Date().toISOString(),
        };
        this.posBootstrapCache = {
            data,
            versionHash,
            cachedAt: Date.now(),
        };
        if (clientVersionHash && clientVersionHash === versionHash) {
            return { notModified: true, versionHash };
        }
        return { notModified: false, versionHash, ...data };
    }
    /**
     * 0b. POS OUT OF STOCK CATALOGUE (STAGE 2: LAZY LOADED IN BACKGROUND)
     * Fetches the products and variants that currently have 0 on-hand stock.
     * Runs seamlessly in the background after bootstrap so the UI never blocks.
     */
    static async getPOSOutOfStockCatalogue(userContext, branchId) {
        const now = Date.now();
        if (this.posOutOfStockCache && (now - this.posOutOfStockCache.cachedAt < 300000)) {
            return this.posOutOfStockCache.data;
        }
        const stockBalances = await index_js_1.StockBalance.find({ onHand: { $gt: 0 } }).select('variantId').lean();
        const inStockVariantIds = new Set(stockBalances.map((b) => b.variantId?.toString()).filter(Boolean));
        const [inStockVariantProducts, outOfStockVariants, categories] = await Promise.all([
            index_js_1.Variant.find({
                status: 'ACTIVE',
                _id: { $in: Array.from(inStockVariantIds).map((id) => new mongoose_1.default.Types.ObjectId(id)) },
            }).select('productId').lean(),
            index_js_1.Variant.find({
                status: 'ACTIVE',
                _id: { $nin: Array.from(inStockVariantIds).map((id) => new mongoose_1.default.Types.ObjectId(id)) },
            }).select('_id productId sizeId thicknessId sku posDisplayName retailPrice walkInPrice wholesalePrice distributorPrice status onHand').lean(),
            index_js_1.Category.find({ status: 'ACTIVE' }).select('name code').lean(),
        ]);
        const inStockProductIds = new Set(inStockVariantProducts.map((v) => v.productId ? v.productId.toString() : '').filter(Boolean));
        // Products that currently have no in-stock variants
        const outOfStockProducts = await index_js_1.Product.find({
            status: 'ACTIVE',
            _id: { $nin: Array.from(inStockProductIds).map((id) => new mongoose_1.default.Types.ObjectId(id)) },
        }).select('name code brandId categoryId productLineId imageUrl posDisplayName branchId status').lean();
        const formattedVariants = outOfStockVariants.map((v) => ({
            id: v._id.toString(),
            productId: v.productId ? v.productId.toString() : '',
            sizeId: v.sizeId ? v.sizeId.toString() : '',
            thicknessId: v.thicknessId ? v.thicknessId.toString() : '',
            sku: v.sku,
            posDisplayName: v.posDisplayName || '',
            retailPrice: (0, financial_js_1.toRupees)(v.retailPrice || 0),
            walkInPrice: (0, financial_js_1.toRupees)(v.walkInPrice || v.retailPrice || 0),
            wholesalePrice: (0, financial_js_1.toRupees)(v.wholesalePrice || 0),
            distributorPrice: (0, financial_js_1.toRupees)(v.distributorPrice || 0),
            stock: v.onHand || 0,
            status: v.status || 'ACTIVE',
        }));
        const formattedProducts = outOfStockProducts.map((p) => {
            const cat = categories.find((c) => c._id.toString() === p.categoryId?.toString());
            return {
                ...p,
                id: p._id.toString(),
                brandId: p.brandId ? p.brandId.toString() : '',
                categoryId: p.categoryId ? p.categoryId.toString() : '',
                category: cat ? { id: cat._id.toString(), name: cat.name, code: cat.code } : undefined,
                productLineId: p.productLineId ? p.productLineId.toString() : '',
                status: p.status || 'ACTIVE',
            };
        });
        const data = {
            products: formattedProducts,
            variants: formattedVariants,
        };
        this.posOutOfStockCache = {
            data,
            cachedAt: Date.now(),
        };
        return data;
    }
    /**
     * 1. GET POS CATALOGUE
     * Returns active brands, categories, sizes, thicknesses, products and active variants
     * with prices formatted for POS and sensitive purchase prices stripped.
     */
    static async getPOSCatalogue(userContext) {
        const [brands, categories, sizes, thicknesses, products, variants] = await Promise.all([
            index_js_1.Brand.find({ status: 'ACTIVE' }).select('name code description').lean(),
            index_js_1.Category.find({ status: 'ACTIVE' }).select('brandId name code description').lean(),
            index_js_1.Size.find({ status: 'ACTIVE' }).select('displayLabel length width unit').lean(),
            index_js_1.Thickness.find({ status: 'ACTIVE' }).select('displayLabel value unit').lean(),
            index_js_1.Product.find({ status: 'ACTIVE' })
                .populate('productLineId', 'name code imageUrl')
                .select('name code brandId categoryId productLineId imageUrl')
                .lean(),
            index_js_1.Variant.find({ status: 'ACTIVE' })
                .populate('sizeId', 'displayLabel length width')
                .populate('thicknessId', 'displayLabel value')
                .populate('productId', 'name code brandId categoryId imageUrl')
                .select('-purchasePrice -purchaseDiscountPercent')
                .lean(),
        ]);
        // Map variants for easy POS consumption
        const formattedVariants = variants.map((v) => ({
            id: v._id.toString(),
            productId: v.productId?._id?.toString() || v.productId?.toString(),
            sku: v.sku,
            productName: v.productId?.name || 'Product',
            sizeLabel: v.sizeId?.displayLabel || `${v.sizeId?.length}x${v.sizeId?.width}`,
            thicknessLabel: v.thicknessId?.displayLabel || `${v.thicknessId?.value} inch`,
            retailPrice: (v.retailPrice || 0) / 100,
            wholesalePrice: (v.wholesalePrice || 0) / 100,
            distributorPrice: (v.distributorPrice || 0) / 100,
            listPrice: (v.listPrice || 0) / 100,
        }));
        return {
            brands,
            categories,
            sizes,
            thicknesses,
            products,
            variants: formattedVariants,
        };
    }
    /**
     * 2. GET SKU STOCK AVAILABILITY FOR POS
     * Accessible by POS cashier accounts without warehouse viewStock permission.
     */
    static async getSkuAvailability(skuOrId, userContext) {
        let sku = skuOrId;
        if (mongoose_1.default.Types.ObjectId.isValid(skuOrId)) {
            const v = await index_js_1.Variant.findById(skuOrId).select('sku');
            if (v)
                sku = v.sku;
        }
        let branchId = userContext.branchId;
        if (userContext.role === 'SUPER_ADMIN' && !branchId) {
            // Find main branch as default
            const mb = await mongoose_1.default.model('Branch').findOne({ code: 'SHOP-12-14' }).select('_id');
            if (mb)
                branchId = mb._id.toString();
        }
        if (!branchId) {
            throw new apiResponse_js_1.AppError('Branch context required for stock availability.', 400, 'BRANCH_CONTEXT_REQUIRED');
        }
        const balances = await index_js_1.StockBalance.find({
            branchId: new mongoose_1.default.Types.ObjectId(branchId),
            sku: sku.toUpperCase(),
        }).lean();
        let totalOnHand = 0;
        let totalReserved = 0;
        for (const bal of balances) {
            totalOnHand += bal.onHand;
            totalReserved += bal.reserved || 0;
        }
        const available = Math.max(0, totalOnHand - totalReserved);
        return {
            sku: sku.toUpperCase(),
            branchId,
            onHand: totalOnHand,
            reserved: totalReserved,
            available,
        };
    }
    /**
     * 3. ATOMIC POS CHECKOUT
     * Single authoritative financial and inventory transaction:
     * - Authoritative price lookup from DB (ignoring client unitPrice)
     * - Integer-paisa financial calculations
     * - Concurrency-safe atomic stock deduction with $gte conditional check
     * - Customer credit limit enforcement and audit logging
     * - Immutable SalesInvoice and StockMovement creation
     * - Customer ledger posting and receivables update
     */
    static async checkout(input, userContext) {
        return await (0, transaction_js_1.runTransaction)(async (session) => {
            // 1. Idempotency Check
            if (input.idempotencyKey) {
                const existingInvoice = await index_js_1.SalesInvoice.findOne({
                    idempotencyKey: input.idempotencyKey,
                }).session(session);
                if (existingInvoice) {
                    return {
                        invoice: existingInvoice,
                        message: 'Idempotent replay: original checkout result returned.',
                        isReplay: true,
                    };
                }
            }
            // 2. Resolve Effective Branch (Terminal Branch)
            let effectiveBranchId;
            if (userContext.role === 'SUPER_ADMIN' && input.branchId) {
                if (mongoose_1.default.Types.ObjectId.isValid(input.branchId)) {
                    effectiveBranchId = new mongoose_1.default.Types.ObjectId(input.branchId);
                }
                else {
                    const b = await index_js_1.Branch.findOne({ $or: [{ code: input.branchId }, { name: input.branchId }] }).session(session);
                    if (b) {
                        effectiveBranchId = b._id;
                    }
                    else {
                        const firstBranch = await index_js_1.Branch.findOne({ isActive: true }).session(session);
                        if (!firstBranch)
                            throw new apiResponse_js_1.AppError('No active branch found.', 404, 'BRANCH_NOT_FOUND');
                        effectiveBranchId = firstBranch._id;
                    }
                }
            }
            else if (userContext.branchId && mongoose_1.default.Types.ObjectId.isValid(userContext.branchId)) {
                effectiveBranchId = new mongoose_1.default.Types.ObjectId(userContext.branchId);
            }
            else {
                const defaultBranch = await index_js_1.Branch.findOne({ isActive: true }).session(session);
                if (defaultBranch) {
                    effectiveBranchId = defaultBranch._id;
                }
                else {
                    throw new apiResponse_js_1.AppError('Branch identity required for checkout.', 403, 'NO_BRANCH_ASSIGNED');
                }
            }
            // Resolve Source (Inventory Fulfilling) Branch
            let sourceBranchId = effectiveBranchId;
            let isInterBranch = false;
            if (input.sourceBranchId && mongoose_1.default.Types.ObjectId.isValid(input.sourceBranchId)) {
                const potentialSource = new mongoose_1.default.Types.ObjectId(input.sourceBranchId);
                if (potentialSource.toString() !== effectiveBranchId.toString()) {
                    sourceBranchId = potentialSource;
                    isInterBranch = true;
                }
            }
            // 3. Resolve Target Stock Location (on source fulfilling branch)
            let targetLocation;
            if (input.stockLocationId && mongoose_1.default.Types.ObjectId.isValid(input.stockLocationId)) {
                targetLocation = await index_js_1.StockLocation.findOne({
                    _id: new mongoose_1.default.Types.ObjectId(input.stockLocationId),
                    branchId: sourceBranchId,
                    isActive: { $ne: false },
                }).session(session);
            }
            if (!targetLocation) {
                targetLocation = await index_js_1.StockLocation.findOne({
                    branchId: sourceBranchId,
                    isActive: { $ne: false },
                })
                    .sort({ isDefault: -1, createdAt: 1 })
                    .session(session);
            }
            if (!targetLocation) {
                targetLocation = await index_js_1.StockLocation.findOne({
                    branchId: sourceBranchId,
                })
                    .sort({ isDefault: -1, createdAt: 1 })
                    .session(session);
            }
            if (!targetLocation) {
                const branchDoc = await index_js_1.Branch.findById(sourceBranchId).session(session);
                const branchCode = branchDoc?.code || 'MAIN';
                const [createdLoc] = await index_js_1.StockLocation.create([
                    {
                        branchId: sourceBranchId,
                        name: `${branchDoc?.name || 'Main Branch'} - Sales Floor`,
                        code: `LOC-FLOOR-${branchCode}`,
                        type: 'SALES_FLOOR',
                        isActive: true,
                    },
                ], { session });
                targetLocation = createdLoc;
            }
            // If editing an existing invoice, restore previous stock and reverse previous dues atomically
            if (input.editingInvoiceId) {
                let oldInv = null;
                if (mongoose_1.default.Types.ObjectId.isValid(input.editingInvoiceId)) {
                    oldInv = await index_js_1.SalesInvoice.findById(input.editingInvoiceId).session(session);
                }
                if (!oldInv) {
                    oldInv = await index_js_1.SalesInvoice.findOne({
                        $or: [
                            { idempotencyKey: input.editingInvoiceId },
                            { invoiceNumber: input.editingInvoiceId },
                            { invoiceNumber: input.editingInvoiceId.toUpperCase() },
                        ],
                    }).session(session);
                }
                if (oldInv && oldInv.status !== index_js_2.INVOICE_STATUSES.VOID) {
                    const oldSourceBranch = oldInv.sourceBranchId || oldInv.branchId;
                    const oldTargetLoc = await index_js_1.StockLocation.findOne({
                        branchId: oldSourceBranch,
                        isActive: { $ne: false },
                    }).session(session);
                    if (oldTargetLoc && oldInv.items) {
                        for (const it of oldInv.items) {
                            await index_js_1.StockBalance.findOneAndUpdate({ branchId: oldSourceBranch, stockLocationId: oldTargetLoc._id, sku: it.sku.toUpperCase() }, { $inc: { onHand: it.quantity } }, { session, upsert: true });
                        }
                    }
                    if (oldInv.balanceDue > 0 && oldInv.customerId) {
                        const oldCust = await index_js_1.Customer.findById(oldInv.customerId).session(session);
                        if (oldCust) {
                            oldCust.outstandingBalance = Math.max(0, (oldCust.outstandingBalance || 0) - oldInv.balanceDue);
                            await oldCust.save({ session: session || undefined });
                            await index_js_1.Customer.updateOne({ _id: oldCust._id, 'branchBalances.branchId': oldInv.branchId }, { $inc: { 'branchBalances.$.outstanding': -oldInv.balanceDue } }, { session: session || undefined });
                        }
                    }
                    oldInv.status = index_js_2.INVOICE_STATUSES.VOID;
                    oldInv.balanceDue = 0;
                    oldInv.notes = `${oldInv.notes || ''} [EDITED & REPLACED by user ${userContext.loginId}]`.trim();
                    await oldInv.save({ session: session || undefined });
                }
            }
            // 4. Resolve Authoritative Prices & Line Items in Integer Paisa
            let subtotalPaisa = 0;
            const resolvedLineItems = [];
            for (const item of input.items) {
                const variant = await index_js_1.Variant.findOne({
                    sku: item.sku.toUpperCase(),
                    status: 'ACTIVE',
                })
                    .populate('productId')
                    .populate('sizeId')
                    .populate('thicknessId')
                    .session(session);
                if (!variant) {
                    throw new apiResponse_js_1.AppError(`SKU "${item.sku}" not found or is currently inactive.`, 404, 'SKU_NOT_FOUND', { sku: item.sku });
                }
                // Authoritative Selling Price based on Sale Type (Stored in Paisa), or custom overridden unit price if provided
                let authoritativePricePaisa;
                if (typeof item.unitPrice === 'number' && item.unitPrice > 0) {
                    authoritativePricePaisa = Math.round(item.unitPrice * 100);
                }
                else {
                    switch (input.saleType) {
                        case index_js_2.SALE_TYPES.WHOLESALE:
                            authoritativePricePaisa = variant.wholesalePrice;
                            break;
                        case index_js_2.SALE_TYPES.DISTRIBUTOR:
                            authoritativePricePaisa = variant.distributorPrice || variant.wholesalePrice || variant.retailPrice;
                            break;
                        case index_js_2.SALE_TYPES.WALK_IN:
                        default:
                            authoritativePricePaisa = variant.retailPrice;
                            break;
                    }
                }
                const itemDiscountPaisa = Math.round((item.discount || 0) * 100);
                const itemLineTotalPaisa = Math.max(0, authoritativePricePaisa * item.quantity - itemDiscountPaisa);
                subtotalPaisa += itemLineTotalPaisa;
                const prod = variant.productId;
                const sz = variant.sizeId;
                const th = variant.thicknessId;
                resolvedLineItems.push({
                    variantId: variant._id,
                    sku: variant.sku,
                    productName: prod?.name || variant.sku,
                    sizeLabel: sz?.displayLabel || `${sz?.length}x${sz?.width}`,
                    thicknessLabel: th?.displayLabel || `${th?.value} inch`,
                    quantity: item.quantity,
                    unitPricePaisa: authoritativePricePaisa,
                    lineTotalPaisa: itemLineTotalPaisa,
                    unitPrice: authoritativePricePaisa / 100,
                    lineTotal: itemLineTotalPaisa / 100,
                });
            }
            // 5. Total Calculations
            const discountPaisa = Math.round((input.discountAmount || 0) * 100);
            const totalPaisa = Math.max(0, subtotalPaisa - discountPaisa);
            const totalRupees = totalPaisa / 100;
            const subtotalRupees = subtotalPaisa / 100;
            const discountRupees = discountPaisa / 100;
            // 6. Payment & Credit Evaluation
            let paidAmountRupees = 0;
            let balanceDueRupees = 0;
            const cashReceivedRupees = input.cashReceived || 0;
            let changeReturnedRupees = 0;
            let paymentStatus = index_js_2.PAYMENT_STATUSES.PAID;
            if (input.paymentArrangement === index_js_2.PAYMENT_ARRANGEMENTS.FULL) {
                paidAmountRupees = totalRupees;
                balanceDueRupees = 0;
                paymentStatus = index_js_2.PAYMENT_STATUSES.PAID;
                if (cashReceivedRupees > totalRupees) {
                    changeReturnedRupees = Math.round((cashReceivedRupees - totalRupees) * 100) / 100;
                }
            }
            else if (input.paymentArrangement === index_js_2.PAYMENT_ARRANGEMENTS.PARTIAL) {
                paidAmountRupees = Math.min(totalRupees, Math.max(0, input.amountReceived || 0));
                balanceDueRupees = Math.round((totalRupees - paidAmountRupees) * 100) / 100;
                paymentStatus = balanceDueRupees === 0 ? index_js_2.PAYMENT_STATUSES.PAID : index_js_2.PAYMENT_STATUSES.PARTIAL;
            }
            else if (input.paymentArrangement === index_js_2.PAYMENT_ARRANGEMENTS.CREDIT) {
                paidAmountRupees = 0;
                balanceDueRupees = totalRupees;
                paymentStatus = index_js_2.PAYMENT_STATUSES.UNPAID;
            }
            // 7. Customer Credit Limit Verification & Auto-Resolution
            let customer = null;
            if (input.customerId) {
                customer = await index_js_1.Customer.findById(input.customerId).session(session);
                if (!customer) {
                    throw new apiResponse_js_1.AppError('Selected customer does not exist.', 404, 'CUSTOMER_NOT_FOUND');
                }
            }
            const phoneInput = input.customerPhone?.trim();
            const nameInput = input.customerName?.trim();
            // If customer not identified by ID, search by phone number
            if (!customer && phoneInput) {
                customer = await index_js_1.Customer.findOne({ phone: phoneInput }).session(session);
            }
            if (balanceDueRupees > 0) {
                // If still no customer found in DB, check if cashier provided identification details
                if (!customer) {
                    const isGenericPlaceholder = !nameInput ||
                        nameInput.toLowerCase() === 'walk-in customer' ||
                        nameInput.toLowerCase() === 'walk-in retail customer';
                    if (!isGenericPlaceholder && phoneInput) {
                        // Auto-create identified customer in database to maintain ledger and credit tracking
                        const isWholesale = input.saleType === index_js_2.SALE_TYPES.WHOLESALE || input.saleType === index_js_2.SALE_TYPES.DISTRIBUTOR;
                        const [newCustomer] = await index_js_1.Customer.create([
                            {
                                name: nameInput,
                                phone: phoneInput,
                                customerType: isWholesale ? index_js_2.CUSTOMER_TYPES.WHOLESALE : index_js_2.CUSTOMER_TYPES.WALK_IN,
                                creditEnabled: true,
                                creditLimit: isWholesale ? 200000 : 50000,
                                outstandingBalance: 0,
                                status: 'ACTIVE',
                                city: 'Karachi',
                            },
                        ], { session });
                        customer = newCustomer;
                        input.customerId = newCustomer._id.toString();
                    }
                    else {
                        throw new apiResponse_js_1.AppError('An identified customer (Customer Name & Phone) is strictly required for credit or partial sales (Udhaar). Anonymous walk-ins cannot purchase on credit.', 400, 'ANONYMOUS_CREDIT_REJECTED');
                    }
                }
                if (customer.status !== 'ACTIVE') {
                    throw new apiResponse_js_1.AppError(`Customer account is "${customer.status}". Credit sales are prohibited.`, 403, 'CUSTOMER_NOT_ACTIVE');
                }
                // Auto-enable credit if not enabled
                if (!customer.creditEnabled) {
                    customer.creditEnabled = true;
                    await customer.save({ session });
                }
                // Available credit calculation
                const existingOutstanding = customer.outstandingBalance || 0;
                const availableCredit = Math.max(0, (customer.creditLimit || 0) - existingOutstanding);
                // Terminal cashier credit permission: If credit limit exceeded, cashier can still proceed
                // with the sale (informational warning per user requirement). We record this in audit log.
                input.customerId = customer._id.toString();
            }
            // Server-verified credit approver identity (never trust client-supplied approver)
            const isCreditOverrideApplied = Boolean(input.creditOverride);
            const serverApprovedBy = isCreditOverrideApplied
                ? userContext.role === 'SUPER_ADMIN'
                    ? `Super Admin (${userContext.loginId || userContext.name || 'System'})`
                    : `Supervisor (${userContext.loginId || userContext.name || 'Manager'})`
                : undefined;
            const serverOverrideReason = isCreditOverrideApplied
                ? input.overrideReason?.trim() || 'Authorized supervisor credit override'
                : undefined;
            // 8. Atomic Concurrency-Safe Stock Deduction (Safety Check 2.2: Available = onHand - reserved)
            // Consolidate repeated SKUs across cart lines
            const skuQuantityMap = new Map();
            for (const item of input.items) {
                const skuKey = item.sku.toUpperCase();
                skuQuantityMap.set(skuKey, (skuQuantityMap.get(skuKey) || 0) + item.quantity);
            }
            // Generate Invoice Reference early for movement tracking & audit log
            const invoiceNumber = await (0, sequence_js_1.generateDailySequence)('INV', session);
            // If credit override was applied, record an immutable audit log entry
            if (isCreditOverrideApplied) {
                await index_js_1.AuditLog.create([
                    {
                        accountId: userContext.accountId ? new mongoose_1.default.Types.ObjectId(userContext.accountId) : undefined,
                        action: 'CREDIT_LIMIT_OVERRIDE',
                        entity: 'SalesInvoice',
                        entityId: invoiceNumber,
                        details: {
                            customerId: customer?._id?.toString(),
                            customerName: customer?.name,
                            creditLimit: customer?.creditLimit,
                            existingOutstanding: customer?.outstandingBalance || 0,
                            requiredCredit: balanceDueRupees,
                            approvedBy: serverApprovedBy,
                            reason: serverOverrideReason,
                        },
                    },
                ], { session });
            }
            for (const [skuKey, totalRequiredQty] of skuQuantityMap.entries()) {
                const updatedBal = await index_js_1.StockBalance.findOneAndUpdate({
                    branchId: sourceBranchId,
                    stockLocationId: targetLocation._id,
                    sku: skuKey,
                    $expr: {
                        $gte: [
                            { $subtract: ['$onHand', { $ifNull: ['$reserved', 0] }] },
                            totalRequiredQty,
                        ],
                    },
                }, {
                    $inc: { onHand: -totalRequiredQty },
                }, { session, new: true });
                if (!updatedBal) {
                    const currentBal = await index_js_1.StockBalance.findOne({
                        branchId: sourceBranchId,
                        stockLocationId: targetLocation._id,
                        sku: skuKey,
                    }).session(session);
                    const availableNow = currentBal ? currentBal.onHand - (currentBal.reserved || 0) : 0;
                    throw new apiResponse_js_1.AppError(`Insufficient stock for SKU "${skuKey}". Available: ${availableNow}, Requested: ${totalRequiredQty}. Checkout aborted.`, 400, 'INSUFFICIENT_STOCK', {
                        sku: skuKey,
                        available: availableNow,
                        requested: totalRequiredQty,
                    });
                }
                // Create immutable audit ledger movement entry
                const movementNumber = await (0, sequence_js_1.generateDailySequence)('MOV-POS', session);
                await index_js_1.StockMovement.create([
                    {
                        movementNumber,
                        branchId: sourceBranchId,
                        stockLocationId: targetLocation._id,
                        sku: skuKey,
                        movementType: isInterBranch
                            ? index_js_2.STOCK_MOVEMENT_TYPES.INTER_BRANCH_SALE
                            : index_js_2.STOCK_MOVEMENT_TYPES.SALE_DEDUCTION,
                        quantityDifference: -totalRequiredQty,
                        previousBalance: updatedBal.onHand + totalRequiredQty,
                        newBalance: updatedBal.onHand,
                        referenceType: 'SALES_INVOICE',
                        referenceId: invoiceNumber,
                        reason: isInterBranch
                            ? `Cross-branch POS sale for terminal ${effectiveBranchId} (${input.saleType})`
                            : `POS sale checkout (${input.saleType})`,
                        performedBy: userContext.loginId,
                        timestamp: new Date(),
                    },
                ], { session });
            }
            // 9. Create Sales Invoice Snapshot
            const [invoice] = await index_js_1.SalesInvoice.create([
                {
                    invoiceNumber,
                    branchId: effectiveBranchId,
                    sourceBranchId: sourceBranchId,
                    isInterBranch: isInterBranch,
                    customerId: customer?._id,
                    customerName: customer ? customer.name : input.customerName || 'Walk-in Customer',
                    customerPhone: customer ? customer.phone : input.customerPhone,
                    customerType: customer ? customer.customerType : index_js_2.CUSTOMER_TYPES.WALK_IN,
                    saleType: input.saleType,
                    items: resolvedLineItems.map((r) => ({
                        variantId: r.variantId,
                        sku: r.sku,
                        productName: r.productName,
                        sizeLabel: r.sizeLabel,
                        thicknessLabel: r.thicknessLabel,
                        quantity: r.quantity,
                        unitPrice: r.unitPrice,
                        lineTotal: r.lineTotal,
                    })),
                    subtotal: subtotalRupees,
                    discount: discountRupees,
                    tax: 0,
                    total: totalRupees,
                    paidAmount: paidAmountRupees,
                    balanceDue: balanceDueRupees,
                    paymentStatus,
                    paymentArrangement: input.paymentArrangement,
                    cashReceived: cashReceivedRupees,
                    changeReturned: changeReturnedRupees,
                    dueDate: input.dueDate ? new Date(input.dueDate) : undefined,
                    creditOverride: isCreditOverrideApplied,
                    creditApprovedBy: serverApprovedBy,
                    overrideReason: serverOverrideReason,
                    cashierName: userContext.loginId,
                    notes: input.notes,
                    idempotencyKey: input.idempotencyKey,
                },
            ], { session });
            // 10. Customer Ledger Posting & Outstanding Balance Update
            if (customer && balanceDueRupees > 0) {
                const newOutstanding = (customer.outstandingBalance || 0) + balanceDueRupees;
                customer.outstandingBalance = newOutstanding;
                await customer.save({ session });
                await index_js_1.CustomerLedgerEntry.create([
                    {
                        customerId: customer._id,
                        branchId: effectiveBranchId,
                        entryType: 'INVOICE',
                        referenceInvoiceId: invoiceNumber,
                        debit: totalRupees,
                        credit: paidAmountRupees,
                        runningBalance: newOutstanding,
                        narration: `POS Invoice #${invoiceNumber} (${input.saleType}) - Invoiced: Rs. ${totalRupees.toLocaleString()}, Received: Rs. ${paidAmountRupees.toLocaleString()}, Outstanding: Rs. ${balanceDueRupees.toLocaleString()}`,
                        performedBy: userContext.loginId,
                        timestamp: new Date(),
                    },
                ], { session });
            }
            // 11. Record Payment Document for Cash/Card/Bank received
            if (paidAmountRupees > 0) {
                const paymentNumber = await (0, sequence_js_1.generateDailySequence)('PAY', session);
                await index_js_1.Payment.create([
                    {
                        paymentNumber,
                        invoiceId: invoice._id,
                        customerId: customer?._id || new mongoose_1.default.Types.ObjectId(),
                        branchId: effectiveBranchId,
                        amount: paidAmountRupees,
                        paymentMethod: input.paymentMethod === 'CREDIT_30D' ? 'CASH' : input.paymentMethod,
                        reference: invoiceNumber,
                        notes: `Payment for POS invoice ${invoiceNumber}`,
                        collectedBy: userContext.loginId,
                        paymentDate: new Date(),
                    },
                ], { session });
            }
            // 12. Persist Idempotency Store
            if (input.idempotencyKey) {
                await index_js_1.IdempotencyKey.create([
                    {
                        key: input.idempotencyKey,
                        endpoint: '/pos/checkout',
                        accountId: new mongoose_1.default.Types.ObjectId(userContext.accountId || userContext.branchId),
                        requestHash: `HASH-${input.idempotencyKey}`,
                        responseStatus: 201,
                        responseBody: { invoiceNumber },
                        status: 'RESOLVED',
                    },
                ], { session });
            }
            return {
                invoice,
                message: 'POS checkout completed successfully.',
                isReplay: false,
            };
        });
    }
    /**
     * 4. HELD SALES MANAGEMENT
     */
    static async getHeldSales(userContext) {
        const filter = {};
        if (userContext.role !== 'SUPER_ADMIN') {
            filter.branchId = new mongoose_1.default.Types.ObjectId(userContext.branchId);
        }
        return await index_js_1.HeldSale.find(filter).sort({ createdAt: -1 }).lean();
    }
    static async createHeldSale(input, userContext) {
        if (!userContext.branchId && userContext.role !== 'SUPER_ADMIN') {
            throw new apiResponse_js_1.AppError('Branch assignment required to hold sales.', 403, 'NO_BRANCH_ASSIGNED');
        }
        const branchId = userContext.branchId || (await mongoose_1.default.model('Branch').findOne().select('_id'))?._id;
        const heldNumber = await (0, sequence_js_1.generateDailySequence)('HOLD');
        const heldSale = await index_js_1.HeldSale.create({
            heldNumber,
            branchId: new mongoose_1.default.Types.ObjectId(branchId),
            cashierId: userContext.accountId,
            cashierName: userContext.loginId,
            customerId: input.customerId ? new mongoose_1.default.Types.ObjectId(input.customerId) : undefined,
            customerName: input.customerName || 'Walk-in Customer',
            customerPhone: input.customerPhone,
            saleType: input.saleType,
            paymentArrangement: input.paymentArrangement,
            items: input.items,
            subtotal: input.subtotal,
            discountAmount: input.discountAmount || 0,
            taxAmount: input.taxAmount || 0,
            grandTotal: input.grandTotal,
            notes: input.notes,
        });
        return heldSale;
    }
    static async deleteHeldSale(id, userContext) {
        const heldSale = await index_js_1.HeldSale.findById(id);
        if (!heldSale)
            throw new apiResponse_js_1.AppError('Held sale not found.', 404, 'HELD_SALE_NOT_FOUND');
        if (userContext.role !== 'SUPER_ADMIN' && heldSale.branchId.toString() !== userContext.branchId) {
            throw new apiResponse_js_1.AppError('Unauthorized access to held sale of another branch.', 403, 'FORBIDDEN_BRANCH');
        }
        await index_js_1.HeldSale.findByIdAndDelete(id);
        return { success: true, message: 'Held sale removed successfully.' };
    }
    static async resumeHeldSale(id, userContext) {
        const heldSale = await index_js_1.HeldSale.findById(id);
        if (!heldSale)
            throw new apiResponse_js_1.AppError('Held sale not found.', 404, 'HELD_SALE_NOT_FOUND');
        if (userContext.role !== 'SUPER_ADMIN' && heldSale.branchId.toString() !== userContext.branchId) {
            throw new apiResponse_js_1.AppError('Unauthorized access to held sale of another branch.', 403, 'FORBIDDEN_BRANCH');
        }
        // Delete from held storage upon resumption
        await index_js_1.HeldSale.findByIdAndDelete(id);
        return heldSale;
    }
}
exports.PosService = PosService;
//# sourceMappingURL=pos.service.js.map