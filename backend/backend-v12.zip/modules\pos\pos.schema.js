"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.availabilityParamSchema = exports.heldSaleParamSchema = exports.heldSaleSchema = exports.checkoutSchema = exports.checkoutItemSchema = void 0;
const zod_1 = require("zod");
const index_js_1 = require("../../constants/index.js");
exports.checkoutItemSchema = zod_1.z.object({
    sku: zod_1.z.string().min(1, 'SKU is required'),
    quantity: zod_1.z.number().int().min(1, 'Quantity must be at least 1'),
    unitPrice: zod_1.z.number().min(0).optional(), // Client preview only, backend authoritative price used
    discount: zod_1.z.number().min(0).optional().default(0),
});
exports.checkoutSchema = zod_1.z.object({
    body: zod_1.z.object({
        branchId: zod_1.z.string().optional(), // Super Admin only; for Branch, server session branchId is always enforced
        sourceBranchId: zod_1.z.string().optional(), // Cross-branch fulfillment source branch ID
        stockLocationId: zod_1.z.string().optional(), // Defaults to branch default stockroom
        customerId: zod_1.z.string().optional(),
        customerName: zod_1.z.string().optional().default('Walk-in Customer'),
        customerPhone: zod_1.z.string().optional(),
        customerType: zod_1.z.string().optional(),
        saleType: zod_1.z.enum([index_js_1.SALE_TYPES.WALK_IN, index_js_1.SALE_TYPES.WHOLESALE, index_js_1.SALE_TYPES.DISTRIBUTOR]),
        paymentArrangement: zod_1.z.enum([
            index_js_1.PAYMENT_ARRANGEMENTS.FULL,
            index_js_1.PAYMENT_ARRANGEMENTS.PARTIAL,
            index_js_1.PAYMENT_ARRANGEMENTS.CREDIT,
        ]),
        paymentMethod: zod_1.z
            .enum(['CASH', 'CARD', 'BANK_TRANSFER', 'CHEQUE', 'ONLINE', 'CREDIT_30D'])
            .default('CASH'),
        items: zod_1.z.array(exports.checkoutItemSchema).min(1, 'At least one item is required for checkout'),
        discountAmount: zod_1.z.number().min(0).optional().default(0),
        amountReceived: zod_1.z.number().min(0).optional().default(0),
        cashReceived: zod_1.z.number().min(0).optional().default(0),
        dueDate: zod_1.z.string().or(zod_1.z.date()).optional(),
        creditOverride: zod_1.z.boolean().optional().default(false),
        creditApprovedBy: zod_1.z.string().optional(),
        overrideReason: zod_1.z.string().optional(),
        notes: zod_1.z.string().optional(),
        idempotencyKey: zod_1.z.string().optional(),
        editingInvoiceId: zod_1.z.string().optional(),
    }),
});
exports.heldSaleSchema = zod_1.z.object({
    body: zod_1.z.object({
        customerId: zod_1.z.string().optional(),
        customerName: zod_1.z.string().optional().default('Walk-in Customer'),
        customerPhone: zod_1.z.string().optional(),
        saleType: zod_1.z
            .enum([index_js_1.SALE_TYPES.WALK_IN, index_js_1.SALE_TYPES.WHOLESALE, index_js_1.SALE_TYPES.DISTRIBUTOR])
            .optional()
            .default(index_js_1.SALE_TYPES.WALK_IN),
        paymentArrangement: zod_1.z
            .enum([index_js_1.PAYMENT_ARRANGEMENTS.FULL, index_js_1.PAYMENT_ARRANGEMENTS.PARTIAL, index_js_1.PAYMENT_ARRANGEMENTS.CREDIT])
            .optional()
            .default(index_js_1.PAYMENT_ARRANGEMENTS.FULL),
        items: zod_1.z.array(zod_1.z.object({
            sku: zod_1.z.string().min(1),
            productId: zod_1.z.string().optional(),
            productName: zod_1.z.string(),
            sizeLabel: zod_1.z.string().optional(),
            thicknessLabel: zod_1.z.string().optional(),
            quantity: zod_1.z.number().int().min(1),
            unitPrice: zod_1.z.number().min(0),
            lineTotal: zod_1.z.number().min(0),
        })).min(1, 'Cart must contain at least one item'),
        subtotal: zod_1.z.number().min(0),
        discountAmount: zod_1.z.number().min(0).optional().default(0),
        taxAmount: zod_1.z.number().min(0).optional().default(0),
        grandTotal: zod_1.z.number().min(0),
        notes: zod_1.z.string().optional(),
    }),
});
exports.heldSaleParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        id: zod_1.z.string().min(1, 'Held sale ID is required'),
    }),
});
exports.availabilityParamSchema = zod_1.z.object({
    params: zod_1.z.object({
        skuId: zod_1.z.string().min(1, 'SKU ID or SKU code is required'),
    }),
});
//# sourceMappingURL=pos.schema.js.map