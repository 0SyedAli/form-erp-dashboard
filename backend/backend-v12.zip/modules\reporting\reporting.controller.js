"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportingController = void 0;
const reporting_service_js_1 = require("./reporting.service.js");
const reconciliation_service_js_1 = require("./reconciliation.service.js");
const apiResponse_js_1 = require("../../utils/apiResponse.js");
class ReportingController {
    static getValidatedUser(req) {
        const user = req.account || req.user;
        if (!user)
            throw new apiResponse_js_1.AppError('Authentication required.', 401, 'UNAUTHORIZED');
        return {
            id: user._id?.toString() || user.id || '',
            role: user.role,
            branchId: user.branchId?._id?.toString() || user.branchId?.toString(),
            permissions: user.permissions,
        };
    }
    // 1. Super Admin Consolidated Dashboard
    static async getAdminDashboard(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Super Admin privileges required to view consolidated dashboard.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getAdminDashboard(req.query);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Consolidated dashboard metrics loaded.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load admin dashboard.', error.statusCode || 500, error.code);
        }
    }
    // 2. Branch Dashboard (Strict Session Isolation)
    static async getBranchDashboard(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            let targetBranchId;
            if (user.role === 'SUPER_ADMIN') {
                targetBranchId = req.query.branchId || (user.branchId ? user.branchId.toString() : '');
                if (!targetBranchId) {
                    throw new apiResponse_js_1.AppError('branchId query parameter is required for Super Admin.', 400, 'BRANCH_REQUIRED');
                }
            }
            else {
                // Branch accounts strictly access their own session branch
                if (!user.permissions?.reports) {
                    throw new apiResponse_js_1.AppError('Branch account lacks report viewing permission.', 403, 'PERMISSION_DENIED');
                }
                if (!user.branchId) {
                    throw new apiResponse_js_1.AppError('Branch identity not linked to account session.', 403, 'BRANCH_NOT_LINKED');
                }
                targetBranchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getBranchDashboard(targetBranchId, req.query);
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Branch dashboard metrics loaded.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load branch dashboard.', error.statusCode || 500, error.code);
        }
    }
    // 3. Sales Reports
    static async getSalesSummary(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getSalesSummary(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load sales summary.', error.statusCode || 500, error.code);
        }
    }
    static async getSalesTrends(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getSalesTrends(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load sales trends.', error.statusCode || 500, error.code);
        }
    }
    static async getSalesByBranch(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Cross-branch sales report is restricted to Super Admin.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getSalesByBranch(req.query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load branch sales.', error.statusCode || 500, error.code);
        }
    }
    static async getSalesByTier(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getSalesByTier(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load tier sales.', error.statusCode || 500, error.code);
        }
    }
    static async getSalesByProduct(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getSalesByProduct(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load product sales.', error.statusCode || 500, error.code);
        }
    }
    // 4. Receivables & Collections Reports
    static async getReceivablesSummary(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role === 'BRANCH' && !user.permissions?.customerCredit && !user.permissions?.reports) {
                throw new apiResponse_js_1.AppError('Branch account lacks credit reporting permissions.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getReceivablesSummary();
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load receivables summary.', error.statusCode || 500, error.code);
        }
    }
    static async getReceivablesAging(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role === 'BRANCH' && !user.permissions?.customerCredit && !user.permissions?.reports) {
                throw new apiResponse_js_1.AppError('Branch account lacks credit aging permissions.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getReceivablesAging();
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load receivables aging.', error.statusCode || 500, error.code);
        }
    }
    static async getCollectionsSummary(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getCollectionsSummary(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load collections summary.', error.statusCode || 500, error.code);
        }
    }
    // 5. Inventory Reports
    static async getInventorySummary(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getInventorySummary(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load inventory summary.', error.statusCode || 500, error.code);
        }
    }
    static async getInventoryLowStock(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getInventoryLowStock(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load low stock report.', error.statusCode || 500, error.code);
        }
    }
    static async getInventoryValuation(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Inventory valuation is restricted to Super Admin.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getInventoryValuation();
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load inventory valuation.', error.statusCode || 500, error.code);
        }
    }
    static async getInventoryMovements(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getInventoryMovements(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load inventory movements.', error.statusCode || 500, error.code);
        }
    }
    // 6. Purchasing & Payables Reports
    static async getPurchasingSummary(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            const query = { ...req.query };
            if (user.role === 'BRANCH') {
                if (!user.permissions?.purchases) {
                    throw new apiResponse_js_1.AppError('Branch lacks purchasing reporting permission.', 403, 'FORBIDDEN');
                }
                query.branchId = user.branchId.toString();
            }
            const data = await reporting_service_js_1.ReportingService.getPurchasingSummary(query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load purchasing summary.', error.statusCode || 500, error.code);
        }
    }
    static async getPurchasingBySupplier(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN' && !user.permissions?.suppliers) {
                throw new apiResponse_js_1.AppError('Access to supplier purchasing report is restricted.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getPurchasingBySupplier(req.query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load supplier purchasing report.', error.statusCode || 500, error.code);
        }
    }
    static async getPurchasingByBranch(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Cross-branch purchasing report is restricted to Super Admin.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getPurchasingByBranch(req.query);
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load branch purchasing report.', error.statusCode || 500, error.code);
        }
    }
    static async getPayablesSummary(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Accounts payable reporting is restricted to Super Admin.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getPayablesSummary();
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load payables summary.', error.statusCode || 500, error.code);
        }
    }
    static async getPayablesAging(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Accounts payable aging is restricted to Super Admin.', 403, 'FORBIDDEN');
            }
            const data = await reporting_service_js_1.ReportingService.getPayablesAging();
            (0, apiResponse_js_1.sendSuccess)(res, data);
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to load payables aging.', error.statusCode || 500, error.code);
        }
    }
    // 7. Cross-Module Audit & Reconciliation
    static async getReconciliationAudit(req, res) {
        try {
            const user = ReportingController.getValidatedUser(req);
            if (user.role !== 'SUPER_ADMIN') {
                throw new apiResponse_js_1.AppError('Reconciliation audit is restricted to Super Admin only.', 403, 'FORBIDDEN');
            }
            const data = await reconciliation_service_js_1.ReconciliationService.runFullAudit();
            (0, apiResponse_js_1.sendSuccess)(res, data, 'Cross-module financial reconciliation audit complete.');
        }
        catch (error) {
            (0, apiResponse_js_1.sendError)(res, error.message || 'Failed to execute reconciliation audit.', error.statusCode || 500, error.code);
        }
    }
}
exports.ReportingController = ReportingController;
//# sourceMappingURL=reporting.controller.js.map