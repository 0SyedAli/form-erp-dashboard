import { Request, Response, NextFunction } from 'express';
export declare class SupplierController {
    static createSupplier(req: Request, res: Response, next: NextFunction): Promise<void>;
    static getSuppliers(req: Request, res: Response, next: NextFunction): Promise<void>;
    static getSupplierById(req: Request, res: Response, next: NextFunction): Promise<void>;
    static updateSupplier(req: Request, res: Response, next: NextFunction): Promise<void>;
    static updateStatus(req: Request, res: Response, next: NextFunction): Promise<void>;
    static getSupplierLedger(req: Request, res: Response, next: NextFunction): Promise<void>;
    static getSupplierOutstanding(req: Request, res: Response, next: NextFunction): Promise<void>;
    static getSupplierBills(req: Request, res: Response, next: NextFunction): Promise<void>;
    static getSupplierPayments(req: Request, res: Response, next: NextFunction): Promise<void>;
}
