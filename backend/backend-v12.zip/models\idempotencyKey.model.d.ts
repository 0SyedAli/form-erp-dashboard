import mongoose, { Document } from 'mongoose';
export interface IIdempotencyKey extends Document {
    key: string;
    endpoint: string;
    accountId: mongoose.Types.ObjectId;
    requestHash: string;
    responseStatus?: number;
    responseBody?: any;
    status: 'PENDING' | 'RESOLVED';
    createdAt: Date;
}
export declare const IdempotencyKey: mongoose.Model<IIdempotencyKey, {}, {}, {}, mongoose.Document<unknown, {}, IIdempotencyKey, {}, {}> & IIdempotencyKey & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
