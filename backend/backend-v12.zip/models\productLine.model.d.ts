import mongoose, { Document } from 'mongoose';
export interface IProductLine extends Document {
    brandId: mongoose.Types.ObjectId;
    categoryId: mongoose.Types.ObjectId;
    branchId?: mongoose.Types.ObjectId;
    code: string;
    name: string;
    description?: string;
    imageUrl?: string;
    status: 'ACTIVE' | 'INACTIVE';
    createdAt: Date;
    updatedAt: Date;
}
export declare const ProductLine: mongoose.Model<any, {}, {}, {}, any, any>;
